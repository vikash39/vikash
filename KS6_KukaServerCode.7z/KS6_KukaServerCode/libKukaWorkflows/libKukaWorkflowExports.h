#ifndef LIB_KUKA_WORKFLOW_EXPORTS_H
#define LIB_KUKA_WORKFLOW_EXPORTS_H


#if defined(LIBKUKAWORKFLOWS_EXPORTS)
# if defined(_WIN32)
#       define KUKA_WORKFLOW_EXPORT     __declspec(dllexport)
#   else
#       define KUKA_WORKFLOW_EXPORT
#   endif
#else
#  if defined(_WIN32)
#       define KUKA_WORKFLOW_EXPORT      __declspec(dllimport)
#   else
#       define KUKA_WORKFLOW_EXPORT
#   endif
#endif

#endif  //LIB_KUKA_WORKFLOW_EXPORTS_H