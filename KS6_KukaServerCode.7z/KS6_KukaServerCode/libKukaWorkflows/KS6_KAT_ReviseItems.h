# ifndef KAT_REVISE_ITEMS_H
# define KAT_REVISE_ITEMS_H

//Custom include files
#include "libKukaWorkflows.h"

using namespace std;
#ifdef __cplusplus
extern "C" {
#endif

	#define ATTACHMENT								"attachment"
	#define ASSIGN_TO_PROJECT						"assign_to_project"
	#define ATTACHED_DATASETS						"attached_datasets"
	#define COPY_OPTIONS							"copy_options"
	#define TARGET									"target"
	#define REFERENCE								"reference"
	#define SEPARATOR_PREFERENCE					"EPM_ARG_target_user_group_list_separator"
	#define NO_COPY									"no_copy"
	#define COPY_OBJECT								"copy_object"
	#define COPY_REFERENCE							"copy_reference"
	#define ITEMREVISION							"ItemRevision"


	int processArguments(EPM_action_message_t msg, map<string, string> &mArguments, map<string, string> &mDatasetCopyOptions);
	string getDelimiter();
	int split( string str, char delimiter, vector<string> &vResult );
	int revise(tag_t tSourceObject, tag_t &tRevisedObject);
	int assignProjects(tag_t tSourceObject, tag_t tTargetObject);
	int processRelatedObjects(tag_t tSourceObject, tag_t tRevisedObject, std::map<std::string, std::string>  mDatasetCopyOptions);
	int saveAsObject(tag_t tInput, tag_t &tSavedObject);

	KUKA_WORKFLOW_EXPORT int katReviseItems(EPM_action_message_t msg);

#ifdef __cplusplus
}
#endif

#endif //KAT_REVISE_ITEMS_H
