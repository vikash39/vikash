#include "libKukaWorkflows.h"
#include "KS6_KAT_ReviseItems.h"
#include "KS6_KAT_AttachAssemblyComponents.h"

int libKukaWorkflows_register_callbacks()
{
	int iStatus = ITK_ok;
	try
	{
		TC_write_syslog( "Successfully registered libKukaWorkflows dll. Built on %s %s \n", __DATE__, __TIME__ );

		CUSTOM_register_exit( "libKukaWorkflows", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t) kukaRegisterHandlers );

	}
	catch (...)
	{
		TC_write_syslog( "Exception occurred while registering Kuka handlers." );
	}
	return iStatus;
}

int kukaRegisterHandlers( int* decision, va_list args )
{
	int iStatus = ITK_ok;
	try
	{
		*decision = ALL_CUSTOMIZATIONS;

		TC_write_syslog( "Registering Kuka action handlers." );

		//Register action handlers
		EPM_register_action_handler("KAT-revise-items", "KAT Revise Items", (EPM_action_handler_t)katReviseItems);

		EPM_register_action_handler("KAT-attach-assembly-components", "KAT Attach Assembly Components", (EPM_action_handler_t)katAttachAssemblyComponents);

		//EPM_register_action_handler("KAT-move-attached-objects", "KAT Move Attached Objects", (EPM_action_handler_t)katMoveAttachedObjects);

	}
	catch (...)
	{
		TC_write_syslog( "Exception occurred while registering Kuka handlers." );
	}
	return iStatus;
}


