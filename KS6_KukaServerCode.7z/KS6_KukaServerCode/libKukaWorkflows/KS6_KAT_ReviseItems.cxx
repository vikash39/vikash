#include "KS6_KAT_ReviseItems.h"

using namespace Teamcenter;

int katReviseItems(EPM_action_message_t msg)
{	
	ResultStatus rStatus;
	try 
	{
		map<string, string> mArguments;
		map<string, string> mDatasetCopyOptions;
		rStatus = processArguments(msg, mArguments, mDatasetCopyOptions);	

		//Get the root task tag
		tag_t tRootTask = NULLTAG;
		rStatus = EPM_ask_root_task(msg.task, &tRootTask);

		//Ask the attachments
		int iAttachmentCount = 0;
		tag_t* tpAttachments = NULL;
		int iAttachmentType = tc_strcasecmp( mArguments.find(ATTACHMENT)->second.c_str(), REFERENCE) == 0 ? EPM_reference_attachment : EPM_target_attachment;
		rStatus = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iAttachmentCount, &tpAttachments);

		tag_t tItemRevisionType = NULLTAG;
		rStatus = TCTYPE_find_type(ITEMREVISION, ITEMREVISION, &tItemRevisionType);
		
		for (int i = 0; i < iAttachmentCount; i++)
		{
			char* cpObjectType = NULL;
			rStatus = WSOM_ask_object_type2(tpAttachments[i], &cpObjectType);

			tag_t tObjectType = NULLTAG;
			rStatus = TCTYPE_find_type(cpObjectType, NULL, &tObjectType);

			bool bValidType = false;
			rStatus = TCTYPE_is_type_of(tObjectType, tItemRevisionType, &bValidType);

			if (bValidType) 
			{
				tag_t tRevisedObject = NULL;
				rStatus = revise(tpAttachments[i], tRevisedObject);

				if (mArguments.find(ASSIGN_TO_PROJECT) != mArguments.end() && mArguments.find(ASSIGN_TO_PROJECT)->second == "True")
				{
					rStatus = assignProjects(tpAttachments[i], tRevisedObject);
				}

				rStatus = processRelatedObjects(tpAttachments[i], tRevisedObject, mDatasetCopyOptions);
			}
			else
			{
				scoped_smptr<char> objectName;
				rStatus = AOM_ask_value_string(tpAttachments[i], "object_name", &objectName);
				TC_write_syslog("KAT_revise_items: WARNING: Attached object %s is not Item revision.\n", objectName.get());
			}
		}
	}
	catch (const IFail& ex)
	{
		TC_write_syslog("Error in KAT-revise-items handler. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return ITK_ok;
}

int processArguments(EPM_action_message_t msg, map<string, string> &mArguments, map<string, string> &mDatasetCopyOptions)
{
	int iStatus;

	char* cpArgValue = NULL;
	char* cpTypeArg = NULL;
	char* cpValue = NULL;

	//Loop through all the arguments and push them into a map
	//Since all the arguments are optional, if any one of them is not provided then it will not be added to map
	while ((cpArgValue = TC_next_argument(msg.arguments)) != NULL)
	{
		iStatus = ITK_ask_argument_named_value(cpArgValue, &cpTypeArg, &cpValue);
		if (cpValue != NULL)
		{
			string sTypeArg(cpTypeArg);
			transform(sTypeArg.begin(), sTypeArg.end(), sTypeArg.begin(), ::tolower);

			string sValue(cpValue);		

			mArguments.insert(pair<string, string>(sTypeArg, sValue));
		}
	}

	//Validate attachment argument and set it to default value in case if its not passed or contains invalid value
	string sAttachmentType = TARGET;
	if (mArguments.find(ATTACHMENT) != mArguments.end() )
	{		
		if (tc_strcasecmp(mArguments.find(ATTACHMENT)->second.c_str(), REFERENCE) == 0) 
		{
			sAttachmentType = REFERENCE;
		}		
	}	
	mArguments.at(ATTACHMENT) = sAttachmentType;

	//Validate assign to project argument and set it to default value in case if its not passed or contains invalid value
	string sAssignToProject = "True";
	if (mArguments.find(ASSIGN_TO_PROJECT) != mArguments.end() )
	{		
		if (tc_strcasecmp(mArguments.find(ASSIGN_TO_PROJECT)->second.c_str(), "False") == 0 || tc_strcasecmp(mArguments.find(ASSIGN_TO_PROJECT)->second.c_str(), "F") == 0) 
		{
			sAssignToProject = "False";
		}		
	}	
	mArguments.at(ASSIGN_TO_PROJECT) = sAssignToProject;
	

	if (mArguments.find(ATTACHED_DATASETS) != mArguments.end() && mArguments.find(COPY_OPTIONS) != mArguments.end())
	{
		string sDelimiter = getDelimiter();

		string sAttachedDatasets = mArguments.find(ATTACHED_DATASETS)->second;
		vector<string> vAttachedDatasets;
		split(sAttachedDatasets, sDelimiter[0], vAttachedDatasets);

		string sCopyOptions = mArguments.find(COPY_OPTIONS)->second;
		vector<string> vCopyOptions;
		split(sCopyOptions, sDelimiter[0], vCopyOptions);

		for (int i = 0; i < vAttachedDatasets.size(); i++)
		{
			string sCopyOption = NO_COPY;
			if( i < vCopyOptions.size() )
			{				
				if( tc_strcasecmp(vCopyOptions.at(i).c_str(), COPY_OBJECT) != 0 && tc_strcasecmp(vCopyOptions.at(i).c_str(), COPY_REFERENCE) != 0 )
				{
					sCopyOption = vCopyOptions.at(i);
					transform(sCopyOption.begin(), sCopyOption.end(), sCopyOption.begin(), ::tolower);
				}				
			}
			mDatasetCopyOptions.insert(pair<string, string>(vAttachedDatasets.at(i),sCopyOption));
		}
	}
	return iStatus;
}


string getDelimiter()
{
	string delimiter = ",";
	scoped_smptr<char> cPrefValue;
	PREF_ask_char_value(SEPARATOR_PREFERENCE, 0, &cPrefValue);

	if (tc_strcasecmp(cPrefValue.getString(), "") != 0)
	{
		delimiter = cPrefValue.getString();
	}

	return delimiter;
}


int split( string str, char delimiter, vector<string> &vResult ) 
{
	int iStatus = ITK_ok;

	std::stringstream ss( str ); // Turn the string into a stream.
	std::string tok;

	while( getline( ss, tok, delimiter ) )
	{
		vResult.push_back(tok);
	}

	return iStatus;
}

int revise(tag_t tSourceObject, tag_t &tRevisedObject)
{
	int iStatus = ITK_ok;
	//Get type tag
	tag_t tObjectType = NULLTAG;
	iStatus = TCTYPE_ask_object_type(tSourceObject,&tObjectType);

	//Get revise input
	tag_t tReviseInput = NULLTAG;
	iStatus = TCTYPE_construct_operationinput(tObjectType,TCTYPE_OPEARTIONINPUT_REVISE,&tReviseInput);               

	int iNumberObjects = 0;
	tag_t* tpDeepCopy = NULL;
	iStatus = TCTYPE_ask_deepcopydata(tSourceObject,TCTYPE_OPEARTIONINPUT_REVISE,&iNumberObjects,&tpDeepCopy);

	int* iFails = 0;
	tag_t* tRevisedObjects = NULL;
	iStatus = TCTYPE_revise_objects(1,&tSourceObject,&tReviseInput,&iNumberObjects,tpDeepCopy,&tRevisedObjects,&iFails );

	tRevisedObject = tRevisedObjects[0];

	return iStatus;
}

int assignProjects(tag_t tSourceObject, tag_t tTargetObject)
{
	int	iStatus = ITK_ok;
	ResultStatus rStatus;
	try
	{
		int iNoOfProjects = 0;
		int iProjCount    = 0;
		scoped_smptr<tag_t> tpProjects;
		rStatus = AOM_ask_value_tags( tSourceObject, "project_list", &iNoOfProjects, &tpProjects );
		
		if (iNoOfProjects>0 )
		{
			rStatus = PROJ_assign_objects( iNoOfProjects, tpProjects.get(), 1, &tTargetObject );
		}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in assignProjects function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return iStatus;
}



int processRelatedObjects(tag_t tSourceObject, tag_t tRevisedObject, std::map<std::string, std::string>  mDatasetCopyOptions)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try 
	{
		tag_t tRelationType = NULLTAG;
		rStatus = GRM_find_relation_type("IMAN_relation", &tRelationType);

		tag_t tDatasetType = NULLTAG;
		rStatus = TCTYPE_find_type("Dataset", NULL, &tDatasetType);

		int iSecondaryCount = 0;
		scoped_smptr<GRM_relation_t> tSecondaryGRMObjects;
		rStatus = GRM_list_secondary_objects(tSourceObject, tRelationType, &iSecondaryCount, &tSecondaryGRMObjects);

		for (int k = 0; k < iSecondaryCount; k++)
		{			
			tag_t tSecondaryObjType = NULLTAG;
			
			tag_t tObjectToCopy = tSecondaryGRMObjects[k].secondary;

			rStatus = TCTYPE_ask_object_type(tSecondaryGRMObjects[k].secondary, &tSecondaryObjType);

			logical isDataset;
			rStatus = TCTYPE_is_type_of(tSecondaryObjType, tDatasetType, &isDataset);

			//process only dataset
			if (isDataset)
			{
				string sCopyOption = NO_COPY;

				scoped_smptr<char> cSecondaryObjType;
				//get copy_option from map if dataset is present as key
				iStatus = AOM_ask_value_string(tSecondaryGRMObjects[k].secondary, "object_type", &cSecondaryObjType);
				std::map<std::string, std::string>::iterator it = mDatasetCopyOptions.find(cSecondaryObjType.getString());
				if (it != mDatasetCopyOptions.end())
				{
					sCopyOption = it->second;
				}

				if (tc_strcasecmp(sCopyOption.c_str(), COPY_OBJECT) == 0)
				{
					//save as object
					tag_t tSavedObject = NULLTAG;
					iStatus = saveAsObject(tSecondaryGRMObjects[k].secondary, tSavedObject);
					tObjectToCopy = tSavedObject;
				}

				//create relation
				if (tc_strcasecmp(sCopyOption.c_str(), COPY_OBJECT) == 0 || tc_strcasecmp(sCopyOption.c_str(), COPY_REFERENCE) == 0)
				{
					tag_t tRelation = NULLTAG;
					iStatus = GRM_create_relation(tRevisedObject, tObjectToCopy, tSecondaryGRMObjects[k].relation_type, NULLTAG, &tRelation);
					iStatus = GRM_save_relation(tRelation);
				}
			}
		}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in processRelatedObjects function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return iStatus;
}

int saveAsObject(tag_t tInput, tag_t &tSavedObject) 
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	
	try 
	{
		tag_t tObjectType = NULLTAG;
		rStatus = TCTYPE_ask_object_type(tInput, &tObjectType);

		tag_t tSaveAsInput = NULLTAG;
		rStatus = TCTYPE_construct_saveasinput(tObjectType, &tSaveAsInput);

		int iDeepCopyCount = 0;
		scoped_smptr<tag_t> tDeepcopyData;
		rStatus = TCTYPE_ask_deepcopydata(tInput,TCTYPE_OPERATIONINPUT_SAVEAS, &iDeepCopyCount, &tDeepcopyData);

		rStatus = TCTYPE_saveas_object(tInput, tSaveAsInput, iDeepCopyCount, tDeepcopyData.get(), &tSavedObject);
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in saveAsObject function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return iStatus;
}