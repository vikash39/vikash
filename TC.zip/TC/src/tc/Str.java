/**
 * 
 */
package tc;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

/**
 * @author Vinothkumar Arthanari
 *		   Jan 21, 2013
 */
@SuppressWarnings("unchecked")
public class Str   {
	public static final String TC_DATE_FORMAT = "dd-MMM-yyyy HH:mm:ss";
	public static String getFirst(String str){
		return getFirst(str,",");
	}
	
	public static String getLast(String str){
		return getLast(str,",");
	}
	public static String getLastLast(String str){
		return getLastLast(str,",");
	}
	
	public static String getFirst(String str, String sIndex){

		if(str.contains(sIndex))
			return str.substring(0,str.indexOf(sIndex));
		else
			return str ;
	}
	
	public static String getLast(String str, String sIndex){
		if(str.contains(sIndex))
			return str.substring(str.indexOf(sIndex)+1);
		else
			return str ;
	}
	public static String getLastLast(String str, String sIndex){
		if(str.contains(sIndex))
			return str.substring(str.lastIndexOf(sIndex)+1);
		else
			return str ;
	}
	
	public static ArrayList<String> getList(String[] array){
		ArrayList<String> list = new ArrayList<String>();
		Collections.addAll(list, array);
		return list;
	}
	public static ArrayList<String> getList(String str){
		return getList(str,",");
	}

	public static ArrayList<String> getList(String str,String sIndex){
		ArrayList<String> list = new ArrayList<String>();
		if(str == null)
			return null;
		StringTokenizer strTok = new StringTokenizer(str,sIndex);
		while(strTok.hasMoreTokens())
			list.add(strTok.nextToken().trim());
		return list;
	}
	
	
	public static String[] toArray(String str){
		return toArray(str,",");
	}
	
	public static String[] toArray(String str, String sIndex){
		ArrayList<String> list = getList(str,sIndex);
		return toArray(list);
	}
	
	public static String[] toArray(ArrayList<String> list){
		return list.toArray(new String[list.size()]);
	}
	
	public static String getNumericStringVal(String paramString1){

			return getNumericStringVal(paramString1,"0") ;
	}
	
	public static String getNumericStringVal(String paramString1,String paramString2){
		try{
			String res = "";
			paramString1 = paramString1.replaceAll(",", ".");
			char[] tmp = paramString1.trim().toCharArray();
			for(int i = 0; i< tmp.length ; i++){
				if(Character.isDigit(tmp[i]))
					res += tmp[i];
				else if(tmp[i] == '.')
					res += tmp[i];
				else if(i ==0 && (tmp[i] == '+' || tmp[i] == '-'))
					res += tmp[i];
				else break;
			}
			//System.out.println(res);
			return res.trim();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return paramString2.trim();
	}
	
	public static String getNumberFormat(int patternCnt,int paternCntEr){
		if(patternCnt == -1)
			patternCnt = paternCntEr;
		String pattern ="#";
		for(int i = 0; i< patternCnt ; i++){
			if(i == 0)
				pattern += ".";
			pattern += "#";
		}
		
		return pattern;
	}
	public static String getRoundOffValue(double dod){
		return getRoundOffValue(dod,"#.###");
	}
  
	public static String getRoundOffValue(double dod,String format){
		String str = String.valueOf(dod);
		try{
				DecimalFormat df = new DecimalFormat(format);
				str = String.valueOf(df.format(dod));
				return str ;
		}catch (Exception e) {}
		return String.valueOf(dod);
	}

	public static String getCurrentDate(boolean time) {
	   String str = "dd-MM-yyyy";
	   if(time)
		   str = "dd-MMM-yyyy HH:mm:ss" ;
	    SimpleDateFormat sdfDate = new SimpleDateFormat(str,Locale.ENGLISH);
	    String strDate = sdfDate.format(new Date());
	    return strDate;
	}
	
	public static double getDouble(String paramString){
		
		return getDouble(paramString,0);
	}

	public static double getDouble(String paramString, double paramDouble) {
		String str = getNumericStringVal(paramString);
		try{
			return Double.valueOf(str).doubleValue() ;
		}catch (Exception e) {}
		return paramDouble ;
	}
	
	public static int getInt(String paramString){
		
		return getInt(paramString,0);
	}

	public static int getInt(String paramString, int paramInt) {
		String str = getNumericStringVal(paramString);
		try{
			return Integer.valueOf(str).intValue() ;
		}catch (Exception e) {}
		return paramInt ;
	}
	
	public static String getFormatedString(String error,Object str){
		try{
			if(str instanceof Object[])
				return MessageFormat.format(error,(Object[]) str);
			return MessageFormat.format(error,str);
		}catch (Exception e) {}
		return error;
	}
	
	
	public static ArrayList<String> clone(ArrayList<String> list){
		return (ArrayList<String>) list.clone();
	}
	
	public static ArrayList subList(ArrayList list,int startInd, int endInd){
		ArrayList list1 = new ArrayList();;
		for (int i = startInd; i< endInd && i < list.size(); i++) {
			list1.add(list.get(i));
		}
		return list1; 
	}
	
	public static String getRunningNoString(String str,int length){
		for(int i = str.length() ; i< length ; i++)
	 			str = "0"+str;
		return str;
	}
	
	public static void deleteFile(String filePath){
		deleteFile(new File(filePath));
	}
	public static void deleteFile(File paramFile){
		try {
			if(!paramFile.exists())
				return;
			if(paramFile.isDirectory()){
				File[] files = paramFile.listFiles();
			    for (File file : files) 
			    	  deleteFile(file);
			    paramFile.delete();
			}else
				paramFile.delete();
		} catch (Exception e) {
			System.out.println("Exception in CreateBTPDataset.delDir()");
			e.printStackTrace();

		}
		
		
	
	}

	public static String getTempDir() {
		return System.getProperty("java.io.tmpdir");
		
	}

	public static boolean isTrue(String str){
		if(str.equalsIgnoreCase("Yes"))
			return true;
		else if(str.equalsIgnoreCase("Y"))
			return true;
		else if(str.equalsIgnoreCase("1"))
			return true;
		else if(str.equalsIgnoreCase("True"))
			return true;
		return false;
	}

	public static void open(String filePath) throws IOException {
		Desktop.getDesktop().open(new File(filePath));
		
		
	}
}


