package tc;

import java.io.File;

import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.util.MessageBox;

/**
 * @author Vinothkumar Arthanari
 *		   Mar 20, 2013
 */

public class PropertyPath {

	public static final boolean DEBUG = false; 
	public static String getPropertyFilePath(){
		return getPropertyFilePath(DEBUG);
	}
	public static String getTcDataPath(){
		return getTcDataPath(false);
	}
	public static String getPropertyFilePath(boolean isDebug){
		return getPropertyFilePath(isDebug,true);
	}
	public static String getTcDataPath(boolean isDebug){
		return getPropertyFilePath(isDebug,false);
		
	}
	public static String getPropertyFilePath(boolean isDebug, boolean isIncludeProp){
		
		try {
		
			TCSession  session = (TCSession)AIFUtility.getCurrentApplication().getSession();
			String tcData = session.getPreferenceService().getString(0, "TC_DATA_DIR");
			//session.getPreferenceService().setS
			File file = new File(tcData);
			if(!file.exists() || isDebug)
				tcData = "C:\\SOFT\\MPLM";
			if(isIncludeProp)
				tcData += "\\Properties\\";
			return tcData;
		} catch (Exception ex) {
			ex.printStackTrace();
			MessageBox.post(ex.getMessage(), "Error", 1);
		}
		return null;
	}
	
		
}
