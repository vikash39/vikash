/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           UpdateDBBOM.java          
#      Module          :           sample          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           infodba          
#  =================================================================================================                    
#  Date                   Name           				Description of Change
#  Aug 8, 2017				  Vinothkumar Arthanari			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package tc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import util.Str;
import util.TC;

import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCException;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class UpdateDBBOM {

	/**
	 * 
	 */
	ArrayList<ArrayList<String>> lst_mm_values;
	ArrayList<ArrayList<String>> lst_bom_values;
	ArrayList<String> lst_mm_col = Str.getList("ItemID_RevID,Item_ID,Revision_ID,ObjectName,OwningUser,Release_Status,Object_Type,Part_Status,PROJECT_EXCLUSIVEPART");
	ArrayList<String> lst_bom_col = Str.getList("Parent_Trace_Link,ItemID_RevID,Item_ID,Revision_ID,Childrens,object_name,Release_Status,object_type");
	public UpdateDBBOM() {
		try {
			lst_mm_values = new ArrayList<ArrayList<String>>();
			lst_bom_values = new ArrayList<ArrayList<String>>();
			TCComponentItemRevision rev = (TCComponentItemRevision) AIFUtility.getCurrentApplication().getTargetComponent();
			TCComponentBOMLine line = TC.getBomLine(rev);
			startItteration(line);
			line.window().close();
			try {
				for(int i = 0; i< lst_mm_values.size() ; i++)
					try {
						
						DBConnection.execute("Part_Details", lst_mm_col,lst_mm_values.get(i));
					} catch (Exception e) {
						e.printStackTrace();
					}
				for(int i = 0; i< lst_bom_values.size() ; i++)
					try {
						DBConnection.execute("PARENT_CHILD", lst_bom_col,lst_bom_values.get(i));
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param tc_parent
	 * @throws TCException 
	 */
	private void startItteration(TCComponentBOMLine tc_parent) throws TCException {
		AIFComponentContext[] arr_child = tc_parent.getChildren();
		loadinformation(tc_parent,arr_child);
		for(int i = 0; i< arr_child.length; i++){
			TCComponentBOMLine tc_line = (TCComponentBOMLine)arr_child[i].getComponent();
			loadMMValues(tc_line);
			if(tc_parent.hasChildren())
				startItteration(tc_line);
		}
	}

	/**
	 * @param tc_line
	 * ItemID_RevID,Item_ID,Revision_ID,ObjectName,OwningUser,Release_Status,Part_Status,Object_Type
	 * @throws TCException 
	 * ArrayList<String> lst_mm_col = Str.getList("ItemID_RevID,Item_ID,Revision_ID,ObjectName,OwningUser,Release_Status,Object_Type,Part_Status,PROJECT_EXCLUSIVEPART");
	
	 */
	private void loadMMValues(TCComponentBOMLine tc_line) throws TCException {
		TCComponent tc_rev = TC.getRevision(tc_line);
		ArrayList<String> lst_val = new ArrayList<String>();
		lst_val.add(TC.getIdandRev(tc_rev));
		lst_val.add(TC.getId(tc_rev));
		lst_val.add(TC.getRevId(tc_rev));
		
		lst_val.add(TC.getName(tc_rev));
		lst_val.add(tc_rev.getProperty("owning_user"));
		lst_val.add(tc_rev.getProperty("release_status_list"));
		lst_val.add(tc_rev.getProperty("oject_type"));
		
		TCComponent rev_mas = TC.getMasterTag(tc_rev,false);
		lst_val.add(rev_mas.getProperty("f2_New_Modified"));
		lst_val.add(rev_mas.getProperty("f2_Project_Migration"));
		
		lst_mm_values.add(lst_val);
	}

	/**
	 * @param arr_child 
	 * @param tc_parent 
	 * @throws TCException 
	 * Parent_Trace_Link,ItemID_RevID,Item_ID,Revision_ID,Childrens,object_name,owning_user,Release_Status,object_type
	 * ArrayList<String> lst_bom_col = Str.getList("Parent_Trace_Link,ItemID_RevID,Item_ID,Revision_ID,Childrens,object_name,Release_Status,object_type");
	 */
	private void loadinformation(TCComponentBOMLine tc_parent, AIFComponentContext[] arr_child) throws TCException {
		String str_child = ""; 
	
		for(int i = 0; i< arr_child.length; i++){
			TCComponentBOMLine tc_line = (TCComponentBOMLine)arr_child[i].getComponent();
			str_child +=TC.getIdandRev(tc_line)+",";
		}
		if(str_child.trim().isEmpty())
			return;
		str_child  = str_child .substring(0, str_child.length()-1);
		ArrayList<String> lst_val = new ArrayList<String>();
		lst_val.add(TC.getIdandRev(tc_parent));
		lst_val.add(TC.getIdandRev(tc_parent));
		
		lst_val.add(TC.getId(tc_parent));
		lst_val.add(TC.getRevId(tc_parent));
		lst_val.add(str_child);
		lst_val.add(TC.getName(tc_parent));
		lst_val.add(tc_parent.getProperty("bl_rev_release_status_list"));
		lst_val.add(tc_parent.getProperty("bl_item_object_type"));
		lst_bom_values.add(lst_val);
	}


}
