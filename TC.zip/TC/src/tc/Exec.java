/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           Exec.java          
#      Module          :           tc          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Mar 8, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package tc;

import java.util.Hashtable;
import java.util.Map;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;

import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.explorer.common.TCComponentSearch;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.services.IPropertyPolicyService;
import com.teamcenter.rac.search.ui.TcSearchUI;
import com.teamcenter.rac.search.views.SearchView;
import com.teamcenter.rac.util.OSGIUtil;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.rac.cad.StructureManagementService;
import com.teamcenter.services.rac.cad._2008_03.StructureManagement.AskChildPathBOMLinesInfo;
import com.teamcenter.services.rac.cad._2008_03.StructureManagement.AskChildPathBOMLinesPath;
import com.teamcenter.services.rac.cad._2013_05.StructureManagement.AskChildPathBOMLinesResponse2;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateIn2;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateInput2;
import com.teamcenter.soa.client.ObjectPropertyPolicyManager;

import cmvr.CMVRTemplateCreation;
import rga.ORCManipulation;
import rga.ORCSearch;

/**
 * @author Administrator
 *
 */
public class Exec extends AbstractHandler {

	/* (non-Javadoc)
	 * @see org.eclipse.core.commands.IHandler#execute(org.eclipse.core.commands.ExecutionEvent)
	 */
	
	TCSession session = (TCSession) AIFUtility.getCurrentApplication().getSession();
	@Override
	public Object execute(ExecutionEvent arg0) throws ExecutionException {
	//	TCComponentItem item = (TCComponentItem) AIFUtility.getCurrentApplication().getTargetComponent();
		//new UpdateDBBOM();
		try {
			/*TCComponent[] ref_prop = item.getReferenceListProperty("m2_base_parameter");
			String str_idx = ref_prop[0].getProperty("fnd0RowIndex");
			ref_prop[1].setIntProperty("fnd0RowIndex",2);
			System.out.println(str_idx);*/
			//createTableProp();
			
			/* IPropertyPolicyService localIPropertyPolicyService1 = (IPropertyPolicyService)OSGIUtil.getService(Activator.getDefault(), IPropertyPolicyService.class);
			 ObjectPropertyPolicyManager localObjectPropertyPolicyManager = session.getSoaConnection().getObjectPropertyPolicyManager();
			 System.out.println(localIPropertyPolicyService1);*/
			//getChildOCC();
			//new CMVRTemplateCreation().readExcelBook();
			//createTableProp2();
			//in.dataToBeRelated
			//loadSearch();
			new ORCManipulation();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public void getChildOCC(){
		TCComponentBOMLine tc_line = (TCComponentBOMLine) AIFUtility.getCurrentApplication().getTargetComponent();
		try {
			System.out.println(tc_line.getProperties());
		} catch (TCException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		StructureManagementService serv = StructureManagementService .getService(session);
		AskChildPathBOMLinesPath[] childPath = new AskChildPathBOMLinesPath[1];
		childPath[0] = new AskChildPathBOMLinesPath();
		childPath[0].childPath=new String[]{"QVep8T0Ka3g7tA"};//QlVpo1oba3g7tAQlXpo1oba3g7tA
		childPath[0].clientId="12";
		AskChildPathBOMLinesInfo[] askChildBomPath = new AskChildPathBOMLinesInfo[1];
		askChildBomPath[0] = new AskChildPathBOMLinesInfo();
		askChildBomPath[0].parentBomLine = tc_line;
		askChildBomPath[0].childPaths = childPath;
		askChildBomPath[0].useAsStable = true;
		askChildBomPath[0].clientId="test";
		AskChildPathBOMLinesResponse2 resp = serv.askChildPathBOMLines2(askChildBomPath );
		com.teamcenter.rac.kernel.ServiceData srvData = resp.serviceData;
		
		Map out = resp.output;
		System.out.println("Out:"+out);
	}

	
	private void createTableProp2() {
		
		//
		CreateInput tab_inp = new CreateInput();
		tab_inp.boName = "M2_CMVR_PARAMATERS";
		tab_inp.stringProps.put("m2_configuration", "config");
		
		CreateInput inp = new CreateInput();
		inp.boName = "M2_MM_CMVR_OSDM";
		inp.stringProps.put("item_id", "000286");
		inp.stringProps.put("object_name", "TEST");
		//inp.compoundCreateInput.put("m2_base_parameter",new CreateInput[]{tab_inp});
		
		CreateIn in = new CreateIn();
        in.clientId = "A";
        in.data  = tab_inp;
        
        DataManagementService dm_serv = DataManagementService.getService(session);
        try {
			CreateResponse localObject2 = dm_serv.createObjects(new CreateIn[]{in});
			System.out.println(localObject2.output[0].objects[0].getUid());
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	private void createTableProp() {
		TCComponentItem item = (TCComponentItem) AIFUtility.getCurrentApplication().getTargetComponent();
		Hashtable<String, String[]> map_prop = new Hashtable<>();
		map_prop.put("m2_configuration", new String[] {"m2_configuration"});
		map_prop.put("m2_value", new String[] {"m2_value"});
		map_prop.put("fnd0RowIndex", new String[] {"2"});
		map_prop.put("m2_group", new String[] {"m2_group"});
		CreateInput2 inp_prop = new CreateInput2();
		inp_prop.boName = "M2_CMVR_PARAMATERS";
		inp_prop.propertyNameValues = map_prop;
		CreateIn2 in_create = new CreateIn2();
		in_create.clientId = "A";
		in_create.pasteProp = "m2_base_parameter";
		in_create.targetObject = item;
		in_create.createData = inp_prop;
		DataManagementService dm_serv = DataManagementService.getService(session);
		
		CreateResponse localCreateResponse = dm_serv.createRelateAndSubmitObjects2(new CreateIn2[] { in_create});
		System.out.println(localCreateResponse.output.length);
		
	}

	/**
	 * @throws TCException 
	 * @throws PartInitException 
	 * 
	 */
	private void loadSearch() throws TCException, PartInitException {
		TCComponentQueryType tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
	     TCComponentQuery tccomponentquery = (TCComponentQuery)tccomponentquerytype.find("Item...");//MM_Vehicle_Benchmark
	     
		TCComponentSearch search = new TCComponentSearch(tccomponentquery);
		search.setCrieria(new String[] {"Item ID"}, new String[] {"000*"});
		 /*IWorkbenchWindow localIWorkbenchWindow = AIFUtility.getActiveDesktop().getDesktopWindow();
		    IWorkbenchPage localIWorkbenchPage = localIWorkbenchWindow.getActivePage();
		    IViewPart localIViewPart = localIWorkbenchPage.findView("com.teamcenter.rac.search.views.SearchView");
		    
		      if (localIViewPart != null) {
		        localIWorkbenchPage.bringToTop(localIViewPart);
		      } else {
		        localIViewPart = localIWorkbenchPage.showView("com.teamcenter.rac.search.views.SearchView");
		      } 
		      SearchView a = (SearchView) localIViewPart;
		      a.loadQuery(tccomponentquery);*/
		TcSearchUI.getInstance().openComponentSearch(search);		
	}

}
