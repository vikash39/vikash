package tc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DBConnection {

	private static Connection conn;
	private static final String URL 		= "jdbc:oracle:thin:@//192.168.2.36:1521/tcdb";
	private static final String USER_ID 	= "tc_fduser";
	private static final String PASSWORD 	= "tc_fduser" ;
	
	private static final String sForNameDriver = "oracle.jdbc.driver.OracleDriver";
	
	public static Connection getConnection() throws SQLException, Exception {
//		if(conn == null)
		if (conn == null || conn.isClosed()) {
			Class.forName(sForNameDriver);
			conn = DriverManager.getConnection(URL,USER_ID,PASSWORD);
		}
		conn.setAutoCommit(false);
//		if(conn == null)
//			conn = DriverManager.getConnection(URL,USER_ID,PASSWORD);
		return conn;
	}
	//public static void createConnect
	public void closeConnection(Connection dbConn) throws SQLException {
			conn = null;
			dbConn.close();
		
		
	}
	
	public static ResultSet execute(String str_stmt_to_exec) throws Exception{
		ResultSet rsProcessList = getConnection().createStatement().executeQuery(str_stmt_to_exec);
		return rsProcessList;
	}
	public static ResultSet execute(String str_table, ArrayList<String> lst_db_name, ArrayList<String> lst_db_val) throws Exception{
		int iIdIdx = lst_db_name.indexOf("SBC_BIW_PARTNO");
		int iRevIdx = lst_db_name.indexOf("SBC_BIW_REV");
		String str_qry_inp = "";
		str_qry_inp = insertStmt(str_table,lst_db_name, lst_db_val);
		ResultSet rsProcessList = getConnection().createStatement().executeQuery(str_qry_inp);
		return rsProcessList;
	}
	public static ResultSet retrive(ArrayList<String> lst_db_name,String itemId,String revId) throws SQLException{
//		int iIdIdx = lst_db_name.indexOf("SBC_BIW_PARTNO");
//		int iRevIdx = lst_db_name.indexOf("SBC_BIW_REV");
		String str_qry_inp = "";
		if(isExists(itemId,revId))
			str_qry_inp = retriveStmt(lst_db_name,itemId,revId);	
		ResultSet rsProcessList = null;
		//		else
//			str_qry_inp = insertStmt(lst_db_name, lst_db_val);
		if(!str_qry_inp.isEmpty())
			rsProcessList = conn.createStatement().executeQuery(str_qry_inp);
		return rsProcessList;
	}
	private static String retriveStmt(ArrayList<String> lst_db_name,String itemId, String revId) {
		String str_qry_inp = "SELECT ";
		for (int i = 0; i < lst_db_name.size(); i++) {
			str_qry_inp +=lst_db_name.get(i)+",";
		}
		if(str_qry_inp.endsWith(","))
			str_qry_inp = str_qry_inp.substring(0, str_qry_inp.length()-1);
		str_qry_inp += " from SBC_BIW where SBC_BIW_PARTNO = '"+itemId+"' and SBC_BIW_REV= '"+revId+"'";
		
		return str_qry_inp;
	}
	private static String insertStmt(String str_table ,ArrayList<String> lst_db_name, ArrayList<String> lst_db_val){
		String str_qry_inp = "INSERT INTO "+str_table+" (";
		for (int i = 0; i < lst_db_name.size(); i++) {
			str_qry_inp +=lst_db_name.get(i)+",";
		}
		if(str_qry_inp.endsWith(","))
			str_qry_inp = str_qry_inp.substring(0, str_qry_inp.length()-1);
		str_qry_inp += ") VALUES (";
		for (int i = 0; i < lst_db_val.size(); i++) {
			str_qry_inp +="'"+lst_db_val.get(i)+"',";
		}
		if(str_qry_inp.endsWith(","))
			str_qry_inp = str_qry_inp.substring(0, str_qry_inp.length()-1);
		str_qry_inp += ")";
		return str_qry_inp;
	}
	private static String updateStmt(ArrayList<String> lst_db_name, ArrayList<String> lst_db_val, int iIdIdx, int iRevIdx){
		String str_qry_inp = "UPDATE SBC_BIW SET  ";
		for (int i = 0; i < lst_db_name.size(); i++) {
			
			str_qry_inp +=lst_db_name.get(i)+"= '"+lst_db_val.get(i)+"',";
		}
		if(str_qry_inp.endsWith(","))
			str_qry_inp = str_qry_inp.substring(0, str_qry_inp.length()-1);
		str_qry_inp +="WHERE "+lst_db_name.get(iIdIdx) +" = '"+lst_db_val.get(iIdIdx) +"' and "+lst_db_name.get(iRevIdx) +" = '"+lst_db_val.get(iRevIdx) +"'";
		return str_qry_inp;
	}
	private static boolean isExists(String str_id, String str_rev) throws SQLException {
		String str_qry_inp = "select SBC_BIW_PARTNO from SBC_BIW where SBC_BIW_PARTNO = '"+str_id+"' and SBC_BIW_REV= '"+str_rev+"'";
		ResultSet rsProcessList = conn.createStatement().executeQuery(str_qry_inp);
		if(rsProcessList.next())
			return true;
		return false;
	}

	
}
