/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           ConfMat.java          
#      Module          :           tc1          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Mar 15, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package tc;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Set;

import util.Str;

/**
 * @author Administrator
 *
 */
public class ConfMat {

	Hashtable<String, ArrayList<String>> map_parent_child;
	Hashtable<String, ItemInfo> map_item_info;
	private String str_project;
	private HashSet<String> set_model;
	
	
	public static void main(String[] args) {
		String[] arr_model_code = {"YUNXT PLATFORM-EBOM-YU1/002",
				"YUNXT PLATFORM-EBOM-YU4/001",
				"YUNXT PLATFORM-EBOM-YU3/001",
				"YUNXT PLATFORM-EBOM-YU2/002",
		"YUNXT PLATFORM-EBOM-YU5/001"};
		ArrayList<String> lst_ids = new ArrayList<>();
		Collections.addAll(lst_ids, arr_model_code);
		new ConfMat("YUNXT PLATFORM-EBOM-YU1/002",lst_ids);
	}
	
	/**
	 * @param lst_ids 
	 * @param str_base 
	 * 
	 */
	LinkedHashMap<String, LinkedHashMap<String, Integer>> map_ex_matrix;
	public ConfMat(String str_base, ArrayList<String> lst_ids) {

		//String str_base = "YUNXT PLATFORM-EBOM-YU1/002";
		str_project = "YUD1";
		String str_to_execute = "select itemid_revid, item_id, revision_id, childrens from parent_child where ItemID_RevID = 'YUNXT PLATFORM-EBOM-YU1/002' or ItemID_RevID = 'YUNXT PLATFORM-EBOM-YU4/001' or ItemID_RevID = 'YUNXT PLATFORM-EBOM-YU3/001' or ItemID_RevID = 'YUNXT PLATFORM-EBOM-YU2/002' or ItemID_RevID = 'YUNXT PLATFORM-EBOM-YU5/001'";
		try {
			map_ex_matrix = new LinkedHashMap<>();
			set_model = new HashSet<>(); 
			set_model.addAll(lst_ids);
			
			map_parent_child = new Hashtable<String, ArrayList<String>>();
			map_item_info = new Hashtable<>();
			HashSet<String> lst_agg = getParentChildinfo(set_model);
			HashSet<String> lst_phant = getParentChildinfo(lst_agg);
			HashSet<String> lst_part = getParentChildinfo(lst_phant);
			
			HashSet<String> set_all_item = new HashSet<>(); 
			Set<String> set_parent = map_parent_child.keySet();
			for (String string : set_parent) {
				set_all_item.addAll(map_parent_child.get(string));
			}
			loadItemInfo(set_all_item);
			System.out.println(map_parent_child);
			System.out.println(map_item_info);
			loadExclusiveMatrix(str_base);
			//process(str_base);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	
	}

	/**
	 * @param str_base
	 */
	private void loadExclusiveMatrix(String str_base) {
		
		setExclusiveInfo(str_base);
		for (String string : set_model) {
			if(!string.equalsIgnoreCase(str_base))
				setExclusiveInfo(string);
		}
		 
		
		map_ex_matrix.put(str_base, calculateExclusiveinfo(str_base));
		for (String string : set_model) {
			if(!string.equalsIgnoreCase(str_base))
				map_ex_matrix.put(string, calculateExclusiveinfo(string));
		}
		for (String string : map_ex_matrix.keySet()) {
			System.out.println(string+"::"+map_ex_matrix.get(string));
		}
	}
	public LinkedHashMap<String, LinkedHashMap<String, Integer>> getExclusiveMatrix(){
		return map_ex_matrix;
	}
	

	/**
	 * @param str_base
	 * @return 
	 */
	private LinkedHashMap<String, Integer> calculateExclusiveinfo(String str_model) {
		LinkedHashMap<String, Integer> map = new LinkedHashMap<>(); 
		ArrayList<String> lst_agg = getChildren(str_model);
		for (String string : lst_agg) {
			ArrayList<String> lst_phan = getChildren(string);
			for (String string2 : lst_phan) {
				ArrayList<String> lst_child = getChildren(string2);
				for (String string3 : lst_child) {
					ItemInfo item_info = map_item_info.get(string3);
					if(item_info!=null )
						if(item_info.str_model != null && !item_info.str_model.trim().isEmpty()) {
							Integer cnt = 0;
							if(map.get(item_info.str_model)!=null)
								cnt = map.get(item_info.str_model);
							cnt++;
							map.put(item_info.str_model, cnt);
						}
					
				}
			}
		}
		return map;
	}

	/**
	 * @param str_model
	 * @return
	 */
	private ArrayList<String> getChildren(String str_model) {
		ArrayList<String> lst_child = map_parent_child.get(str_model);
		if(lst_child == null)
			lst_child = new ArrayList<String>();
		return lst_child;
	}

	/**
	 * @param str_model
	 */
	private void setExclusiveInfo(String str_model) {
		ArrayList<String> lst_agg = getChildren(str_model);
		for (String string : lst_agg) {
			ArrayList<String> lst_phan = getChildren(string);
			for (String string2 : lst_phan) {
				System.out.println(string2+":"+string+":"+str_model);
				ArrayList<String> lst_child = getChildren(string2);
				for (String string3 : lst_child) {
					ItemInfo item_info = map_item_info.get(string3);
					if(item_info != null)
						item_info.setExclusive(str_model);
				}
			}
		}
		
	}

	/**
	 * @param lst_model 
	 * @return 
	 * @throws SQLException 
	 * 
	 */
	private HashSet<String> getParentChildinfo(HashSet<String> lst_model) throws Exception {
		String str_to_execute = "";
		for (String string : lst_model) {
			if(str_to_execute.trim().isEmpty())
				str_to_execute += "ItemID_RevID = '"+string+"'";
			else
				str_to_execute += " or ItemID_RevID = '"+string+"'";
		}
		
		str_to_execute = "select itemid_revid, childrens from parent_child where "+str_to_execute;
		ResultSet result_set = DBConnection.execute(str_to_execute);
		HashSet<String> lst_all_child = new HashSet<>();
		if(result_set!=null)
			
		while(result_set.next()) {
			//System.out.println(result_set.getString("itemid_revid")+"::"+result_set.getString("childrens"));
			ArrayList<String> lst_child = Str.getList(result_set.getString("childrens"));
			map_parent_child.put(result_set.getString("itemid_revid"), lst_child);
			lst_all_child.addAll(lst_child);
		}
		return lst_all_child;
	}
	private void loadItemInfo(HashSet<String> lst_item) throws Exception{
		String str_to_execute = "";
		for (String string : lst_item) {
			if(str_to_execute.trim().isEmpty())
				str_to_execute += "ItemID_RevID = '"+string+"'";
			else
				str_to_execute += " or ItemID_RevID = '"+string+"'";
		}
		
		
		str_to_execute = "select itemid_revid, part_status, project_exclusivepart from part_details where "+str_to_execute;
		ResultSet result_set = DBConnection.execute(str_to_execute);
		while(result_set.next()) {
			//System.out.println(result_set.getString("itemid_revid")+"::"+result_set.getString("childrens"));
			String str_id_rev = result_set.getString("itemid_revid");
			ItemInfo iteminfo = new ItemInfo(str_id_rev,result_set.getString("part_status"),result_set.getString("project_exclusivepart"));
			map_item_info.put(str_id_rev,iteminfo);
			
		}
		
	}
	
	
	class ItemInfo{
		String str_status 		= "";
		String str_exclusive 	= "";
		String str_id_rev;
		String str_model  ;
		/**
		 * @param string 
		 * 
		 */
		public ItemInfo(String str_id_rev,String str_status,String str_exclusive) {
			this.str_id_rev = str_id_rev;
			this.str_status = str_status;
			this.str_exclusive = str_exclusive ;
			str_model  = null;
			// TODO Auto-generated constructor stub
		}
		/**
		 * @param str_model2 
		 * 
		 */
		
		public void setExclusive(String str_model) {
			System.out.println(this);
			if(this.str_model != null)
				return;
			if(str_status == null || str_exclusive == null) {
				this.str_model = "";
				return;
			}
			if(str_status.equalsIgnoreCase("H") && str_exclusive.equalsIgnoreCase(str_project))
				this.str_model = str_model;
			else
				this.str_model = "";
			
		}
		/* (non-Javadoc)
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			
			return str_id_rev+":"+str_exclusive+","+str_status;
		}
	}

}
