package tc;

import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.IExecutionListener;
import org.eclipse.core.commands.NotHandledException;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.ui.handlers.IHandlerService;

import addnew.AddNewHandler;
import addnew.NewTableRowHandler;


public class EarlyStartup implements IStartup {


	@Override
	public void earlyStartup() {
		  final IHandlerService service = ( IHandlerService ) PlatformUI.getWorkbench().getService( IHandlerService.class );
	      final ICommandService commandService = ( ICommandService ) PlatformUI.getWorkbench().getService( ICommandService.class );
	      commandService.addExecutionListener(new IExecutionListener() {
			
			@Override
			public void preExecute(String id, ExecutionEvent event) {
				// TODO Auto-generated method stub
				if(id.equalsIgnoreCase("com.teamcenter.rac.newTableRow")){
					Command command = commandService.getCommand( id );
					NewTableRowHandler handler = new NewTableRowHandler();
                    command.setHandler(handler);
				} else if(id.equalsIgnoreCase("com.teamcenter.rac.newSchedule")){
					Command command = commandService.getCommand( id );
					
	                    
				}
			}
			
			@Override
			public void postExecuteSuccess(String arg0, Object arg1) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void postExecuteFailure(String arg0, ExecutionException arg1) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void notHandled(String arg0, NotHandledException arg1) {
				// TODO Auto-generated method stub
				
			}
		});
	        
	        
	}

}
