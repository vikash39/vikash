/**
 * 
 */
package tc;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.StringTokenizer;

import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.util.MessageBox;

/**
 * @author Vinothkumar Arthanari
 *		   Jan 18, 2013
 */

public class ReadProperty {

	/**
	 * 
	 */
	public Properties frmProperties ;
	public TCSession session ;
	private String fileName;

	public static boolean DEBUG; 
	public ReadProperty(String fileName) throws Exception{
		this.fileName			=	fileName ;
		DEBUG  					= PropertyPath.DEBUG ;
		initialize();
	}
	public ReadProperty(String fileName, boolean isDebug) throws Exception{
		this.fileName			=	fileName ;
		DEBUG					=	isDebug ; 
		initialize();
	}
	/**
	 * 
	 */
	public ReadProperty(Object obj) {
		try{
			System.out.println(obj.getClass().getName());
			String str = Str.getFirst(obj.getClass().getName(),".");
			if(str.equalsIgnoreCase("itemattributes_fd"))
				this.fileName = "ItemRevisionMasterForm";
			else if(str.equalsIgnoreCase("rollup"))	
				this.fileName = "RollUp";
			DEBUG  = PropertyPath.DEBUG ;
			if(fileName!=null && !fileName.trim().isEmpty())
				initialize();
		}catch (Exception e) {}
	}
	public void initialize() throws Exception{
		frmProperties 			= new Properties();
		session 				= (TCSession)AIFUtility.getCurrentApplication().getSession();
		loadProperty();
	}
	private void loadProperty() throws Exception{
		if(frmProperties==null || frmProperties.isEmpty()){
				frmProperties = getProperty(fileName);
		}
	}
	
	public Properties getProperty(String fileName) throws Exception{
		try {
			InputStream in ;
			String filePath ;
			if(fileName.contains("\\"))
				filePath = fileName;
			else
				filePath = PropertyPath.getPropertyFilePath(DEBUG)+fileName +".properties"; 
			in = new FileInputStream(filePath);
	
			frmProperties.load(in);
			in.close();
		} catch (FileNotFoundException e1) {
			MessageBox.post(e1.getMessage().toString(), "Error",MessageBox.ERROR);
			e1.printStackTrace();
			throw e1;
		} catch (IOException e1) {
			MessageBox.post(e1.getMessage().toString(), "Error",MessageBox.ERROR);
			e1.printStackTrace();
			throw e1;
		}
		return frmProperties;
	}
	public StringTokenizer getToken(String propType){
		return getToken(propType, ",");
	}
	public StringTokenizer getToken(String propType,String delimeter){
		//System.out.println(propType);
		String str = frmProperties.getProperty(propType);
		StringTokenizer strToken = new StringTokenizer(str,delimeter);
		return strToken ;
	}
	public ArrayList<String> getFrmProperties(String propType){
		return getFrmProperties(propType, ","); 	
	}
	public ArrayList<String> getFrmProperties(String propType,String tokenizer){
		try{
			if(!isExists(propType))
				return null;
			StringTokenizer strToken = getToken(propType);
			ArrayList<String> propName = new ArrayList<String>();
			while(strToken.hasMoreTokens())
				propName.add(strToken.nextToken(tokenizer));
			
			return propName;
		}catch (Exception e) {
			e.printStackTrace() ;
		}
		
		return null ;
	}	
	public boolean isExists(String paramString){
		return frmProperties.get(paramString) == null ? false : true;
	}

	public String getFirstString(String propType){
		if(getString(propType) == null)
			return null;
		return frmProperties.getProperty(propType).split(",")[0];
	}	
	public String getString(String propType){
		return frmProperties.getProperty(propType);
	}	
	public boolean isTrue(String propType){
		String str = frmProperties.getProperty(propType);
		if(str.equalsIgnoreCase("Yes"))
			return true;
		else if(str.equalsIgnoreCase("Y"))
			return true;
		else if(str.equalsIgnoreCase("1"))
			return true;
		else if(str.equalsIgnoreCase("True"))
			return true;
		return false;
	}	
	
	public int getInt(String propType){
		StringTokenizer strToken = getToken(propType);
		while(strToken.hasMoreTokens()){
			return Integer.valueOf(strToken.nextToken().trim()).intValue() ;
		}
		return -1;
	}	
	public double getDouble(String propType){
		StringTokenizer strToken = getToken(propType);
		while(strToken.hasMoreTokens()){
			return Double.valueOf(Str.getDouble(strToken.nextToken().trim(),-1.00)).doubleValue() ;
		}
		return -1.00;
	}	
	public boolean getBoolean(String propType){
		StringTokenizer strToken = getToken(propType);
		while(strToken.hasMoreTokens()){
			return Boolean.valueOf(strToken.nextToken().trim()).booleanValue();
		}
		return false;
	}	
	public Object getIntArray(String propType,int i){
		StringTokenizer strToken = getToken(propType);
		ArrayList<String> propName = new ArrayList<String>();
		/*int[] intVal = new int[strToken.countTokens()]; 
		double[] doubleVal = new double[strToken.countTokens()]; 
		float[] floatVal = new float[strToken.countTokens()]; */
		while(strToken.hasMoreTokens()){
			//if(i == 0)
				
			propName.add(strToken.nextToken(","));
		}
		return propName;
	}	
}

