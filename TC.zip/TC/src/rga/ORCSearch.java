/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           ORCSearch.java          
#      Module          :           tc          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - CMVR          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                   Name					        Description of Change
#  Aug 9, 2018				  Vinothkumar Arthanari			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;

import com.teamcenter.rac.kernel.TCComponent;

import util.TC;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class ORCSearch {

	/**
	 * @param log_hrs 
	 * 
	 */
	public ORCSearch(TraverseDailyLogHours log_hrs) {
		try {
		
			DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			ArrayList<TCComponent> lst_tc_qry = TC.getTcQuery("Item Revision...", new String[] {"Type"}, new String[] {"F2_MM_ORCRevision"});
			for (TCComponent tcComponent : lst_tc_qry) {
				TCComponent tc_master = TC.getMasterTag(tcComponent, false);
				String project = tc_master.getProperty("f2_Project_Name");
				Date date = tcComponent.getDateProperty("creation_date");
			    String created_date = formatter.format(date);
			    DailyLog log = log_hrs.map_overall.get(created_date);
			    if(log != null) {
			    	log.addNoOfORC();
			    }
			    
			    LinkedHashMap<String, DailyLog> map_proj = log_hrs.map_proj.get(project);
			    if(map_proj != null ) {
			    	DailyLog log1 = map_proj.get(created_date);
			    	if(log1!=null)
			    		log1.addNoOfORC();
			    }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
}
