/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           ORCManipulation.java          
#      Module          :           rga          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - CMVR          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                   Name					        Description of Change
#  Aug 9, 2018				  Vinothkumar Arthanari			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class ORCManipulation {

	/**
	 * 
	 */
	public ORCManipulation() {
		TraverseDailyLogHours log_hrs = new TraverseDailyLogHours();
		new ORCSearch(log_hrs);
		
		calculateCumulativeOrcs(log_hrs.map_overall);
		LinkedHashMap<String, LinkedHashMap<String, DailyLog>> map_proj = log_hrs.map_proj;
		for (Entry<String, LinkedHashMap<String, DailyLog>> entry : map_proj.entrySet()) {
			calculateCumulativeOrcs(entry.getValue());
		}
		calculateForChartData(log_hrs.map_overall);
		for (Entry<String, LinkedHashMap<String, DailyLog>> entry : map_proj.entrySet()) {
			calculateForChartData(entry.getValue());
		}
		System.out.println("Completed.");
	}

	/**
	 * @param map_overall
	 */
	private void calculateForChartData(LinkedHashMap<String, DailyLog> map_overall) {
		Set<Entry<String, DailyLog>> entryset = map_overall.entrySet();
		
		DailyLog log_last = null;
		double sumOfLogTi = 0;
		double sumOfLogMTBF = 0;
		
		for (Entry<String, DailyLog> entry : entryset) {
			DailyLog log = entry.getValue();
			log_last = log;
			
			double iCumulativeMtbf = log.getCumulativeHours()/log.getCumulativeORC();
			log.setCumulativeMtbf(iCumulativeMtbf);
			
			double logTI = Math.log(log.getCumulativeHours());
			log.setLogTI(logTI);
			
			double logMTBF  = Math.exp(iCumulativeMtbf);
			log.setLogMTBF(logMTBF);
			
			sumOfLogTi += logTI;
			sumOfLogMTBF += logMTBF;
		}
		if(log_last != null) {
			double growthrate = 0;
			double dFront  = 1/log_last.getCumulativeORC();
			double dBack =   sumOfLogMTBF-sumOfLogTi * growthrate;
			double dInpForExp = dFront*dBack;
			double dShapeFactor=Math.exp(dInpForExp);
			
		}
		
	}

	/**
	 * @param map_overall
	 */
	private void calculateCumulativeOrcs(LinkedHashMap<String, DailyLog> map_overall) {
		Set<Entry<String, DailyLog>> entryset = map_overall.entrySet();
		DailyLog log_prev = null;
		
		for (Entry<String, DailyLog> entry : entryset) {
			if(log_prev == null) {
				log_prev = entry.getValue();
				log_prev.setCumulativeORC(log_prev.getNoOfORC());
			}else {
				DailyLog log =  entry.getValue();;
				log.setCumulativeORC(log_prev.getCumulativeORC()+log.getNoOfORC());
				log_prev=log;
			}
		}

		
	}
}
