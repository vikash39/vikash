/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           DailyCount.java          
#      Module          :           rga          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - OffShoreDevelopment          
#      Author          :           Vinothkumar Arthanari          
#
#  =================================================================================================               
#  Revision History:     
#  =================================================================================================                    
#  Date            Name                       Description of Change
#  09-Aug-2018     Vinothkumar Arthanari      Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class DailyCount {

	String project;
	String tractor;
	int hours;
	
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getTractor() {
		return tractor;
	}
	public void setTractor(String tractor) {
		this.tractor = tractor;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	
}
