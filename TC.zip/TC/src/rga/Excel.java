/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           Excel.java          
#      Module          :           rga          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - OffShoreDevelopment          
#      Author          :           Vinothkumar Arthanari          
#
#  =================================================================================================               
#  Revision History:     
#  =================================================================================================                    
#  Date            Name                       Description of Change
#  09-Aug-2018     Vinothkumar Arthanari      Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

//import org.apache.poi.hssf.record.formula.eval.ErrorEval;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class Excel {

	public static Workbook getWorkbook(String filePath) throws FileNotFoundException, IOException {
		Workbook workBook = null;
			String ext = filePath.substring(filePath.lastIndexOf(".")+1);
			if(ext.equalsIgnoreCase("xls"))
				workBook = new HSSFWorkbook(new FileInputStream(filePath));
			/*else if (ext.equalsIgnoreCase("xlsx"))
				workBook = new XSSFWorkbook(new FileInputStream(filePath));*/
				
		return workBook;
		
	}
	 public static String getCellValue(Cell cell) {
	    if (cell == null) 
	        return "";
	    switch (cell.getCellType()) {
	        case Cell.CELL_TYPE_BLANK:
	            return "";
	        case Cell.CELL_TYPE_BOOLEAN:
	            return  cell.getBooleanCellValue()+"";
	        case Cell.CELL_TYPE_STRING:
	            return cell.getStringCellValue();
	        case Cell.CELL_TYPE_NUMERIC:
	           return isNumberOrDate(cell);
	        case Cell.CELL_TYPE_FORMULA:
	        {
	        	 String str_val = "";
	             switch (cell.getCachedFormulaResultType()) {
	             case Cell.CELL_TYPE_STRING:
	                 RichTextString str = cell.getRichStringCellValue();
	                 if (str != null && str.length() > 0) {
	                     str_val = str.toString();
	                 }
	                 break;
	             case Cell.CELL_TYPE_NUMERIC:
	                 CellStyle style = cell.getCellStyle();
	                 if (style == null) {
	                     str_val = cell.getNumericCellValue() + "";
	                 } else {
	                     DataFormatter _formatter = new DataFormatter();
	                     str_val = _formatter.formatRawCellContents(cell.getNumericCellValue(), style.getDataFormat(), style.getDataFormatString());
	                 }
	                 break;
	             case Cell.CELL_TYPE_BOOLEAN:
	                 str_val = cell.getBooleanCellValue() + "";
	                 break;
	             case Cell.CELL_TYPE_ERROR:
	                 //str_val = ErrorEval.getText(cell.getErrorCellValue());
	                 break;
	             }
	             return str_val;
	        }
	    }
	    return "";
	}
	 private static String isNumberOrDate(Cell cell) {
	    if (DateUtil.isCellDateFormatted(cell)) {
	        DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
	        return formatter.format(cell.getDateCellValue());
	    } else {
	        DataFormatter df = new DataFormatter();
	        return  df.formatCellValue(cell);
	    }
	} 
}
