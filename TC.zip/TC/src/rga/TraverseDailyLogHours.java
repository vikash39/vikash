/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           TraverseDailyLogHours.java          
#      Module          :           rga          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - OffShoreDevelopment          
#      Author          :           Vinothkumar Arthanari          
#
#  =================================================================================================               
#  Revision History:     
#  =================================================================================================                    
#  Date            Name                       Description of Change
#  09-Aug-2018     Vinothkumar Arthanari      Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class TraverseDailyLogHours {

	
	LinkedHashMap<String, DailyLog> map_overall;
	
	LinkedHashMap<String,LinkedHashMap<String, DailyLog>> map_proj;
	public static void main(String[] args) throws IOException, InterruptedException {
		
		
		
		new TraverseDailyLogHours();
		
	}
	
	/**
	 * 
	 */
	public TraverseDailyLogHours() {
		try {
			Workbook book = Excel.getWorkbook("C:\\Temp\\RGA\\RGA_DailyLogHours.xls");
			Sheet sheet = book.getSheetAt(book.getActiveSheetIndex());
			Row header_row = sheet.getRow(0);
			ArrayList<String> lst_dates = getDateList(header_row);
			LinkedHashMap<String, ArrayList<DailyCount>> map_date_cnt = new LinkedHashMap<>();
			HashSet<String> set_proj = new HashSet<>();
			for (Row row : sheet) {
				if(row.getRowNum() == 0)
					continue;
				String str_project = Excel.getCellValue(row.getCell(0));
				String str_tractor = Excel.getCellValue(row.getCell(1));
				set_proj.add(str_project);
				
				int iNo = header_row.getLastCellNum();
				for (Cell cell : row) {
					if(cell.getColumnIndex()<= 1) 
						continue;
					
					DailyCount cnt = new DailyCount();
					cnt.setProject(str_project);
					cnt.setTractor(str_tractor);
					int iHrs = 0;
					try {
						iHrs = Integer.valueOf(Excel.getCellValue(cell)).intValue();
					} catch (Exception e) {
						// TODO: handle exception
					}
					cnt.setHours(iHrs);
					String str_date = lst_dates.get(cell.getColumnIndex()-2);
					ArrayList<DailyCount> lst_daily_cnt  = map_date_cnt.get(str_date);
					if(lst_daily_cnt == null)
						lst_daily_cnt = new ArrayList<>();
					lst_daily_cnt.add(cnt);
					
					map_date_cnt.put(str_date, lst_daily_cnt);
					
				}
				
			}
			
			getOverAllDailyDetail(map_date_cnt,set_proj);
			//System.out.println(map_date_cnt);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * @param map_date_cnt
	 * @param set_proj 
	 */
	private void getOverAllDailyDetail(LinkedHashMap<String, ArrayList<DailyCount>> map_date_cnt, HashSet<String> set_proj) {
		
		map_overall = new LinkedHashMap<>();
		
		map_proj = new LinkedHashMap<>();
		
		Set<Entry<String, ArrayList<DailyCount>>> entryset = map_date_cnt.entrySet();
		for (Entry<String, ArrayList<DailyCount>> entry : entryset) {
			String date = entry.getKey();
			int iSumOfOverallHours = getOverallSumOfHours(entry.getValue());
			
			
			map_overall.put(date, getDailyLog(date, iSumOfOverallHours));
			for (String str_proj : set_proj) {
				int iSumOfHours = getSumOfHours(entry.getValue(),str_proj);
				LinkedHashMap<String, DailyLog> map_log = map_proj.get(str_proj);
				if(map_log == null)
					map_log = new LinkedHashMap<>();
				DailyLog log = map_log.get(date);
				if(log == null)
					log = getDailyLog(date, 0);
				log.setCumulativeHours(iSumOfHours);
				map_log.put(date, log);
				map_proj.put(str_proj, map_log);
			}
			
		}
		System.out.println(map_overall);
		for(String key: map_proj.keySet()) {
			System.out.println(key+":"+map_proj.get(key));
		}
		
	}
	private DailyLog getDailyLog(String date, int hours){
		DailyLog log = new DailyLog();
		log.setDate(date);
		log.setCumulativeHours(hours);
		return log;
	}
	/**
	 * @param value
	 * @param str_proj
	 * @return
	 */
	private int getSumOfHours(ArrayList<DailyCount> value, String str_proj) {
		int hours = 0;
		for (DailyCount dailyCount : value) {
			if(dailyCount.project.equalsIgnoreCase(str_proj))
				hours +=dailyCount.getHours() ;	
		}
		return hours;
	}
	/**
	 * @param value
	 * @return 
	 */
	private int getOverallSumOfHours(ArrayList<DailyCount> value) {
		int hours = 0;
		for (DailyCount dailyCount : value) {
			hours +=dailyCount.getHours() ;	
		}
		return hours;
	}
	/**
	 * @param header_row 
	 * @return 
	 * 
	 */
	private ArrayList<String> getDateList(Row header_row) {
		int iNo = header_row.getLastCellNum();
		ArrayList<String> lst_dates = new ArrayList<>();
		for(int i = 2; i< iNo; i++) {
			lst_dates.add(Excel.getCellValue(header_row.getCell(i)));
		}
		
		return lst_dates;
	}
}
