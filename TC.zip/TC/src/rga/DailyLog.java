/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           DailyLog.java          
#      Module          :           rga          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - OffShoreDevelopment          
#      Author          :           Vinothkumar Arthanari          
#
#  =================================================================================================               
#  Revision History:     
#  =================================================================================================                    
#  Date            Name                       Description of Change
#  09-Aug-2018     Vinothkumar Arthanari      Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package rga;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class DailyLog {

	String date;
	int cumulativeHours;
	int noOfORC;
	int cumulativeORC;
	double cumulativeMtbf;
	double logTI;
	double logMTBF;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getCumulativeHours() {
		return cumulativeHours;
	}
	public void setCumulativeHours(int hours) {
		this.cumulativeHours = hours;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Hours:"+cumulativeHours+"\tORC:"+noOfORC+"\tCumulative:"+cumulativeORC;
	}
	/**
	 * 
	 */
	public void addNoOfORC() {
		noOfORC++;
		
	}
	/**
	 * @return the cumulativeORC
	 */
	public int getCumulativeORC() {
		return cumulativeORC;
	}
	/**
	 * @param cumulativeORC the cumulativeORC to set
	 */
	public void setCumulativeORC(int cumulativeORC) {
		this.cumulativeORC = cumulativeORC;
	}
	/**
	 * @return the noOfORC
	 */
	public int getNoOfORC() {
		return noOfORC;
	}
	/**
	 * @return the cumulativeMtbf
	 */
	public double getCumulativeMtbf() {
		return cumulativeMtbf;
	}
	/**
	 * @param cumulativeMtbf the cumulativeMtbf to set
	 */
	public void setCumulativeMtbf(double cumulativeMtbf) {
		this.cumulativeMtbf = cumulativeMtbf;
	}
	/**
	 * @return the logTI
	 */
	public double getLogTI() {
		return logTI;
	}
	/**
	 * @param logTI the logTI to set
	 */
	public void setLogTI(double logTI) {
		this.logTI = logTI;
	}
	/**
	 * @return the logMTBF
	 */
	public double getLogMTBF() {
		return logMTBF;
	}
	/**
	 * @param logMTBF the logMTBF to set
	 */
	public void setLogMTBF(double logMTBF) {
		this.logMTBF = logMTBF;
	}
}
