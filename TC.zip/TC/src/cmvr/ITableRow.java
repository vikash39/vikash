/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           ITableRow.java          
#      Module          :           cmvr          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Apr 10, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package cmvr;

/**
 * @author Administrator
 *
 */
public interface ITableRow {

	
	public String[] getValues();
	public void setValues(String[] str_arr);
}
