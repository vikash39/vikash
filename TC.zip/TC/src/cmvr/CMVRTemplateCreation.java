/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           CMVRTemplateCreation.java          
#      Module          :           cmvr          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Apr 9, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package cmvr;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateIn2;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateInput2;

/**
 * @author Administrator
 *
 */
public class CMVRTemplateCreation {

	private Sheet sheet;
	/**
	 * 
	 */
	public CMVRTemplateCreation() {
		
	}
	ArrayList<String> lst_val;
	ArrayList<RowInfo> lst_info;
	public void readExcelBook() throws IOException {
		
		FileInputStream excelFile = new FileInputStream(new File("C:\\temp\\CMVR INP.xlsx"));
        Workbook workbook = new XSSFWorkbook(excelFile);
        sheet = workbook.getSheetAt(0);
        loadHeaderInfomration();
        loadTableInfor();
        updateIntoTeamcenter();
	}
	public static void main(String[] args) {
		try {
			new CMVRTemplateCreation().readExcelBook();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 
	 */
	private void updateIntoTeamcenter() {
		TCComponentItem item = (TCComponentItem) AIFUtility.getCurrentApplication().getTargetComponent();
		ArrayList<CreateIn2> lst_inp = new ArrayList<>();
		for (RowInfo rowInfo : lst_info) {
			CreateInput2 inp_prop = new CreateInput2();
			inp_prop.boName = "M2_CMVR_PARAMATERS";
			Hashtable<String, String[]> map_prop = new Hashtable<>();
			Set<String> set = rowInfo.map_attrib.keySet();
			String str_confg = "";
			for (String string : set) {
				if(string.contains("S. No"))
					map_prop.put("m2_serial_no", new String[] {rowInfo.map_attrib.get(string)});
				else if(string.contains("Parameter"))
					map_prop.put("m2_parameter", new String[] {rowInfo.map_attrib.get(string)});
				else if(string.contains("Value"))
					map_prop.put("m2_value", new String[] {rowInfo.map_attrib.get(string)});
				else if(string.contains("Group"))
					map_prop.put("m2_group", new String[] {rowInfo.map_attrib.get(string)});
				else
					str_confg += string+"="+removeNL(rowInfo.map_attrib.get(string))+"\n";
			}
			map_prop.put("m2_configuration", new String[] {str_confg});
			inp_prop.propertyNameValues = map_prop;
			CreateIn2 in_create = new CreateIn2();
			in_create.clientId = ""+lst_inp.size();
			in_create.pasteProp = "m2_base_parameter";
			in_create.targetObject = item;
			in_create.createData = inp_prop;
			lst_inp.add(in_create);
			
			System.out.println(str_confg);
		}
		
		DataManagementService dm_serv = DataManagementService.getService(item.getSession());
		
		CreateResponse localCreateResponse = dm_serv.createRelateAndSubmitObjects2(lst_inp.toArray(new CreateIn2[lst_inp.size()] ));
		System.out.println(localCreateResponse.output.length);
	}
	private String removeNL(String str_val){
		if(str_val.contains("\n"))
			str_val = str_val.replaceAll("\n", "__NL__");
		return str_val;
	}
	/**
	 * 
	 */
	private void loadTableInfor() {
		lst_info = new ArrayList<>();
		for(Row row : sheet) {
			if(row.getRowNum() == 0)
				continue;
			RowInfo info = new RowInfo();
			for(int j = 0; j< lst_val.size(); j++) {
				String str_val = getCellValue(row.getCell(j));
				if(!str_val.trim().isEmpty())
					info.map_attrib.put(lst_val.get(j), str_val);
			}
			if(info.map_attrib.size()>0)
				lst_info.add(info);
		}
	}
	
	
	class RowInfo{
		Hashtable<String, String> map_attrib;
		public RowInfo() {
			map_attrib = new Hashtable<>();
		}
	}

	private void loadHeaderInfomration(){
		Row row = sheet.getRow(0);
		lst_val = new ArrayList<>();
		for(int i = 0; i< row.getLastCellNum() ; i++) {
			lst_val.add(getCellValue(row.getCell(i)));
		}
	}
	 public static String getCellValue(Cell cell) {
	        if (cell == null) 
	            return "";
	        switch (cell.getCellType()) {
	            case Cell.CELL_TYPE_BLANK:
	                return "";
	            case Cell.CELL_TYPE_BOOLEAN:
	                return  cell.getBooleanCellValue()+"";
	            case Cell.CELL_TYPE_STRING:
	                return cell.getStringCellValue();
	            case Cell.CELL_TYPE_NUMERIC:
	               return isNumberOrDate(cell);
	            case Cell.CELL_TYPE_FORMULA:
	                return isNumberOrDate(cell);
	        }
	        return "";
	    }
	 private static String isNumberOrDate(Cell cell) {
	        if (DateUtil.isCellDateFormatted(cell)) {
	            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	            return formatter.format(cell.getDateCellValue());
	        } else {
	            DataFormatter df = new DataFormatter();
	            return  df.formatCellValue(cell);
	        }
	    } 
}
