/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           AA.java          
#      Module          :           cmvr          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - CMVR          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                   Name					        Description of Change
#  May 5, 2018				  Vinothkumar Arthanari			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package cmvr;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.ResourceManager;
import org.eclipse.wb.swt.SWTResourceManager;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class AA extends Dialog {

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public AA(Shell parentShell) {
		super(parentShell);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = (Composite) super.createDialogArea(parent);
		
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setImage(SWTResourceManager.getImage("C:\\Vinoth\\Workspace\\com.mnm.fd_cmvr\\icons\\Approved.png"));
		lblNewLabel.setText("New Label");

		return container;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}

}
