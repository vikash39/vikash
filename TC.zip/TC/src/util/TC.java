package util;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



import com.teamcenter.rac.aif.kernel.AIFComponentContext;
import com.teamcenter.rac.aif.kernel.AIFComponentContextListIterator;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.common.Activator;
import com.teamcenter.rac.kernel.ResourceMember;
import com.teamcenter.rac.kernel.SoaUtil;
import com.teamcenter.rac.kernel.TCAccessControlService;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentBOMLine;
import com.teamcenter.rac.kernel.TCComponentBOMWindow;
import com.teamcenter.rac.kernel.TCComponentBOMWindowType;
import com.teamcenter.rac.kernel.TCComponentContextList;
import com.teamcenter.rac.kernel.TCComponentDataset;
import com.teamcenter.rac.kernel.TCComponentDatasetType;
import com.teamcenter.rac.kernel.TCComponentFolder;
import com.teamcenter.rac.kernel.TCComponentFolderType;
import com.teamcenter.rac.kernel.TCComponentForm;
import com.teamcenter.rac.kernel.TCComponentFormType;
import com.teamcenter.rac.kernel.TCComponentGroup;
import com.teamcenter.rac.kernel.TCComponentGroupType;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentItemRevisionType;
import com.teamcenter.rac.kernel.TCComponentItemType;
import com.teamcenter.rac.kernel.TCComponentManager;
import com.teamcenter.rac.kernel.TCComponentPerson;
import com.teamcenter.rac.kernel.TCComponentProcess;
import com.teamcenter.rac.kernel.TCComponentProcessType;
import com.teamcenter.rac.kernel.TCComponentProject;
import com.teamcenter.rac.kernel.TCComponentProjectType;
import com.teamcenter.rac.kernel.TCComponentQuery;
import com.teamcenter.rac.kernel.TCComponentQueryType;
import com.teamcenter.rac.kernel.TCComponentRevisionRule;
import com.teamcenter.rac.kernel.TCComponentRevisionRuleType;
import com.teamcenter.rac.kernel.TCComponentSignoff;
import com.teamcenter.rac.kernel.TCComponentTask;
import com.teamcenter.rac.kernel.TCComponentTaskTemplate;
import com.teamcenter.rac.kernel.TCComponentTaskTemplateType;
import com.teamcenter.rac.kernel.TCComponentUser;
import com.teamcenter.rac.kernel.TCComponentUserType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPreferenceService;
import com.teamcenter.rac.kernel.TCProperty;
import com.teamcenter.rac.kernel.TCSession;
//import com.teamcenter.rac.kernel.servicegateway.TcWebServiceGateway;
import com.teamcenter.rac.kernel.tcservices.TcResponseHelper;
import com.teamcenter.rac.kernel.tcservices.TcVariantService;
import com.teamcenter.rac.kernel.tcservices.TcVariantService.DeepCopyInfo_S;
import com.teamcenter.rac.pse.AbstractPSEApplicationPanel;
import com.teamcenter.rac.pse.common.BOMPanel;
import com.teamcenter.rac.pse.variants.sosvi.VariantItemRequirement;
import com.teamcenter.rac.query.QueryService;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.Registry;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core.ProjectLevelSecurityService;
import com.teamcenter.services.rac.core._2007_06.DataManagement.RelationAndTypesFilter;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsPref2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationsResponse2;
import com.teamcenter.services.rac.core._2007_09.DataManagement.ExpandGRMRelationship;
import com.teamcenter.services.rac.core._2009_10.ProjectLevelSecurity;

/**
 * @author Vinothkumar Arthanari
 *		   Jan 10, 2013
 */
@SuppressWarnings({"deprecation","rawtypes","unchecked"})
public class TC {
	
	public static TCSession session 					= (TCSession)AIFUtility.getCurrentApplication().getSession();
	public static TCComponentUser user 					= session.getUser();
	public static final String SPECIFICATION  			= "IMAN_specification"; 
	public static final String  CMF_FORM				= "catia_model_attributes" ;
	public static final String  TEMPLATE_ACCESS			= "Access Bypass" ;
	public static final String  OTHER_ATTRIBUTE_FORM	= "M2_OtherAttributes" ;
	public static final String  OTHER_ATTRIBUTE_FORM_REL= "M2_OtherAttributesFormRel" ;
	public static final DataManagementService dataMgtService = DataManagementService.getService(session);
	/**
	 * Finds the Item
	@param  itemId - Item ID
	@return TCComponentItem
	*/
	public static TCComponentItem findItem(String itemId){
		return findItem(null, itemId);
	}

	/**
	 * Finds the Item
	@param itemType - Item Type
	@param itemId  - Item ID
	@return
	*TCComponentItem
	*/
	public static TCComponentItem findItem(String itemType, String itemId){
		try {
			if(itemType == null || itemType.trim().isEmpty())
				itemType = "Item";
			TCComponentItemType tItemType =(TCComponentItemType) session.getTypeComponent(itemType);
			TCComponentItem tItem = tItemType.find(itemId);
			
			return tItem;
		} catch (TCException e) {
			e.printStackTrace();
		} 
		return null;
	}

	/**
	 * Finds the Item Revision Based on Item ID and Revision ID
	@param itemId - Item ID
	@param revId -  Revision ID
	@return
	*TCComponentItemRevision
	*/
	public static TCComponentItemRevision findRev(String itemId, String revId){
		return findRev(null, itemId, revId);
	}

	/**
	 *  Finds the Item Revision Based on Item ID ,Revision ID and Revision Type
	@param revType - Revision Type
	@param itemId - Item ID
	@param revId -  Revision ID
	@return
	*TCComponentItemRevision
	*/
	public static TCComponentItemRevision findRev(String revType, String itemId, String revId){
		try {
			if(revType == null || revType.trim().isEmpty())
				revType = "ItemRevision";
			TCComponentItemRevisionType tItemRevType =(TCComponentItemRevisionType) session.getTypeComponent(revType);
			TCComponentItemRevision tItemRev = tItemRevType.findRevision(itemId,revId);
			return tItemRev;
		} catch (TCException e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	/**
	 *  Creates the Item 
	@param itemID - Item ID
	@param itemName - Item Name
	@param itemType - Item Type
	@return
	@throws Exception
	*TCComponentItem
	*/
	public static TCComponentItem createItem(String itemID, String itemName,String itemType) throws Exception
	{
		try {
			TCSession tSession = (TCSession) AIFUtility.getCurrentApplication().getSession();
			TCComponentItemType tItemtype = (TCComponentItemType) tSession .getTypeComponent(itemType);
			TCComponentItem tItem	=	tItemtype.create(itemID, "001", itemType,itemName, null, null,null,null);
			System.out.println("Created Item ID:"+tItem);
			return tItem;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	

	/**
	 * Returns Latest Item Revision of the Specified Flag.
	 */
	public static TCComponentItemRevision getLatestReleasedRev(TCComponentItem tItem,String releaseFlag) throws TCException{
		TCComponentItemRevision[] relRevs = tItem.getReleasedItemRevisions();
		if(relRevs == null || relRevs.length == 0)
			return null;
		for (TCComponentItemRevision tcComponentItemRevision : relRevs) {
			if(releaseFlag == null )
				return tcComponentItemRevision;
			if(TC.isReleased(tcComponentItemRevision, releaseFlag))
				return tcComponentItemRevision;
		}
		return null;
	}
	public static TCComponentDataset attachDataSet(TCComponentItemRevision tItemRev, String upLoadFilePath, String relation, boolean throwable) throws Exception {
		
		System.out.println("upLoadFilePath :"+upLoadFilePath);
		String[]  fileTypeRef = getFileReference(upLoadFilePath);
		return attachDataSet(new Object[]{
					tItemRev,
					upLoadFilePath,
					fileTypeRef[0],
					fileTypeRef[1],
					relation
					}, throwable);
	}	
	
	public static String[] getFileReference(String upLoadFilePath){
		System.out.println(upLoadFilePath);
		String fileExt = upLoadFilePath.substring(upLoadFilePath.lastIndexOf(".")+1);
		if(fileExt.equalsIgnoreCase("xls"))			return new String[]{"MSExcel","excel"};
		if(fileExt.equalsIgnoreCase("pdf"))			return new String[]{"PDF",TC.isUSOTCSite() ? "PDF_Reference" : "PDF"};
		if(fileExt.equalsIgnoreCase("xlsx"))			return new String[]{"MSExcelX","excel"};
		if(fileExt.equalsIgnoreCase("pptx"))			return new String[]{"MSPowerPointX","powerpoint"};
		if(fileExt.equalsIgnoreCase("ppt"))			return new String[]{"MSPowerPoint","powerpoint"};
		if(fileExt.equalsIgnoreCase("doc"))			return new String[]{"MSWord","word"};
		if(fileExt.equalsIgnoreCase("docx"))			return new String[]{"MSWordX","word"};
		if(fileExt.equalsIgnoreCase("zip"))			return new String[]{"Zip","ZIPFILE"};
		if(fileExt.equalsIgnoreCase("CATProduct"))		return new String[]{"CATProduct","catproduct"};
		if(fileExt.equalsIgnoreCase("CATPart"))		return new String[]{"CATPart","catpart"};
		if(fileExt.equalsIgnoreCase("dxf"))			return new String[]{"PV","DXF"};
		if(fileExt.equalsIgnoreCase("tif"))			return new String[]{"TIF","TIF_Reference"};
		if(fileExt.equalsIgnoreCase("jpg"))			return new String[]{"JPEG","JPEG_Reference"};
		if(fileExt.equalsIgnoreCase("bmp"))			return new String[]{"Bitmap","Image"};
		if(fileExt.equalsIgnoreCase("gif"))			return new String[]{"Image","Image"};
		if(fileExt.equalsIgnoreCase("cgm"))			return new String[]{"CGM","PV"};
		if(fileExt.equalsIgnoreCase("prt"))			return new String[]{"UGMASTER","UGPART"};
	
		return new String[]{"Text","Text"};
	
	}
	public static TCComponentDataset attachDataSet(Object[] obj) throws Exception {
		return attachDataSet(obj, false);
	}
	/**
	 * Creates and Attaches the Dataset in Specified ItemRevision
	@param obj  
	*void
	 *obj[0] - ItemRevision  <br>
	 *obj[1] - upLoadFilePath <br> 
	 *obj[2] - fileType <br>
	 *obj[3] - reference <br>
	 *obj[4] - relation <br>
	 *obj[5] - appendValue if Passed
	 * @return 
	 * @throws Exception 
	
	*/
	
	public static TCComponentDataset attachDataSet(Object[] obj, boolean isThroable) throws Exception {
		TCComponentDataset newDataset  = null;
		try {
			TCComponent itemRev = (TCComponent) obj[0];
			String dsId ;
			if(obj.length == 6)
				dsId = obj[5].toString();
			else
				dsId =  itemRev.getProperty("item_id")+"/"+itemRev.getProperty("item_revision_id");
			String[] refType = new String[1];
			TCComponentDatasetType datasetType = (TCComponentDatasetType)itemRev.getSession().getTypeComponent(obj[2].toString());
			System.out.println(obj[2].toString());
			if(obj[2].toString().equalsIgnoreCase("PDF"))
				newDataset =datasetType.create(dsId, "PDF", "PDF", "PDF");
			else
				newDataset =datasetType.create(dsId, "", obj[2].toString());
			
			itemRev.add(obj[4].toString(), newDataset);
			refType[0] = obj[3].toString();
			String[] filepath = new String[1];
			filepath[0] =obj[1].toString();
			try{
				newDataset.setFiles(filepath, refType);	
			}catch (TCException e) {
				/*if(FmsFileCacheProxy.isFccEnabled())
					MessageBox.post("FCC is Not Enabled... Please restart the FCC..","Error",MessageBox.ERROR);
				else*/
				if(isThroable)
					throw e;
				MessageBox.post(e);
			}
		} catch (Exception ex) {
			if(isThroable)
				throw ex;
			MessageBox.post(ex);
			ex.printStackTrace();
		}
		return newDataset;
	}
	
	public static ArrayList<TCComponent> getTcQuery(String queryName,ArrayList<String> queryKey,ArrayList<String> queryValue) {
		return getTcQuery(queryName, queryKey.toArray(new String[queryKey.size()]), queryValue.toArray(new String[queryValue.size()]));

	}
	
	/**
	 * Query and returns the result based on the Query name, Key and Value.
	@param queryName
	@param queryKey
	@param queryValue
	@return ArrayList<TCComponent>
	*/
	public static ArrayList<TCComponent> getTcQuery(String queryName,String queryKey [],String queryValue []){

    	
	    
        TCSession session =(TCSession) AIFUtility.getCurrentApplication().getSession();;
        QueryService queryservice = new QueryService();
        TCComponent atccomponent[] = new TCComponent[1];
        TCComponentContextList tccomponentcontextlist = null;
        ArrayList<TCComponent> tItem = new ArrayList<TCComponent>();
  		session.setStatus("Exceuting Query...");
  	    AIFComponentContext aaifcomponentcontext[] = new AIFComponentContext[999];
			try{
					 TCComponentQueryType tccomponentquerytype = (TCComponentQueryType)session.getTypeComponent("ImanQuery");
				     TCComponentQuery tccomponentquery = (TCComponentQuery)tccomponentquerytype.find(queryName);//MM_Vehicle_Benchmark
				     TCComponent[] arr_qry = tccomponentquery.execute(queryKey, queryValue);
				     ArrayList<TCComponent> lst_qry = new ArrayList<>();
				     Collections.addAll(tItem, arr_qry);
				     System.out.println("Query Name:"+queryName);
				     System.out.println("Keys:"+Arrays.asList(queryKey));
				     System.out.println("Value:"+Arrays.asList(queryValue));
				     /*tccomponentcontextlist = queryservice.executeSavedQuery(session, (TCComponentManager) tccomponentquery.getComponentManager(), tccomponentquery, queryKey, queryValue, atccomponent, 0, 0);
				     AIFComponentContextListIterator aifcomponentcontextlistiterator = tccomponentcontextlist.getIterator();
				     aaifcomponentcontext = aifcomponentcontextlistiterator.getRemainings();
				     System.out.println("Count item types:"+aifcomponentcontextlistiterator.getListCount());
				     session.setStatus("Processing Query Results..");
				     for(int i  = 0; i<aifcomponentcontextlistiterator.getListCount(); i++)
				     	 tItem.add((TCComponent) aaifcomponentcontext[i].getComponent());*/
				    
				    System.out.println("Query  Result Count:"+tItem.size());
				    session.setReadyStatus();
				}
				catch (Exception e) 
				{
						e.printStackTrace();
				}
				
				return tItem;
    
	}
	
	/**
	 * Return Master form
	@param compTag - {@link TCComponent} valid Item, ItemRevision and BOM Line
	@param isMaster - <code>true</code> Returns Item Master Form if 
	@return
	*TCComponent
	*/
	public static TCComponent getMasterTag(TCComponent compTag,boolean isMaster){
		try{
			if(compTag instanceof TCComponentBOMLine)
				compTag = ((TCComponentBOMLine)compTag).getItemRevision();
			
			
			if(compTag instanceof TCComponentItem)
				if(isMaster)
					return compTag.getRelatedComponent("IMAN_master_form");
				else{
					TCComponentItemRevision rev =((TCComponentItem)compTag).getLatestItemRevision();
					return rev.getRelatedComponent("IMAN_master_form_rev");
				}
			else
				if(isMaster){
					TCComponentItem rev =((TCComponentItemRevision)compTag).getItem();
					return rev.getRelatedComponent("IMAN_master_form");
				}
				else{
					
					return compTag.getRelatedComponent("IMAN_master_form_rev");
				}
					
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * Getting project codes from MY Teamcenter prespective Project Dropdown List
	@param formType
	@param formName
	@return
	@throws TCException
	*TCComponentForm
	*/
	public static ArrayList getproject(TCSession tSession, TCComponentUser tUser) throws TCException 
	{
		ProjectLevelSecurity.UserProjectsInfoInput localUserProjectsInfoInput = new ProjectLevelSecurity.UserProjectsInfoInput();
	 	    localUserProjectsInfoInput.user = tUser;
	 	    localUserProjectsInfoInput.activeProjectsOnly = true;
	 	    localUserProjectsInfoInput.privilegedProjectsOnly = true;
	 	    localUserProjectsInfoInput.programsOnly = false;
	 	    localUserProjectsInfoInput.clientId = ("Call getUserProjects() at " + new Date());
	 	    ProjectLevelSecurityService localProjectLevelSecurityService = ProjectLevelSecurityService.getService(tSession);
	 	    ProjectLevelSecurity.UserProjectsInfoResponse localUserProjectsInfoResponse = localProjectLevelSecurityService.getUserProjects(new ProjectLevelSecurity.UserProjectsInfoInput[] { localUserProjectsInfoInput });
	 	    SoaUtil.checkPartialErrors(localUserProjectsInfoResponse.serviceData);
	 	    ArrayList localArrayList = new ArrayList(0);
	 	    for (ProjectLevelSecurity.UserProjectsInfo localUserProjectsInfo : localUserProjectsInfoResponse.userProjectInfos)
	 	      for (ProjectLevelSecurity.ProjectInfo localProjectInfo : localUserProjectsInfo.projectsInfo)
	 	        localArrayList.add(localProjectInfo.project);
	 	    return localArrayList;
			
		}
	/**
	 * Creates the Form
	@param formType
	@param formName
	@return
	@throws TCException
	*TCComponentForm
	*/
	public static TCComponentForm createForm(String formType,String formName) throws TCException{
		TCComponentFormType formTypeComp = (TCComponentFormType) session.getTypeComponent(formType);
		TCComponent form = formTypeComp.create(formName,formName ,formType ,true);
		return (TCComponentForm) form;
	}
	
	/**
	 * Creates and Attaches the form in Item Revision.
	@param tItemRev
	@param relation
	@param formType
	@return
	@throws TCException
	*TCComponentForm
	*/
	public static TCComponentForm createForm(TCComponentItemRevision tItemRev,String relation, String formType) throws TCException{
		TCComponentForm form = createForm(formType, TC.getIdandRev(tItemRev, "/"));
		tItemRev.add(relation,form);
		return form ;
	}
	
	
	/**
	 * Makes the parentRev as Top level component in window and returns that Top Level BOM Line
	@param parentRev 
	@return
	*TCComponentBOMLine
	*/
	public static  TCComponentBOMLine getBomLine(TCComponentItemRevision parentRev){
		try{
			TCComponentRevisionRuleType tRevisionRuleType = (TCComponentRevisionRuleType)session.getTypeComponent("RevisionRule");
			TCComponentRevisionRule tRevisionRule = tRevisionRuleType.getDefaultRule();
			TCComponentBOMWindowType tWindowType = (TCComponentBOMWindowType)session.getTypeComponent("BOMWindow");
			TCComponentBOMWindow tWindow = tWindowType.create(tRevisionRule);	
			TCComponentBOMLine parentBomLine = tWindow.setWindowTopLine(null, parentRev, null, null);
			return parentBomLine;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * Closes the BOM Window. 
	@param line -any line of the Current BOM Window
	*/
	public static void closeWindow(TCComponentBOMLine line){
		try {
			if(!line.window().isWindowClosed())
				line.window().close();
		} catch (Exception e) {
		}
		
	}
	/**
	 * Finds the User for the input User ID
	@param userId - User ID
	@return
	 *TCComponentUser
	 */
	public static String getUserMailId( String userId){
		try {
			
			TCComponentPerson tPerson = (TCComponentPerson) TC.findUser(userId).getUserInformation().get(0);
			String mail =tPerson.getProperty("PA9");
			return mail;
		} catch (TCException e) {
			//e.printStackTrace();
		} 
		return null;
	}
	/**
	 * Finds the User for the input User ID
	@param userId - User ID
	@return
	*TCComponentUser
	*/
	public static TCComponentUser findUser( String userId){
		try {
			
			TCComponentUserType  tUserType=(TCComponentUserType) session.getTypeComponent("User");
			TCComponentUser tUser = tUserType.find(userId);
			return tUser;
		} catch (TCException e) {
			//e.printStackTrace();
		} 
		return null;
	}
	/**
	 * Finds the Group for the Group Name
	@param grpName - Group Name
	@return
	*TCComponentGroup
	*/
	public static TCComponentGroup findGroup( String grpName){
		try {
			TCComponentGroupType tGrpType=(TCComponentGroupType) session.getTypeComponent("Group");
			TCComponentGroup tGrp = tGrpType.find(grpName);
			return tGrp;
		} catch (TCException e) {
			//e.printStackTrace();
		} 
		return null;
	}
	/**
	 * Finds the template and returns that
	@param processTemplateName - Process Template Name
	@return
	*TCComponentTaskTemplate
	*/
	public static TCComponentTaskTemplate findTemplate(String processTemplateName) throws TCException{
			 TCComponentTaskTemplateType taskTemplateType = (TCComponentTaskTemplateType) session.getTypeComponent("EPMTaskTemplate");
			 return taskTemplateType.find(processTemplateName.trim(), 0);

	}
	
	public static TCComponentProcess initProcess(TCComponent tCompRev,String templateName) throws TCException{
		return initProcess(tCompRev, findTemplate(templateName));
	}
	public static TCComponentProcess initProcess(TCComponent tCompRev,TCComponentTaskTemplate taskTemplate) throws TCException{
		return initProcess(tCompRev, taskTemplate, null);
	}
	public static TCComponentProcess initProcess(TCComponent tCompRev,TCComponentTaskTemplate taskTemplate,  ResourceMember[] resourceMenmber) throws TCException{
		TCComponentProcessType localTCComponentProcessType = (TCComponentProcessType)session.getTypeComponent("Job");
		int parmInt[] = {1};
		TCComponent comp[] = {tCompRev};
		TCComponentProcess newProcess  = null ;
		if(resourceMenmber !=null)
			newProcess = (TCComponentProcess) localTCComponentProcessType.create(tCompRev.toString(), tCompRev.toString(), taskTemplate, comp, parmInt, resourceMenmber);
		else
			newProcess = (TCComponentProcess) localTCComponentProcessType.create(tCompRev.toString(), tCompRev.toString(), taskTemplate, comp, parmInt);
		System.out.println("Process Initiated:"+ newProcess);
		return newProcess ;
	}
	
	public static void deleteProcessAccess(TCComponent tComp) {
		if(tComp == null)
			return ;
		TCComponentProcess process  = null;
		try {
			process = tComp.getCurrentJob();
			if(process != null && process.getRootTask().toString().equalsIgnoreCase(TEMPLATE_ACCESS))
				process.delete();
			System.out.println(TEMPLATE_ACCESS+":Deleting Process..");
		} catch (Exception e) {
			System.out.println("Exception in Exec.setAccess()");
			e.printStackTrace();
			try {
				process = tComp.getCurrentJob();
				if(process != null && process.getRootTask().toString().equalsIgnoreCase(TEMPLATE_ACCESS)){
					TCComponentTask task = process.getRootTask().getSubtask("Access");
					/*task.setProperty("done", "true");
					task.performAction(4, "Completing...");*/
					
					TCProperty tcprop = task.getTCProperty("task_result");
					tcprop.setStringValue("Completed");
					task.performAction(4, "Completing...");
					
					System.out.println(TEMPLATE_ACCESS+":Updating Do Task..");
				}
			} catch (Exception e2) {
				System.out.println("Exception in Exec.setAccess()");
				e2.printStackTrace();

			}
		}
		try {
			System.out.println(TEMPLATE_ACCESS+":Done.. "+tComp.getCurrentJob());
		} catch (Exception e) {}
	}
	
	/**
	 * Returns Item ID and Revision ID with Seperator - "/"
	@param tcComp
	@return
	*String
	*/
	public static String getIdandRev(TCComponent tcComp){
		return getIdandRev(tcComp,"/");
	}
	/**
	 * Returns Item ID and Revision ID with seperator Passed
	@param tcComp
	@return
	*String
	*/
	public static String getIdandRev(TCComponent tcComp,String seperator){
		try {
			tcComp = getRevision(tcComp) ;
			String str = tcComp.getProperty("item_id")+seperator+tcComp.getProperty("item_revision_id");
			return str;
		} catch (TCException e) {
			e.printStackTrace();
			return tcComp.toString();
		}
	}
		
	/**
	 * Checks whether WRITE Access is there for that object.
	@param tcComp
	@return
	*boolean
	*/
	public static boolean hasWriteAccess(TCComponent tcComp){
		return hasAccess(tcComp, "WRITE") ;
	}
	/**
	 * Checks whether Passes Access is there for that object.
	@param tcComp
	@param sAccess
	@return
	*boolean
	*/
	public static boolean hasAccess(TCComponent tcComp,String sAccess){
		try{
			TCAccessControlService accessControlService = session.getTCAccessControlService();
			if(accessControlService !=null  )
				return accessControlService.checkPrivilege(tcComp, sAccess);
		}catch (Exception e) { e.printStackTrace();
		}
		return true;
	}
	
	/**
	 * Returns true if the tcComponent is released.
	@param tcComponent
	@return
	*boolean
	*/
	public static boolean isReleased(TCComponent tcComponent){
		try{
			String statusRealName = "release_status_list";
			if(tcComponent instanceof TCComponentBOMLine)
				statusRealName = "bl_rev_release_status_list";
			return tcComponent.getProperty(statusRealName).trim().isEmpty() ? false : true; 
			
		}catch (Exception e) {}
		return false;
	}
	/**
	 * Returns <code>true</code> if the tcComponent is released with the given release Status.
	@param tcComponent
	@param releaseName
	@return
	*boolean
	*/
	public static boolean isReleased(TCComponent tcComponent, String releaseName){
		try{
			String statusRealName = "release_status_list";
			if(tcComponent instanceof TCComponentBOMLine)
				statusRealName = "bl_rev_release_status_list";
			String statList = tcComponent.getProperty(statusRealName).trim();
			String[] relName = statList.split(",");
			for (String string : relName) 
				if(string.trim().equalsIgnoreCase(releaseName))
					return true;
			
		}catch (Exception e) {}
		return false;
	}
	
	/**Returns <code>true</code> if the Current Group is dba if Bypass is enabled
	@return
	 *boolean
	 */
	public static boolean isDbaRole(boolean bypass) {
		String userGroup = session.getCurrentGroup().toString();
		return userGroup.equalsIgnoreCase("dba")  ? (bypass ? session.hasBypass() : true) : false;
	}
	/**Returns <code>true</code> if the Current Group is dba
	@return
	*boolean
	*/
	public static boolean isDbaRole() {
		return isDbaRole(false);
	}
	/**
	 * Returns true , if the Site is not MGRDSite..
	@return
	*boolean
	*/
	public static boolean isCHERNDSite(){
		String site = session.getCurrentSite().toString();
		if(site.equalsIgnoreCase("MGRDSite")){//USOTCSite//CHERNDSite
			return false;
		}else
			return true;
	}
	
	/**
	 * Returns true , if the Site is USOTCSite..
	@return
	*boolean
	*/
	//added by priya(20-10-2014) for blocking PF Validation for USOTC
	public static boolean isUSOTCSite(){
		String site = session.getCurrentSite().toString();
		System.out.println("the site....."+site);
		if(!site.equalsIgnoreCase("USOTCSite")){//USOTCSite//CHERNDSite
			return false;
		}else
			return true;
	}
	
	/** Returns true if the Object belongs to owning Site.*/
	public static boolean isOwningObject(TCComponent tComp){
		return isOwningObject(tComp,false);
	}
	
	/** Returns true if the Object belongs to owning Site.*/
	public static boolean isOwningObject(TCComponent tComp, boolean paramBoolean){
		
		try {
			String  site = tComp.getProperty("owning_site");
			if(site.trim().isEmpty())
				return true;
			else
				return false;
		} catch (TCException e) {
			e.printStackTrace();
			return paramBoolean ;
		}
	}
	/** Returns true if the Component in Process stage List*/
	public static boolean inProgress(TCComponent tComp){
		return inProgress(tComp,false);
	}
	/** Returns true if the Component in Process stage List*/
	public static boolean inProgress(TCComponent tComp, boolean paramBoolean){
		try {
			String  processList = tComp.getProperty("process_stage_list");
			if(processList.trim().isEmpty())
				return false;
			else
				return true;
		} catch (TCException e) {
			e.printStackTrace();
			return paramBoolean;
		}
		
	}
	/*public static int getQuantity(TCComponentBOMLine line,int parmInt) {
		try{
			String str = line.getProperty("bl_quantity").trim() ;
			if(str.isEmpty())
				str = "1";
			return Str.getInt(str,1) ;
		}catch (Exception e) {}
		return parmInt;
	}
	public static int getQuantity(TCComponentBOMLine line) {
		return getQuantity(line,1);
	}*/
	/**
	 * Returns Quantity of the BOM Line
	@param line
	@return
	*double
	*/
	public static double getQuantity(TCComponentBOMLine line,double paramDouble) {
		try{
			String str = line.getProperty("bl_quantity").trim() ;
			/*if(str.isEmpty())
				str = "1";*/
			return str.isEmpty() ? 1 : Str.getDouble(str,1) ;
		}catch (Exception e) {}
		return paramDouble;
	}
	/**
	 * Returns Quantity of the BOM Line
	@param line
	@return
	*double
	*/
	public static double getQuantity(TCComponentBOMLine line) {
		return getQuantity(line,1.0);
	}
	
	/**
	 * Returns Quantity of the BOM Line
	@param line
	@return
	*double
	*/
	public static int getQnty(TCComponentBOMLine line) {
		try{
			String str = line.getProperty("bl_quantity").trim() ;
			return str.isEmpty() ? 1 : Str.getInt(str) ;
		}catch (Exception e) {}
		return 1;
	}
	
	/**
	 * Returns Level of the BOM Line
	@param line
	@return
	*int
	*/
	public static int getLevel(TCComponentBOMLine line) {
		try {
			return line.getIntProperty("bl_level_starting_0");
		} catch (Exception e) {
		}
		return 0;
	}
	
	/**
	 * Returns the Revision,
	 * 		1. If Item, then returns Latest Revision.
	 * 		2. If BomLine. then returns the Item revision on BOM Line
	 * 		3. else returns the same Object Passed.
	@param tComp
	@return TCComponent
	@throws TCException
	*
	*/
	public static TCComponent getRevision(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentBOMLine)
			return ((TCComponentBOMLine)tComp).getItemRevision();
		else if(tComp instanceof TCComponentItem)
			return ((TCComponentItem)tComp).getLatestItemRevision();
		else
			return tComp;
	}
	
	/**
	 * Checks whether BOM View Revision type is attached to the Object.
	@param tComp
	@return boolean
	@throws TCException
	*
	*/
	public static boolean hasBOMView(TCComponent tComp) throws TCException{
		return tComp.getProperty("structure_revisions").trim().isEmpty() ? false: true ;
	}
	/**
	 * Return <code>true</code> if the Component have One Children as BOM Line.
	@param tComp
	@return boolean
	@throws TCException
	*
	*/
	public static boolean hasBOMLine(TCComponent tComp) throws TCException{
		tComp.refresh();
		return tComp.getProperty("view").trim().isEmpty()  ? false: true;
	}
	/** Returns true if the Login Person is owning user.. */
	public static boolean isOwner(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentBOMLine)
			tComp =  ((TCComponentBOMLine)tComp).getItemRevision();
		TCComponent tOwner = tComp.getReferenceProperty("owning_user");
		if(tOwner.equals(session.getUser()))
			return true;
		else
			return false;
	}
	/** Opens the Component in My Teamcenter..*/
	public static void openInMyTeamcenter(TCComponent tComp){
		openInPerspective(tComp, "com.teamcenter.rac.ui.perspectives.navigatorPerspective");
	}
	/** Opens the Component in Structure Manager..*/
	public static void openInStructureManager(TCComponent tComp){
		openInPerspective(tComp, "com.teamcenter.rac.pse.PSEPerspective");
	}
	/** Opens the Component withrespect to the prespective ID..*/
	public static void openInPerspective(TCComponent tComp, String perspectiveId){
		InterfaceAIFComponent[] openComp = {tComp}; 
		Activator.getDefault().openPerspective( perspectiveId );
		Activator.getDefault().openComponents(  perspectiveId, openComp);
	}
	/**
	 * Returns Structure Manager Title
	 */
	public static String getPseTitle(){
		return getPseTitle(true);
	}
	/**
	 * Returns Structure Manager Title
	 */
	//@SuppressWarnings("restriction")
	public static String getPseTitle(boolean isLeft)
	{
		JPanel applicationPanel = AIFUtility.getCurrentApplication().getApplicationPanel();
		 if(applicationPanel !=null && applicationPanel instanceof AbstractPSEApplicationPanel){
			 AbstractPSEApplicationPanel localAbstractPSEApplicationPanel = (AbstractPSEApplicationPanel) AIFUtility.getCurrentApplication().getApplicationPanel();
			 int i = isLeft ? 0: 1 ;
			 BOMPanel[] bomPanels = localAbstractPSEApplicationPanel.getAllBOMPanels();
			 if(bomPanels[i] == null)
				 return "" ;
			 return bomPanels[i].toString();
			 /*String title = bomPanels[i].getName() +"-"+bomPanels[i].getRevisionRuleName();
			 AbstractPSEApplication pseApp = (AbstractPSEApplication) com.teamcenter.rac.tcapps.TcappsPlugin.getPSEService();
			 try {
				 title += "-"+pseApp.askRevisionRuleDateUnitIntentString(bomPanels[i].getRevisionRule());
			} catch (Exception e) {
			}
			 
			 if(!bomPanels[i].getSOSName().isEmpty())
				 if(bomPanels[i].isSOSModified())
					 title += "-"+bomPanels[i].getSOSName()+"(Modified)" ;
				 else
					 title += "-"+bomPanels[i].getSOSName() ;
			 return title;*/
		}
		return "";
	}
	/**Returns the Previous revision List.*/
	
	public static ArrayList<TCComponentItemRevision> getPreviousRevList(TCComponentItemRevision tItemRev) throws TCException{
		return getPreviousRevList(tItemRev,false);
	}
	/** Returns the Previous revision List.
	@param tItemRev
	@param includeRev - on true includes the passing Item Revision
	@return
	@throws TCException
	*ArrayList<TCComponentItemRevision>
	*/
	public static ArrayList<TCComponentItemRevision> getPreviousRevList(TCComponentItemRevision tItemRev, boolean includeRev) throws TCException{
		TCComponent[] revListarr = tItemRev.getItem().getRelatedComponents("revision_list");
		
		ArrayList<TCComponentItemRevision> revList = new ArrayList<TCComponentItemRevision>();
		for (int i = 0; i< revListarr.length  ; i++) {
			TCComponentItemRevision tcRev = (TCComponentItemRevision) revListarr[i];
			if(tcRev.equals(tItemRev)){
				if(includeRev)
					revList.add(tcRev);
				break;
			}
			revList.add(tcRev);
		}
		return revList;
	}
	/** Returns the Next revision List.
	@param tItemRev
	@param includeRev - on true includes the passing Item Revision
	@return
	@throws TCException
	 *ArrayList<TCComponentItemRevision>
	 */
	public static ArrayList<TCComponentItemRevision> getNextRevList(TCComponentItemRevision tItemRev, boolean includeRev) throws TCException{
		TCComponent[] revListarr = tItemRev.getItem().getRelatedComponents("revision_list");
		
		ArrayList<TCComponentItemRevision> revList = new ArrayList<TCComponentItemRevision>();
		boolean rev = false;
		for (int i = 0; i< revListarr.length  ; i++) {
			TCComponentItemRevision tcRev = (TCComponentItemRevision) revListarr[i];
			if(rev || tcRev.equals(tItemRev)){
				if(rev)
					revList.add(tcRev);
				rev = true;
			}
		}
		if(includeRev)
			revList.add(0, tItemRev);
		return revList;
	}
	/**
	@param tCompRev
	*void
	 * @return 
	 * @throws TCException 
	*/
	public static TCComponentItem[] getRelatedVariantItem(TCComponentItemRevision tCompRev) throws TCException {
		ArrayList<TCComponentItemRevision> prevRevList = getPreviousRevList(tCompRev,true);
		Collections.reverse(prevRevList);
		for (int i = 0; i < prevRevList.size();  i++) {
			TCComponentBOMLine line = getBomLine(prevRevList.get(i));
			VariantItemRequirement  req = new VariantItemRequirement(line,session.getVariantService());
			TCComponentItem[] reqList = req.findSuitableVariantItems();
			if(reqList!=null){
				HashSet<TCComponentItem> set = new HashSet<TCComponentItem>(Arrays.asList(reqList));
				return  (set.toArray(new TCComponentItem[set.size()]));
			}
			TC.closeWindow(line);
			
		}
		return null;
	}

	/**
	@param obj
	*void
	 * @param tCompRev 
	 * @throws Exception 
	 * @throws TCException 
	*/
	public static void reviseVariantItem(TCComponentItem[] reqList, TCComponentItemRevision tCompRev) throws TCException, Exception {
		TCComponentBOMLine line = getBomLine(tCompRev);
		
		for (TCComponentItem tcComponentItem : reqList) {
			
			TC.initProcess(tcComponentItem.getLatestItemRevision()	, TC.findTemplate("BL-Quick Release"));
			TcResponseHelper localTcResponseHelper = TcVariantService.reviseAndUpdateVariantItemRevision(
					session, 
					line.getItemRevision(),
					line,
					"", 
					tcComponentItem.getProperty("object_name"), 
					tcComponentItem.getLatestItemRevision().getProperty("object_desc"),
					tcComponentItem.getLatestItemRevision(),
					new DeepCopyInfo_S[0], 
					null);
			TCComponent[] arrayOfTCComponent = localTcResponseHelper.getReturnedObjects();
			TCComponent newComp = null;
	        for (int k = 0; k < arrayOfTCComponent.length; k++)
	          if ((arrayOfTCComponent[k] instanceof TCComponentItemRevision))
	          {
	            newComp = arrayOfTCComponent[k];
	            break;
	          }
	        System.out.println(newComp);
		}
		closeWindow(line);
		
	}

	public static boolean canUpload(TCComponent tComp){
		Registry reg = Registry.getRegistry(Activator.class);
		try {
			
			if ( isOwner(tComp) ) 
				if (isReleased(tComp)) 
					MessageBox.post(reg.getString("Alias.WorkingRevision.INFO"), "Warning",MessageBox.WARNING);
				else
					if(isOwningObject(tComp))
						return true;
					else 
						MessageBox.post(reg.getString("Alias.WorkingRevision.INFO"), "Information",MessageBox.INFORMATION);
			else 
				MessageBox.post(reg.getString("Alias.OwningUser.INFO"), "Information",MessageBox.INFORMATION);
		} catch (TCException e) {
				e.printStackTrace();
		}
		return false;
	}
	
	/**
	@param role
	*void
	*/
	public static boolean isRole(String role) {
		return role.trim().equalsIgnoreCase((session.getRole().toString().trim()));
		
	}

	public static boolean isGroup(String group) {
		return group.trim().equalsIgnoreCase((session.getCurrentGroup().toString().trim()));
	}

	/**
	 * Returns Item Revision ID
	@param tItemRev
	@return
	 *Object
	 * @throws TCException 
	 */
	public static String getRevId(TCComponent tComp) throws TCException {
		tComp = getRevision(tComp);
		return tComp.getProperty("item_revision_id");
	}
	/**
	 * Returns Production Revision ID
	@param tItemRev
	@return
	 *Object
	 * @throws TCException 
	 */
	public static String getProdRevId(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentForm)
			return tComp.getProperty("metaphase_rev_no");
		tComp = getRevision(tComp);
		return getMasterTag(tComp, false).getProperty("metaphase_rev_no");
	}
	/**
	 * Returns Production Revision ID
	@param tItemRev
	@return
	 *Object
	 * @throws TCException 
	 */
	public static String getProdId(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentForm)
			return tComp.getProperty("m2_Permanent_Part_Number");
		tComp = getRevision(tComp);
		if(TC.isTypeOf(tComp, "MM_Item Revision") || TC.isTypeOf(tComp, "MM_Item_I Revision"))
			return getId(tComp);
		return getMasterTag(tComp, false).getProperty("m2_Permanent_Part_Number");
	}

	/**
	 * Returns Item ID
	@param tItemRev
	@return
	*Object
	 * @throws TCException 
	*/
	
	public static String getId(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentBOMLine)
			return tComp.getProperty("bl_item_item_id");
		return tComp.getProperty("item_id");
	}

	/**
	 * Returns Object
	@param tItemRev
	@return
	 *Object
	 * @throws TCException 
	 */
	public static String getName(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentBOMLine)
			return tComp.getProperty("bl_rev_object_name");
		return tComp.getProperty("object_name");
	}


	/**
	 * Returns PF Code
	@param tItemRev
	@return
	 *Object
	 * @throws TCException 
	 */
	public static String getPfCode(TCComponent tComp) throws TCException {
		if(tComp instanceof TCComponentForm)
			return tComp.getProperty("pf_code");
		
		return getMasterTag(tComp , false).getProperty("pf_code");
	}

	

	/**Checks whether Project is Assigned or Not 
	@param tComp
	@return
	*boolean
	*/
	public static boolean isProjectAssigned(TCComponent tComp) {
		String projectIds = "";
		try {
				projectIds = tComp.getProperty(tComp instanceof TCComponentBOMLine ? "bl_rev_project_ids" : "project_ids");
		} catch (Exception e) {
			System.out.println("Exception in TC.isProjectAssigned()");
			e.printStackTrace();
		}
		return !projectIds.trim().isEmpty() ;
		
	}
	/**
	 * Returns Project ID List
	@param tComp
	@return
	@throws TCException
	*ArrayList<String>
	*/
	public static ArrayList<String> getProject(TCComponent tComp) throws TCException {
		String projectIds = "";
		if(tComp instanceof TCComponentBOMLine)
			projectIds = tComp.getProperty("bl_rev_project_ids");
		else
			projectIds = tComp.getProperty("project_ids");
		if(projectIds.trim().isEmpty()) return new ArrayList<String>();
		return Str.getList(projectIds);//getRevision(tComp).getProperty("item_revision_id");
	}
	/**
	 * Returns Lead Project of the object
	@param tComp
	@return
	@throws TCException
	 *ArrayList<String>
	 */
	public static String getLeadProject(TCComponent tComp) throws TCException {
		ArrayList<String> projectIds = getProject(tComp);
		return projectIds.isEmpty()? "" : projectIds.get(0); 
	}
	
	
	/**
	 * Checks the Folder in Home Folder and returns it. Creates and returns the folder if no folder is in home folder
	@param name
	@return
	@throws TCException
	*TCComponentFolder
	*/
	public static TCComponentFolder getFolder(String name) throws TCException{
		return getFolder(null,name);
	}
	/**
	 * Checks the Folder in Home Folder and returns it. Creates and returns the folder if no folder is in home folder
	@param name
	@return
	@throws TCException
	*TCComponentFolder
	*/
	public static TCComponentFolder getFolder(TCComponent folder,String name) throws TCException{
		return getFolder(folder,name,true);
	}
	/**
	 * Checks the Folder in Specified Folder and returns it. if create is true will create and return.
	@param folder - null for Home Folder.
	@param name
	@return
	@throws TCException
	*TCComponentFolder
	*/
	public static TCComponentFolder getFolder(TCComponent folder,String name,boolean create) throws TCException{
				TCComponentFolder homeFolder = (TCComponentFolder) (folder == null? session.getUser().getHomeFolder() : folder) ;
				TCComponent[] folders = homeFolder.getRelatedComponents();
				TCComponentFolder tgtFolder = null;
				for(int j = 0;j<folders.length;j++){
					if(folders[j] instanceof TCComponentFolder){
						
						String folName = folders[j].getProperty("object_name");
						if(folName.equalsIgnoreCase(name)){
							tgtFolder = (TCComponentFolder) folders[j];
							break;
						}
					}
				}
				if(tgtFolder == null && create){
					tgtFolder = createFolder(name);
					homeFolder.add("contents", tgtFolder);
				}
		return tgtFolder;
	}
	public static TCComponentFolder createFolder(String folderName) throws TCException {
		TCComponentFolderType flderType = (TCComponentFolderType) session.getTypeComponent("Folder");
		return flderType.create(folderName , folderName , "Folder");
		
		
	}

	/**
	 * Get the Preference value with respect to the scope.
	@param scope
	@param string
	@return
	*String[]
	*/
	public static String[] getPreferenceArray(int scope, String string) {
		return session.getPreferenceService().getStringArray(scope, string);
		
	}
	public static String getPreference(int scope, String string) {
		return session.getPreferenceService().getString(scope, string);
		
	}
	public static String getWebLink() {
		return "http://"+getPreferenceArray(TCPreferenceService.TC_preference_site, "WEB_default_site_server")[0]+"/tc/webclient/";
		
	}
	public static String getWebLink(TCComponent tcComp) {
		return getWebLink()+tcComp.getUid();
		
	}
	/**
	@return MRV logo location- Downloads ID -MRVLOGO and returns the downloaded Location
	*File
	*/
	public static File getMRVLogoLocation(){
		File file = null;
		try {
			TCComponentItemRevision rev = TC.findRev("MRVLOGO", "001");
			TCComponent spec = rev.getRelatedComponent("IMAN_specification");
			if(spec!=null){
				TCComponentDataset dataSet = (TCComponentDataset) spec;
				String tmpDir = System.getProperty("java.io.tmpdir");
				file = dataSet.getFile("JPEG_Reference", "mrvLogo.jpg", tmpDir);
			}
		} catch (Exception e) {}
		return file;
	}
	public static TCComponentProject findProject(String project) throws TCException {
		TCComponentProjectType tccomponentprojecttype = (TCComponentProjectType)session.getTypeComponent("TC_Project");
		return tccomponentprojecttype.find(project);
	}
	public static void assignToProject(String project, TCComponentItem tItem) throws TCException {
		   TCComponentProjectType tccomponentprojecttype = (TCComponentProjectType)session.getTypeComponent("TC_Project");
           TCComponentProject  tccomponentproject = tccomponentprojecttype.find(project);
           if(tccomponentproject == null)
        	   return ;
         /*  if(tccomponentprojecttype.isPrivilegedMember(tccomponentproject, session.getUser())){
        	   System.out.println("your privilegedMember");
           		TCComponent atcComponent[] = {tItem};
           		tccomponentproject.assignToProject(atcComponent);
	        }*/
       	TCComponent atcComponent[] = {tItem};
   		tccomponentproject.assignToProject(atcComponent);
		
	}
	
	public static boolean hasProjectAccess(String projectCode) throws TCException{
		 TCComponentProjectType tccomponentprojecttype = (TCComponentProjectType)session.getTypeComponent("TC_Project");
         TCComponentProject  tccomponentproject = tccomponentprojecttype.find(projectCode);
         if(tccomponentproject == null)
        	 return false;
         return tccomponentprojecttype.isPrivilegedMember(tccomponentproject, user);
	}
	public static TCComponent getRelCompComponent(TCComponent compTag, String relation,String type) throws TCException{
		TCComponent[] relComp = compTag.getRelatedComponents(relation);
		for(int i = 0; i< relComp.length ; i++){
			if(relComp[i].getType().equalsIgnoreCase(type))
				return relComp[i];	
		}
		
		return null;
	}
	public static TCComponentDataset getCatiaDataset(TCComponent itemRev) throws TCException{
		TCComponentDataset dataset = (TCComponentDataset) getRelCompComponent(itemRev, SPECIFICATION, "CATPart");
		return dataset == null ?  (TCComponentDataset) getRelCompComponent(itemRev, SPECIFICATION, "CATProduct") : dataset;
		
	}
	public static TCComponentDataset getUGDataset(TCComponent itemRev) throws TCException{
		
		return (TCComponentDataset) getRelCompComponent(itemRev, SPECIFICATION, "UGMASTER");
		
	}
	public static TCComponent getUGMasterForm(TCComponent itemRev, boolean create) throws TCException{
		
		TCComponentDataset ugDataset = (TCComponentDataset) getRelCompComponent(itemRev, SPECIFICATION, "UGMASTER");
		TCComponent ugForm = null;
		if(ugDataset!=null)
			ugForm = (TCComponent) getRelCompComponent(ugDataset, "ref_list", "UGPartMassPropsForm");
		System.out.println(ugForm);
		if(create && ugForm == null){
			if(ugDataset == null){
				ugDataset = createDataset(getIdandRev(itemRev),"UGMASTER"); //"UGII V10-BASE"
				itemRev.add(SPECIFICATION, ugDataset);
			}
			if(ugForm == null){
				ugForm = createForm("UGPartMassPropsForm",getIdandRev(itemRev));
				ugDataset.addNamedReference(ugForm, "UGPART-MASSPR");
			}
		}
		return ugForm;
	}
	public static LinkedHashMap<TCComponent, TCComponent> getRelationComponents(TCComponent tComp,ExpandGRMRelationsPref2 grmRelation, boolean primary) throws TCException{
		LinkedHashMap<TCComponent, TCComponent> itemRelMap = new LinkedHashMap<TCComponent, TCComponent>();
		ExpandGRMRelationsResponse2 grmResponse ;
		if(primary)
			grmResponse = dataMgtService.expandGRMRelationsForPrimary(new TCComponent[]{tComp}, grmRelation);
		else
			grmResponse = dataMgtService.expandGRMRelationsForSecondary(new TCComponent[]{tComp}, grmRelation);
		ExpandGRMRelationship[] grmRelObjs  = grmResponse.output[0].relationshipData[0].relationshipObjects;
		for (ExpandGRMRelationship expandGRMRelationship : grmRelObjs) 
			if(expandGRMRelationship.otherSideObject!=null /*&& expandGRMRelationship.relation!=null*/)
				itemRelMap.put(expandGRMRelationship.otherSideObject,expandGRMRelationship.relation);
		return itemRelMap;
	}
	
	public static TCComponentDataset createDataset(String name,String type) throws TCException{
		TCComponentDatasetType dType = (TCComponentDatasetType) TC.session.getTypeComponent(type);
		return dType.create(name, name, type);
		
	}
	public static boolean isTypeOf(TCComponent tCompRev, String typeName) {
		return tCompRev.getType().equalsIgnoreCase(typeName);
		
	}

	public static TCComponent getTargetComponent() {
		return (TCComponent)AIFUtility.getCurrentApplication().getTargetComponent();
		
	}
	public static TCComponent[] getTargetComponents() {
		InterfaceAIFComponent[] targComp = AIFUtility.getCurrentApplication().getTargetComponents();
		TCComponent[] tcComp = new TCComponent[targComp.length]; 
		for (int i = 0; i < targComp.length; i++)
			tcComp[i] = (TCComponent) targComp[i] ;
		return tcComp;
	}

	public static TCComponent[] getChildren(TCComponent tcComp) throws TCException 
	{
		return tcComp.getRelatedComponents("ps_children");
		
	}
	public static ExpandGRMRelationsPref2 getGRMRelation(String relation ){
		RelationAndTypesFilter[] relTypeFilter 		= new RelationAndTypesFilter[1];
		relTypeFilter[0] 	= new RelationAndTypesFilter();
		relTypeFilter[0].relationTypeName =relation;
		ExpandGRMRelationsPref2 grmIntRel =new ExpandGRMRelationsPref2();
		grmIntRel.info = relTypeFilter;
		grmIntRel.returnRelations = true;
		return grmIntRel;
	}

	public static TCComponentForm getOtherAttributeForm( TCComponentItemRevision tItemRev, boolean create) throws Exception {
		return getOtherAttributeForm(tItemRev, create, false);
	}
	public static TCComponentForm getOtherAttributeForm( TCComponentItemRevision tItemRev, boolean create,boolean ignore) throws Exception {
		TCComponentForm form = null;
		if(!ignore)
			form = (TCComponentForm) getRelCompComponent(tItemRev, OTHER_ATTRIBUTE_FORM_REL,OTHER_ATTRIBUTE_FORM);
		
		if(form == null && create){
			form = (TCComponentForm) createForm(tItemRev, OTHER_ATTRIBUTE_FORM_REL, OTHER_ATTRIBUTE_FORM);
			updateOtherAttributeForm(tItemRev,form);
			/*TCComponent revMasTag = getMasterTag(tItemRev, false);
			ReadProperty readProp = new ReadProperty("ItemRevisionMasterForm",PropertyPath.DEBUG);
			form.setProperties(readProp.getString("OtherAttribute_IRMF_Property").split(","), revMasTag.getProperties(readProp.getString("IRMF_OtherAttribute_Property").split(",")));*/
		}
		return form;
	}
	public static String getOtherAttributeValue(TCComponent itemRev,TCComponent otherForm,String revMasProp,String otherAttrProp) throws TCException{
		String str = "";
		if(otherForm != null)
			str = otherForm.getProperty(otherAttrProp);
		if(str.trim().isEmpty()){
			if(!(itemRev instanceof TCComponentForm))
				itemRev = getMasterTag(itemRev, false);
			str = itemRev.getProperty(revMasProp);
		}
		return str;
		
	}
	private static void updateOtherAttributeForm(TCComponent tItemRev,TCComponent otherForm) throws Exception{
		//TCComponentForm otherForm = getOtherAttributeForm((TCComponentItemRevision) tItemRev, true);
		/*ArrayList<TCComponentItemRevision> prevList = getPreviousRevList((TCComponentItemRevision) tItemRev);
		ReadProperty readProp = new ReadProperty("ItemRevisionMasterForm",PropertyPath.DEBUG);
		String[] revmasProp = readProp.getString("IRMF_OtherAttribute_Property").split(",");
		String[] otherAttrProp = readProp.getString("OtherAttribute_IRMF_Property").split(",");
		if(prevList.size()>0){
			TCComponentForm prevForm = getOtherAttributeForm(prevList.get(prevList.size()-1),false);
			if(prevForm!=null)
				for (String string : otherAttrProp) {
					if(otherForm.getProperty(string).trim().isEmpty()){
						otherForm.setProperty(string, prevForm.getProperty(string));
					}
				}
		}
		TCComponent revMasTag = TC.getMasterTag(tItemRev, false);
		for (int i = 0; i< revmasProp.length; i++) {
			if(otherForm.getProperty(otherAttrProp[i]).trim().isEmpty()){
				otherForm.setProperty(otherAttrProp[i], revMasTag.getProperty(revmasProp[i]));
			}
		}*/
	}
	/*public static String getTCDataLink() {
		String serverPath = null;
		InterfaceServerConnection serverConnection = TC.session.getServerConnection();
		if (serverConnection instanceof TcServiceGatewayCorbaConnection)
	    {
	      TcServiceGatewayCorbaConnection cobCon = (TcServiceGatewayCorbaConnection)serverConnection;
	      System.out.println(cobCon.getGatewayService().getPdiServerIOR());
	      serverPath = "iiop:"+cobCon.getHost()+":"+cobCon.getPort()+":"+"/"+cobCon.getMarkerServerName();
	      System.out.println("iiop:"+cobCon.getHost()+":"+cobCon.getPort()+":"+"/"+cobCon.getMarkerServerName());
	    }else if(serverConnection instanceof TcServiceGatewayWebServiceConnection){
	    	TcServiceGatewayWebServiceConnection cobCon = (TcServiceGatewayWebServiceConnection) serverConnection;
	    	serverPath = cobCon.getHost();
	    }
		return serverPath;
	}*/

	public static TCComponentSignoff getsignoff(TCComponentTask task) 
	{
		try 
		{
			TCComponentSignoff[] tcSignoffs = (task).getValidSignoffs();
			for (TCComponentSignoff tcSignoff : tcSignoffs) 
			{
				if(tcSignoff.getGroupMember().getUser().equals(TC.user))
					return tcSignoff;
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public static void Message(Exception e) 
	{
		Message(null, e);
	}
	
	public static void Message(JDialog dialog, Exception e) 
	{
		e.printStackTrace();
		JOptionPane.showMessageDialog(dialog, e, "ERROR", JOptionPane.ERROR_MESSAGE);
		//MessageBox.post(e);
	}
}
