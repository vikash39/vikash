/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           Test.java          
#      Module          :           util          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Mar 14, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package util;

import java.text.MessageFormat;

/**
 * @author Administrator
 *
 */
public class Test {

	public static void main(String[] args) {
		String message = "On the test run at {0} on {2}, we found {1} prime numbers";
		
		MessageFormat mf = new MessageFormat(message);
		
		System.out.println(mf.format(new Object[] {"A","B","C"}));
	}
}
