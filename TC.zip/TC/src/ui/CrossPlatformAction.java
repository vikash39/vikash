/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           CrossPlatformAction.java          
#      Module          :           ui          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Mar 29, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package ui;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Administrator
 *
 */
public class CrossPlatformAction extends AbstractHandler{

	/* (non-Javadoc)
	 * @see org.eclipse.core.commands.IHandler#execute(org.eclipse.core.commands.ExecutionEvent)
	 */
	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		
		String popupName = ((Event) event.getTrigger()).widget.toString();
		popupName = getLast(getFirst(popupName,"}"),"{");
		if(popupName.equalsIgnoreCase("TC")){
			Display display = Display.getDefault();
			Shell parentShell = new Shell(display);
			new CrossPlatform_UI(parentShell);
		}
		return null;
	}
	
	public static String getLast(String str, String sIndex){
		if(str.contains(sIndex))
			return str.substring(str.indexOf(sIndex)+1);
		else
			return str ;
	}
	
	public static String getFirst(String str, String sIndex){

		if(str.contains(sIndex))
			return str.substring(0,str.indexOf(sIndex));
		else
			return str ;
	}

}
