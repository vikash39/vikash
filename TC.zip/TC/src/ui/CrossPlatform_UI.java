/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           CrossPlatform_UI.java          
#      Module          :           ui          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Mar 29, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.dialogs.TitleAreaDialog;
import org.eclipse.nebula.widgets.grid.Grid;
import org.eclipse.nebula.widgets.grid.GridColumn;
import org.eclipse.nebula.widgets.grid.GridColumnGroup;
import org.eclipse.nebula.widgets.grid.GridHeaderRenderer;
import org.eclipse.nebula.widgets.grid.GridItem;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Item;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.wb.swt.SWTResourceManager;

import com.teamcenter.rac.aifrcp.AIFUtility;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentItem;
import com.teamcenter.rac.kernel.TCComponentItemRevision;
import com.teamcenter.rac.kernel.TCComponentItemType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;

import tc.ConfMat;
import tc.PropertyPath;
import tc.ReadProperty;
import util.TC;

/**
 * @author Administrator
 *
 */
public class CrossPlatform_UI extends TitleAreaDialog {
	private Grid tblCrossPlatform;
	private Combo cmbPlatform;
	private Combo cmbProject;
	private Combo cmbBaseVariant;
	private Label lblBaseVariant;
	private Label lblProject;
	private Label lblPlatform;
	private Button btnLoad;
	private Button btnExport;
	ReadProperty readProp = null;
	TCSession comUtilSession = null;
	private TCComponent[] pltrev;
	public static final Font FONT_TAHOMA_BOLD = SWTResourceManager.getFont("Tahoma", 8, SWT.BOLD);
	private TCComponentItemRevision tcITemRev;
	private Group grpAction;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public CrossPlatform_UI(Shell parentShell) {
		super(parentShell);
		setShellStyle(SWT.MAX | SWT.RESIZE);
		setHelpAvailable(false);
		open();
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		try {
			readProp= new ReadProperty("CADStepProcess", PropertyPath.DEBUG);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		setTitle("Cross Platform Matrix");
		comUtilSession = (TCSession) AIFUtility.getCurrentApplication().getSession();
		Composite area = (Composite) super.createDialogArea(parent);
		Composite container = new Composite(area, SWT.NONE);
		container.setLayout(new GridLayout(1, false));
		container.setLayoutData(new GridData(GridData.FILL_BOTH));

		Group grpFilter = new Group(container, SWT.NONE);
		grpFilter.setLayout(new GridLayout(8, false));
		GridData gd_grpFilter = new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1);
		gd_grpFilter.heightHint = 44;
		grpFilter.setLayoutData(gd_grpFilter);

		lblPlatform = new Label(grpFilter, SWT.NONE);
		lblPlatform.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblPlatform.setText("Platform :");

		cmbPlatform = new Combo(grpFilter, SWT.NONE);
		cmbPlatform.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		String[] strPlatform=readProp.getString("Platform").split(",");
		setComboValues(strPlatform, cmbPlatform);

		cmbPlatform.addSelectionListener(new SelectionListener() {

			private String strPlatformVal;

			public void widgetSelected(SelectionEvent arg0) {

				strPlatformVal = cmbPlatform.getText();
				String[] strroject = readProp.getString(strPlatformVal.replace(" " ,"#")+"_Project").split(",");
				setComboValues(strroject, cmbProject);
			}


			public void widgetDefaultSelected(SelectionEvent arg0) {
			}
		});

		lblProject = new Label(grpFilter, SWT.NONE);
		lblProject.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblProject.setText("Project :");

		cmbProject = new Combo(grpFilter, SWT.NONE);
		cmbProject.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		//String[] strProject=readProp.getString("Platform").split(",");

		lblBaseVariant = new Label(grpFilter, SWT.NONE);
		lblBaseVariant.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		lblBaseVariant.setText("Base Variant :");

		cmbBaseVariant = new Combo(grpFilter, SWT.NONE);
		cmbBaseVariant.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));

		cmbProject.addSelectionListener(new SelectionListener() {



			public void widgetSelected(SelectionEvent arg0) {



				String strProject = cmbProject.getText();
				if (!strProject .isEmpty()) 
				{
					cmbBaseVariant.removeAll();
					getRelatedModel();
					try 
					{
						pltrev = tcITemRev.getRelatedComponents("M2_Ebom_DerivedModels");
						ArrayList<String> lst_model = new ArrayList<String>();
						Hashtable<String, TCComponent> map_sorted = new Hashtable<>();
						for (int iplfrmcnt = 0; iplfrmcnt < pltrev.length; iplfrmcnt++) 
						{
							//						TCComponent mdlprop = pltrev[iplfrmcnt].getRelatedComponent(registry.getString("PROP_RELATION_IMAN_MASTER_FORM_REV"));
							String Mitemid = pltrev[iplfrmcnt].getProperty("object_string");
							String strProName = pltrev[iplfrmcnt].getProperty("gov_classification");//Project information

							if (strProject.contains(strProName))
							{
								lst_model.add(Mitemid);
								map_sorted.put(Mitemid, pltrev[iplfrmcnt]);
								//comboModel.add(Mitemid);
							}
						}
						Collections.sort(lst_model);
						ArrayList<TCComponent> lst_model_rev = new ArrayList<TCComponent>();
						for (String string : lst_model) {
							lst_model_rev.add(map_sorted.get(string));
						}
						
						cmbBaseVariant.setItems(lst_model.toArray(new String[lst_model.size()]));
						cmbBaseVariant.setData("RevList",lst_model_rev);
					} 
					catch (TCException e) 
					{
						e.printStackTrace();
					}
				}
				else
					cmbBaseVariant.removeAll();
				/*boolean blnMandatory=getMandatoryStatus();
				if(blnMandatory){
					btnSubmit.setEnabled(true);
					btnExclusive.setEnabled(true);
				}
				else{
					btnSubmit.setEnabled(false);
					btnExclusive.setEnabled(false);
				}*/


			}

			public void widgetDefaultSelected(SelectionEvent arg0) {

			}
		});

		btnLoad = new Button(grpFilter, SWT.NONE);
		btnLoad.setText("Load");
		
		btnExport = new Button(grpFilter, SWT.NONE);
		btnExport.setText("Export");
		
		grpAction = new Group(container, SWT.NONE);
		grpAction.setLayout(new GridLayout(1, false));
		grpAction.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		btnLoad.addSelectionListener(new SelectionListener() {

			public void widgetSelected(SelectionEvent arg0) {

				
				try {
					if(tblCrossPlatform!=null)
						tblCrossPlatform.dispose();
					tblCrossPlatform = new Grid(grpAction, SWT.BORDER | SWT.FULL_SELECTION |SWT.H_SCROLL | SWT.V_SCROLL);
					GridData gd_table = new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1);
					gd_table.heightHint = 60;
					tblCrossPlatform.setLayoutData(gd_table);
					tblCrossPlatform.setHeaderVisible(true);
					tblCrossPlatform.setLinesVisible(true);
					
					ArrayList<TCComponent> lst_model_rev_sort = new ArrayList<>();
					ArrayList<TCComponent> lst_model_rev = (ArrayList<TCComponent>) cmbBaseVariant.getData("RevList");
					ArrayList<String> lst_ids = new ArrayList<>();
					lst_model_rev_sort.add(lst_model_rev.get(cmbBaseVariant.getSelectionIndex()));
					lst_ids.add(TC.getIdandRev(lst_model_rev.get(cmbBaseVariant.getSelectionIndex())));
					for (TCComponent tc_comp : lst_model_rev) {
						if(!lst_model_rev_sort.get(0).equals(tc_comp)) {
							lst_model_rev_sort.add(tc_comp);
							lst_ids.add(TC.getIdandRev(tc_comp));
						}
					}
					
					
					ConfMat conf = new ConfMat(lst_ids.get(0),lst_ids);
					LinkedHashMap<String, LinkedHashMap<String, Integer>> map_ex_matrix = conf.getExclusiveMatrix();
					
					
					GridColumn tblclmnModel = new GridColumn(tblCrossPlatform, SWT.NONE);
					tblclmnModel.setWidth(300);
					tblclmnModel.setText(cmbPlatform.getText()+" Models");

					
					for(int i = 0; i< lst_model_rev_sort.size(); i++) {
						GridColumn tblclmnNewColumn = new GridColumn(tblCrossPlatform, SWT.WRAP | SWT.CENTER );
						tblclmnNewColumn.setWidth(300);
						tblclmnNewColumn.setText(lst_model_rev_sort.get(i).getProperty("object_string"));
						tblclmnNewColumn.setWordWrap(true);
						tblclmnNewColumn.setResizeable(false);
					
					}
					RGB rgbColor = new RGB(255,204,153);
					Color backgroundColor = new Color(Display.getDefault(), rgbColor.red,rgbColor.green,rgbColor.blue);
					
					for(int i = 0; i< lst_model_rev_sort.size(); i++) {
						GridItem tBaseItem =null;
						boolean b = true;
						for(int j = 0; j< lst_model_rev_sort.size(); j++) {
							if(j == 0) {
								tBaseItem = new GridItem(tblCrossPlatform, SWT.WRAP | SWT.CENTER );
								tBaseItem.setHeight(50);
								//tBaseItem.
								tBaseItem.setText(0, lst_model_rev_sort.get(i).getProperty("object_string"));
								tBaseItem.setBackground(0, backgroundColor);
								tBaseItem.setFont(0, FONT_TAHOMA_BOLD);
							}
							if(j<i)
								continue;
							LinkedHashMap<String, Integer> lst_ex_cnt = map_ex_matrix.get(lst_ids.get(j));
							String str = "0";
							if(lst_ex_cnt.containsKey(lst_ids.get(i)))
								str = lst_ex_cnt.get(lst_ids.get(i)).toString();
							tBaseItem.setText(j+1,str);
							if(b) {
								tBaseItem.setBackground(j+1, SWTResourceManager.getColor(SWT.COLOR_GREEN));
								b =false;
							}
						}
					}
					
					int iColumns = tblCrossPlatform.getColumnCount();
					for (int i = 0; i < iColumns; i++) {
						setColHeaderRendering(rgbColor,tblCrossPlatform.getColumn(i));
					}
					/*for (int iModels = 0; iModels < pltrev.length; iModels++) {
						if(!pltrev[iModels].getProperty("object_string").equalsIgnoreCase(cmbBaseVariant.getText())) {
							TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
							tblclmnNewColumn.setWidth(300);
							tblclmnNewColumn.setText(pltrev[iModels].getProperty("object_string"));

							TableItem tModelRowItem = new TableItem(table, SWT.NONE);
							tModelRowItem.setText(0, pltrev[iModels].getProperty("object_string"));
						}
					}*/
				} catch (Exception e) {
					e.printStackTrace();
				}
				grpAction.layout();
				getShell().layout();
			}

			public void widgetDefaultSelected(SelectionEvent arg0) {

			}
		});

		

		

		

		/*TableColumn tblclmnNewColumn = new TableColumn(table, SWT.NONE);
		tblclmnNewColumn.setWidth(100);
		tblclmnNewColumn.setText("New Column");*/

		return area;
	}

	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(757, 397);
	}

	/** This method is used to set the LOV values by getting the String array of values and Combo box as parameter.. */
	void setComboValues(String[] sValues , Combo cmbtoAdd){

		for (String strValues : sValues) {
			cmbtoAdd.add(strValues);
		}

	}


	/**
	 * This method for get related model from TC
	 */
	private void getRelatedModel() 
	{
		try 
		{
			TCComponentItem plfrmitem = findItem(cmbPlatform.getText());

			TCComponent[] rev_lists = plfrmitem.getRelatedComponents("revision_list");
			ArrayList<TCComponent> revlist=new ArrayList<TCComponent>();
			ArrayList<TCComponent> revcreBaselineList=new ArrayList<TCComponent>();
			for (int i = 0; i < rev_lists.length; i++) {
				if(!rev_lists[i].getProperty("release_status_list").toString().contains("TC Baselined")){//if(!rev_lists[i].getProperty("release_status_list").toString().contains("TC Baselined"))
					revlist.add(rev_lists[i]);
				}
				else{
					revcreBaselineList.add(rev_lists[i]);
				}
			}
			if(revlist.size()==1){
				int tmpRevID = 0;
				TCComponentItemRevision [] tmpBaselineRev = new TCComponentItemRevision[revcreBaselineList.size()];
				revcreBaselineList.toArray(tmpBaselineRev);
				for (int i=0;i<tmpBaselineRev.length;i++){
					String itemReID = ((TCComponentItemRevision) tmpBaselineRev[i]).getProperty("item_revision_id");
					int itemRevID = 0;

					StringTokenizer revIDs = new StringTokenizer(itemReID, ".");
					while (revIDs.hasMoreElements()) {
						itemRevID = Integer.parseInt(revIDs.nextToken());
					}
					//					baselineRev.add(tmpBaselineRev[i]);
					if (itemRevID >tmpRevID){
						//					    latestbaselineRev = ((TCComponentItemRevision) tmpBaselineRev[i]);
						tcITemRev = ((TCComponentItemRevision) tmpBaselineRev[i]);
						tmpRevID = itemRevID;
					}
				}

			}
		} 
		catch (Exception e) {
		}

	}

	/* * Finds the Item
		@param  itemId - Item ID
		@return TCComponentItem
	 */ 
	public TCComponentItem findItem(String itemId){ 
		return findItem(null,itemId);
	}
	/**
	 * Finds the Item
		@param itemType - Item Type
		@param itemId  - Item ID
		@return
	 *TCComponentItem
	 */
	public  TCComponentItem findItem(String itemType, String itemId){
		try {

			if(itemType == null || itemType.trim().isEmpty())
				itemType = "Item";
			TCComponentItemType tItemType =(TCComponentItemType) comUtilSession.getTypeComponent(itemType);
			TCComponentItem tItem = tItemType.findItems(itemId)[0];
			return tItem;
		} 
		catch (TCException e) 
		{
			e.printStackTrace();
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	
	/** This method will set the color for Grid column headers by getting the Grid, Column Name, RGB color and boolean column group as parameter.. 
	 * @param iCol */
	static void setColHeaderRendering(final RGB rgbColor, Item item)
	{
		GridHeaderRenderer gridRenderer=new GridHeaderRenderer() {

			@Override
			public void paint(GC gc, Object value) {

				Color backgroundColor = new Color(getDisplay(), rgbColor.red,rgbColor.green,rgbColor.blue);
				Color foregroundColor = new Color(getDisplay(), 255,255,255);
				Color selectionColor = new Color(getDisplay(), 153,204,255);

				/** get column.. */


				/** get selection state.. */
				boolean selected = this.isSelected();

				/** get coordinates.. */
				int x = getBounds().x; 
				int y = getBounds().y;
				int width = getBounds().width;
				int height = getBounds().height;

				/** set background color and draw rectangle.. */
				Color oldBackground = gc.getBackground();
				Color oldForeground = gc.getForeground();

				if (selected) {
					gc.setBackground(selectionColor);	
					gc.setForeground(foregroundColor);	
					gc.fillGradientRectangle(x, y, width, height, true);

					gc.setForeground(selectionColor);
					gc.drawRectangle(x,y,width-1,height-1);

				} else {
					gc.setBackground(backgroundColor);	
					gc.setForeground(foregroundColor);	
					gc.fillGradientRectangle(x, y, width, height, true);

					gc.setForeground(oldForeground);
					gc.drawRectangle(x,y,width,height);
				}


				gc.setBackground(oldBackground);	
				gc.setForeground(oldForeground);
				Item item= (Item) value;

				/** draw text.. */
				String text = item.getText();	
				Point idxpix = gc.textExtent(text);
				Image img1=item.getImage();
				int textOffset = 3;
				int val =0;
				if(item instanceof GridColumn) 
					val = ((GridColumn)item).getAlignment() == SWT.CENTER ? ((GridColumn)item).getWidth()-idxpix.x : 0;
				else if(item instanceof GridColumnGroup){
					GridColumn[] arr_col = ((GridColumnGroup)item).getColumns();
					int wid = 0;
					for (GridColumn gridColumn : arr_col) {
						wid += gridColumn.getWidth();
					}
					val =  wid-idxpix.x;
				}
				int startPt=val/2+x+textOffset;
				int endPt=y+textOffset;
				gc.setFont(FONT_TAHOMA_BOLD);
				if(img1!=null)
				{
					gc.drawImage(img1,startPt,endPt);
					gc.drawString(text, startPt+20, endPt, true);
				}
				else
				{
					gc.drawString(text, startPt, endPt, true);
				}


			}

			@Override
			public Point computeSize(GC gc, int wHint, int hHint, Object value) {
				return null;
			}

			@Override
			public boolean notify(int event, Point point, Object value) {
				return false;
			}
		};

		if(item instanceof GridColumn)
			((GridColumn)item).setHeaderRenderer( gridRenderer);
		else if(item instanceof GridColumnGroup)
			((GridColumnGroup)item).setHeaderRenderer( gridRenderer);

	}
}
