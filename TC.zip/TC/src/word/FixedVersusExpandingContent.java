package word;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * Brings face to face a ScrolledComposite with fixed content and, on the right side, a ScrolledComposite with expanding content.
 */
public class FixedVersusExpandingContent {

  private static final int STYLE = SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL;

  public static void main( String[] args ) {
    Display display = new Display();
    Shell shell = new Shell( display );
    shell.setText( "ScrolledComposite in 'scroll' and 'browser' mode" );
    shell.setLayout( new FillLayout() );
    ScrolledComposite leftSC = new ScrolledComposite( shell, STYLE );
    CLabel leftLabel = new CLabel( leftSC, SWT.NONE );
    leftLabel.setBackground( display.getSystemColor( SWT.COLOR_DARK_GREEN ) );
    leftLabel.setForeground( display.getSystemColor( SWT.COLOR_WHITE ) );
    String leftText 
      = "Fixed size content.\n\n"
      + "Scrollbars appear if the\n"
      + "ScrolledComposite\nis resized to be too small\n"
      + "to show the entire content.";
    leftLabel.setText( leftText );
    leftLabel.setAlignment( SWT.CENTER );
    leftLabel.setSize( 250, 250 );
    leftSC.setContent( leftLabel );
    ScrolledComposite rightSC = new ScrolledComposite( shell, STYLE );
    CLabel rightLabel = new CLabel( rightSC, SWT.NONE );
    String rightText 
      = "Expanding content.\n\n"
      + "The content has a minimum size.\n"
      + "If the ScrolledComposite is\n"
      + "resized bigger than the minimum size,\n"
      + "the content will grow in size.\n"
      + "If the ScrolledComposite is made too small\n"
      + "to show the minimum size, scrollbars will appear.";
    rightLabel.setText( rightText );
    rightLabel.setBackground( display.getSystemColor( SWT.COLOR_DARK_GRAY ) );
    rightLabel.setForeground( display.getSystemColor( SWT.COLOR_WHITE ) );
    rightLabel.setAlignment( SWT.CENTER );
    rightSC.setContent( rightLabel );
    rightSC.setExpandHorizontal( true );
    rightSC.setExpandVertical( true );
    rightSC.setMinSize( 250, 250 );
    shell.setSize( 600, 300 );
    shell.open();
    while( !shell.isDisposed() ) {
      if( !display.readAndDispatch() )
        display.sleep();
    }
    display.dispose();
  }
}