/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           DocTable.java          
#      Module          :           word          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - CMVR          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                   Name					        Description of Change
#  Jun 27, 2018				  Vinothkumar Arthanari			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package word;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IConfiguration;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.data.ISpanningDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.hideshow.ColumnHideShowLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.SpanningDataLayer;
import org.eclipse.nebula.widgets.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.layer.cell.DataCell;
import org.eclipse.nebula.widgets.nattable.painter.cell.TextPainter;
import org.eclipse.nebula.widgets.nattable.reorder.ColumnReorderLayer;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.ui.binding.UiBindingRegistry;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTHeight;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;

/**
 * @author Vinothkumar Arthanari
 *
 */
public class DocTable extends Dialog {

	private Composite composite;
	private Composite container;

	/**
	 * Create the dialog.
	 * @param parentShell
	 */
	public DocTable(Shell parentShell) {
		super(parentShell);
		setShellStyle(SWT.CLOSE | SWT.MIN | SWT.MAX | SWT.RESIZE);
	}

	/**
	 * Create contents of the dialog.
	 * @param parent
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container1 = (Composite) super.createDialogArea(parent);
		
		ScrolledComposite c1 = new ScrolledComposite(container1, SWT.BORDER | SWT.H_SCROLL | SWT.V_SCROLL);
		c1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		c1.setBackground(parent.getDisplay().getSystemColor(SWT.COLOR_RED));
		
		c1.setExpandHorizontal(true);
		//c1.setExpandVertical(true);
		    
		container = new Composite(c1, SWT.NONE);
		container.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		container.setLayout(new FillLayout(SWT.VERTICAL));
		container.setBackground(parent.getDisplay().getSystemColor(SWT.COLOR_BLUE));
		container.setSize(600, 800);
		
		/*for(int i = 0; i< 10 ; i++) {
			Text t = new Text(container, SWT.BORDER);
			//t.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
			t.setText("Hello");
		}*/
		c1.setContent(container);
		//c1.setMinSize(container.computeSize(SWT.DEFAULT, SWT.DEFAULT));
		try {
			XWPFDocument document = getDocument();
			List<XWPFTable> tables = document.getTables();
			for (XWPFTable xwpfTable : tables) {
				
				createNatTable(xwpfTable);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		

		
		return container1;
	}

	/**
	 * @param xwpfTable 
	 * 
	 */
	private void createNatTable(XWPFTable table) {
		List<XWPFTableRow> arr_row = table.getRows();
		int iColCnt = 0;
		ArrayList<ColumnMergeInfo> lst_cell_merge_info = new ArrayList<>();
		ArrayList<RowMergeInfo> lst_row_merge_info = new ArrayList<>();
		ArrayList<ArrayList<String>> lst_row = new ArrayList<>();
		ArrayList<Integer> lst_int = new ArrayList<>();
		for (int i = 0; i< arr_row.size() ; i++) {
			List<XWPFTableCell> arr_cell = arr_row.get(i).getTableCells();
			ArrayList<String> lst_cell = new ArrayList<>();
			Collections.addAll(lst_cell, new String[getColumnCount(arr_cell)]);
			try {
				
				//List<CTHeight> trHeightList = arr_row.get(i).getCtRow().getTrPr().getTrHeightList();
				lst_int.add(arr_row.get(i).getHeight()/4);
			}catch (Exception e) {
				lst_int.add(40);
			}
			
			int idx = 0;
			for (XWPFTableCell xwpfTableCell : arr_cell) {
				System.out.println(xwpfTableCell.getText());	
				try {
					lst_cell.set(idx, xwpfTableCell.getText());
					
					if(xwpfTableCell.getCTTc().getTcPr().getVMerge()!=null) {
						int iMergStat = xwpfTableCell.getCTTc().getTcPr().getVMerge().getVal().intValue(); // 1 - Continue.    2 - Restart;
						setRowMergeInfo(lst_row_merge_info,i,idx,iMergStat);
					}
					if(xwpfTableCell.getCTTc().getTcPr().getGridSpan()!=null) {
						int iSpan = xwpfTableCell.getCTTc().getTcPr().getGridSpan().getVal().intValue();
						ColumnMergeInfo cellMergeInfo = new ColumnMergeInfo();
						cellMergeInfo.iRow = i;
						cellMergeInfo.iCol = idx;
						cellMergeInfo.iColSpan = iSpan;
						lst_cell_merge_info.add(cellMergeInfo);
						idx += iSpan;
					}
					else idx++;
				} catch (Exception e) {
					System.out.println(xwpfTableCell.getText());	
				}
			}
			lst_row.add(lst_cell);
		}
		
		String[] srr_col_name = new String[lst_row.get(0).size()];
		for(int i = 0 ; i< srr_col_name.length ; i++)
			srr_col_name[i] = "COL_"+i;
		
		ListOfListDataProvider prov = new ListOfListDataProvider(lst_row,lst_cell_merge_info,lst_row_merge_info);
		SpanningDataLayer spanningDataLayer = new SpanningDataLayer(prov);
		for(int i = 0; i< lst_int.size() ; i++)
			spanningDataLayer.setRowHeightByPosition(i, lst_int.get(i));
		ViewportLayer layer = new ViewportLayer(new SelectionLayer(spanningDataLayer));
        layer.setRegionName(GridRegion.BODY);

        
        SelectionLayer selectionLayer = new SelectionLayer(new ColumnHideShowLayer(new ColumnReorderLayer(new SpanningDataLayer(prov))));
	    ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);
	    viewportLayer.setVerticalScrollbarEnabled(false);
	    viewportLayer.setHorizontalScrollbarEnabled(false);
	    
	    DefaultColumnHeaderDataProvider columnHeaderDataProvider = new DefaultColumnHeaderDataProvider(srr_col_name);
	    DataLayer columnHeaderDataLayer = new DataLayer(columnHeaderDataProvider);
	    ILayer columnHeaderLayer = new ColumnHeaderLayer(columnHeaderDataLayer,viewportLayer, selectionLayer);

	    DefaultRowHeaderDataProvider rowHeaderDataProvider = new DefaultRowHeaderDataProvider(prov);
	    DataLayer rowHeaderDataLayer = new DataLayer(rowHeaderDataProvider);
	    rowHeaderDataLayer.setDefaultColumnWidth(40);
	    
	    ILayer rowHeaderLayer = new RowHeaderLayer(rowHeaderDataLayer,viewportLayer, selectionLayer);

	    ILayer cornerLayer = new CornerLayer(new DataLayer(new DefaultCornerDataProvider(columnHeaderDataProvider,rowHeaderDataProvider)),rowHeaderLayer,columnHeaderLayer);

	    GridLayer gridLayer = new GridLayer(viewportLayer,columnHeaderLayer, rowHeaderLayer, cornerLayer);
	    
	    ColumnOverrideLabelAccumulator columnLabelAccumulator =new ColumnOverrideLabelAccumulator(viewportLayer);
	   /* for(int i = 0 ; i< srr_col_name.length ; i++)
	    	columnLabelAccumulator.registerColumnOverrides(i, "TEXT");
	    viewportLayer.setConfigLabelAccumulator(columnLabelAccumulator);*/
	    
	    
		final NatTable natTable = new NatTable(container, gridLayer,true);
		gridLayer.addConfiguration(new AbstractRegistryConfiguration() {
			
			
			@Override
			public void configureRegistry(IConfigRegistry configRegistry) {
				TextPainter Painter = new TextPainter(true, true);
				Painter.setCalculateByTextHeight(true);
				Painter.setCalculateByTextLength(true);
				configRegistry.registerConfigAttribute(CellConfigAttributes.CELL_PAINTER, Painter,DisplayMode.NORMAL, "TEXT");
				
				
			}
			
			
		});
		//natTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		natTable.configure();
		natTable.setSize(600, 1000);
	}
		
	/**
	 * @param lst_row_merge_info
	 * @param i
	 * @param idx
	 * @param iMergStat
	 */
	private void setRowMergeInfo(ArrayList<RowMergeInfo> lst_row_merge_info, int i, int idx, int iMergStat) {
		if(iMergStat == 2) {
			RowMergeInfo info = new RowMergeInfo();
			info.iRow = i;
			info.iCol = idx;
			info.iRowSpan = 1; 
			lst_row_merge_info.add(info);	
		}else {
			RowMergeInfo rowMergeInfoval = null;
			for (RowMergeInfo rowMergeInfo : lst_row_merge_info) {
				if(rowMergeInfo.iCol == idx) {
					if(rowMergeInfoval == null)
						rowMergeInfoval = rowMergeInfo;
					if(rowMergeInfoval.iRow<rowMergeInfo.iRow)
						rowMergeInfoval = rowMergeInfo;
				}
			}
			if(rowMergeInfoval == null)
				System.out.println("Error in Span Logics...");
			rowMergeInfoval.iRowSpan++;
		}
		
	}

	/**
	 * @param lst_cell_merge_info
	 * @param i
	 * @param idx
	 */
	private void setRowMergeInfo(ArrayList<ColumnMergeInfo> lst_cell_merge_info, int iRow, int idx) {
		
		for (ColumnMergeInfo cellMergeInfo : lst_cell_merge_info) {
			if(cellMergeInfo.iRow == iRow)
				cellMergeInfo.iCol = idx;
				
		}
		
	}

	private static int getColumnCount(List<XWPFTableCell> arr_cell){
		int idx = 0;
		for (XWPFTableCell xwpfTableCell : arr_cell) {
			try {
				if(xwpfTableCell.getCTTc().getTcPr().getGridSpan()!=null)
					idx += xwpfTableCell.getCTTc().getTcPr().getGridSpan().getVal().intValue();
				else idx++;
			} catch (Exception e) {
				System.out.println(xwpfTableCell.getText());	
			}
		}
		return idx;
	}

	private XWPFDocument getDocument() throws Exception{
		File file = new File("C:\\temp\\Test Value.docx");
		FileInputStream fis = new FileInputStream(file.getAbsolutePath());

		XWPFDocument document = new XWPFDocument(fis);
		return document;
	}
	/**
	 * Create contents of the button bar.
	 * @param parent
	 */
	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
		createButton(parent, IDialogConstants.CANCEL_ID, IDialogConstants.CANCEL_LABEL, false);
	}

	/**
	 * Return the initial size of the dialog.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}
	
	public static void main(String[] args) {
		new DocTable(new Shell()).open();
	}
	
	class ListOfListDataProvider implements IDataProvider, ISpanningDataProvider{

		ArrayList<ArrayList<String>> lst_row;
		ArrayList<ColumnMergeInfo> lst_cell_merge_info;
		private ArrayList<RowMergeInfo> lst_row_merge_info;
		/**
		 * @param lst_row 
		 * @param lst_cell_merge_info 
		 * @param lst_row_merge_info 
		 * 
		 */
		public ListOfListDataProvider(ArrayList<ArrayList<String>> lst_row, ArrayList<ColumnMergeInfo> lst_cell_merge_info, ArrayList<RowMergeInfo> lst_row_merge_info) {
			this.lst_row = lst_row;
			this.lst_cell_merge_info = lst_cell_merge_info;
			this.lst_row_merge_info = lst_row_merge_info;
		}
		/* (non-Javadoc)
		 * @see org.eclipse.nebula.widgets.nattable.data.IDataProvider#getColumnCount()
		 */
		@Override
		public int getColumnCount() {
			// TODO Auto-generated method stub
			return lst_row.get(0).size();
		}

		/* (non-Javadoc)
		 * @see org.eclipse.nebula.widgets.nattable.data.IDataProvider#getDataValue(int, int)
		 */
		@Override
		public Object getDataValue(int columnIndex, int rowIndex) {
			
			return lst_row.get(rowIndex).get(columnIndex);
		}

		/* (non-Javadoc)
		 * @see org.eclipse.nebula.widgets.nattable.data.IDataProvider#getRowCount()
		 */
		@Override
		public int getRowCount() {
			// TODO Auto-generated method stub
			return lst_row.size();
		}

		/* (non-Javadoc)
		 * @see org.eclipse.nebula.widgets.nattable.data.IDataProvider#setDataValue(int, int, java.lang.Object)
		 */
		@Override
		public void setDataValue(int columnIndex, int rowIndex, Object newValue) {
			lst_row.get(rowIndex).set(columnIndex, newValue == null ? null : newValue.toString());
			
		}
		/* (non-Javadoc)
		 * @see org.eclipse.nebula.widgets.nattable.data.ISpanningDataProvider#getCellByPosition(int, int)
		 */
		@Override
		public DataCell getCellByPosition(int col, int row) {
			int iRow = row;
			int iCol = col;
			int iRowSpan = 1;
			int iColSpan = 1;
			
			try {
				ColumnMergeInfo ref = getColumnReference(col,row);
				if(ref != null) {
					getColumnReference(col,row);
					iCol = ref.iCol;
					iColSpan = ref.iColSpan;
				}
				RowMergeInfo row_ref = getRowReference(col,row);
				if(row_ref!= null) {
					 getRowReference(col,row);
					iRow = row_ref.iRow;
					iRowSpan = row_ref.iRowSpan;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(iRowSpan > 1 && iColSpan > 1) {
				System.out.println(row+":"+col);
				System.out.println("\t\t"+iCol+":"+iRow+"::["+iColSpan+":"+iRowSpan+"]");
			}
			return  new  DataCell(iCol, iRow, iColSpan, iRowSpan);
		}
		/**
		 * @param col
		 * @param row
		 * @return 
		 */
		private RowMergeInfo getRowReference(int col, int row) {
			for (RowMergeInfo rowMergeInfo : lst_row_merge_info) {
				if(rowMergeInfo.iCol == col)
					if(rowMergeInfo.iRow<=row)
						if(rowMergeInfo.iRow+rowMergeInfo.iRowSpan>row)
							return rowMergeInfo;
			}
			return null;
			
		}
		
		/**
		 * @param col
		 * @param row
		 * @return 
		 */
		private ColumnMergeInfo getColumnReference(int col, int row) {
			for (ColumnMergeInfo cellMergeInfo : lst_cell_merge_info) {
				if(cellMergeInfo.iRow == row)
					if(cellMergeInfo.iCol<=col)
						if(cellMergeInfo.iCol+cellMergeInfo.iColSpan>col)
							return cellMergeInfo;
			}
			return null;
			
		}
		
	}
	class ColumnMergeInfo{
		int iRow;
		int iCol;
		int iColSpan;
	}
	class RowMergeInfo{
		int iRow;
		int iCol;
		int iRowSpan;
	}
}
