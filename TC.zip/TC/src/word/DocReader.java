package word;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.POIXMLDocumentPart;
import org.apache.poi.POIXMLProperties;
import org.apache.poi.POIXMLProperties.CustomProperties;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openxmlformats.schemas.officeDocument.x2006.customProperties.CTProperty;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTDocument1;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STMerge;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STMerge.Enum;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DocReader {

	public static void readDocFile(String fileName) {

		try {
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file.getAbsolutePath());

			HWPFDocument doc = new HWPFDocument(fis);

			WordExtractor we = new WordExtractor(doc);

			String[] paragraphs = we.getParagraphText();
			
			System.out.println("Total no of paragraph "+paragraphs.length);
			for (String para : paragraphs) {
				System.out.println(para.toString());
			}
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void readDocxFile(String fileName) {

		try {
			File file = new File(fileName);
			FileInputStream fis = new FileInputStream(file.getAbsolutePath());

			XWPFDocument document = new XWPFDocument(fis);
			updateCustomProperties(document);


			List<XWPFParagraph> paragraphs = document.getParagraphs();
			XWPFTable table = document.getTables().get(0);
			for (XWPFTableRow row : table.getRows()) {
				for (XWPFTableCell cell : row.getTableCells()) {
					System.out.println(cell.getText());
					
				}
			}
				
//			iteratedocumet(document);
		/*	System.out.println("Total no of paragraph "+paragraphs.size());
			for (XWPFParagraph para : paragraphs) {
				System.out.println(para.getText());
			}*/
			
			document.write(new FileOutputStream(new File("C:\\Temp\\2. Table-17 (rev.5)_with modification.docx")));//Test Value1.docx	
			fis.close();
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param document
	 */
	private static void iteratedocumet(XWPFDocument document) {
		Iterator<IBodyElement> body_elt = document.getBodyElementsIterator();
		while(body_elt.hasNext()) {
			IBodyElement elts = body_elt.next();
			if(elts instanceof XWPFParagraph) {
				XWPFParagraph para = (XWPFParagraph) elts;
				System.out.println("Para:"+para.getText());
			} else if(elts instanceof XWPFTable) {
				System.out.println("Table");
			}else
				System.out.println(elts);
		}
		if(body_elt != null)
			return;
		List<XWPFParagraph> paragraphs = document.getParagraphs();
		List<XWPFTable> tables = document.getTables();
		POIXMLDocumentPart relationById = document.getRelationById("VA_1.01");
		System.out.println("Total no of Tables "+tables.size());
		ArrayList<ArrayList<String>> lst_row = new ArrayList<>();
		for (XWPFTable table : tables) {
			List<XWPFTableRow> arr_row = table.getRows();
			int iColCnt = 0;
			for (XWPFTableRow xwpfTableRow : arr_row) {
				List<XWPFTableCell> arr_cell = xwpfTableRow.getTableCells();
				ArrayList<String> lst_cell = new ArrayList<>();
				Collections.addAll(lst_cell, new String[getColumnCount(arr_cell)]);

				int idx = 0;
				System.out.println("-------------");
				
			
				for (XWPFTableCell xwpfTableCell : arr_cell) {
					System.out.println(xwpfTableCell.getText());	
					try {
						lst_cell.set(idx, xwpfTableCell.getText());
						
						if(xwpfTableCell.getCTTc().getTcPr().getGridSpan()!=null)
							idx += xwpfTableCell.getCTTc().getTcPr().getGridSpan().getVal().intValue();
						else idx++;
						//System.out.println(xwpfTableCell.getText()+"\t\tSpan:"+xwpfTableCell.getCTTc().getTcPr().getVMerge().getVal());
						if(xwpfTableCell.getCTTc().getTcPr().getVMerge()!=null) {
							int iMergStat = xwpfTableCell.getCTTc().getTcPr().getVMerge().getVal().intValue(); // 1 - Continue.    2 - Restart;
						}
					} catch (Exception e) {
						System.out.println(xwpfTableCell.getText());	
					}
					/*List<IBodyElement> elts = xwpfTableCell.getBodyElements();
					for (IBodyElement iBodyElement : elts) {
						if(iBodyElement instanceof XWPFParagraph) {
							XWPFParagraph para = (XWPFParagraph)iBodyElement;
							List<XWPFRun> arr_run = para.getRuns();
							for (XWPFRun xwpfRun : arr_run) {
								System.out.println(xwpfRun);
								CTR ctr = xwpfRun.getCTR();
								CTText[] asd = ctr.getInstrTextArray();
								
								if(asd.length>0) {
									asd[0] = asd[0];
								}
								
							}
						}
						
					}*/
				}
				lst_row.add(lst_cell);
			}
			
		}
	}

	/**
	 * @param document
	 */
	private static void updateCustomProperties(XWPFDocument document) {
		CTDocument1 doc = document.getDocument();
		try {
			
			NodeList insrt = doc.getDomNode().getOwnerDocument().getElementsByTagName("w:instrText");
			int length = insrt.getLength();
			for (int i = 0; i< length ; i++) {
				Node item = insrt.item(i);
				if(item instanceof Element) {
					NamedNodeMap attr = item.getAttributes();
					item.getParentNode().getParentNode();
					NodeList arr_nodex = item.getParentNode().getNextSibling().getNextSibling().getChildNodes();
					for (int k = 0; k< arr_nodex.getLength() ; k++) {
						if(arr_nodex.item(k).getNodeName().equalsIgnoreCase("w:t")) {
							arr_nodex.item(k).getFirstChild().setNodeValue("AA:"+i);
						}
							//System.out.println(arr_nodex.item(k).getFirstChild().getNodeValue());
							
					}
					System.out.println(item.getParentNode().getNodeName());
					System.out.println(item.getFirstChild().getNodeValue());
					
					/*for(int j = 0; j<10; j++) {
						attr.
					}*/
					System.out.println(item.getNodeName());
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		POIXMLProperties props = document.getProperties();
		
		CustomProperties cp = props.getCustomProperties();
		
		List<CTProperty> ctProperties = cp.getUnderlyingProperties().getPropertyList();
		for (int i = 0; i < ctProperties.size(); i++) {
			ctProperties.get(i).setLpwstr(""+i);
			System.out.println(ctProperties.get(i).getLpwstr());
		}
		
		document.enforceUpdateFields();
		
	}

	private static int getColumnCount(List<XWPFTableCell> arr_cell){
		int idx = 0;
		for (XWPFTableCell xwpfTableCell : arr_cell) {
			try {
				if(xwpfTableCell.getCTTc().getTcPr().getGridSpan()!=null)
					idx += xwpfTableCell.getCTTc().getTcPr().getGridSpan().getVal().intValue();
				else idx++;
			} catch (Exception e) {
				System.out.println(xwpfTableCell.getText());	
			}
		}
		return idx;
	}
	public static void main(String[] args) {

		readDocxFile("C:\\temp\\Test Value1.docx");//12. Specification of Fastener.docx

		//readDocFile("D:\\Test.doc");

	}
}