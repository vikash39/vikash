package addnew;

import com.teamcenter.rac.aif.AIFDesktop;
import com.teamcenter.rac.aif.AbstractAIFUIApplication;
import com.teamcenter.rac.aif.kernel.InterfaceAIFComponent;
import com.teamcenter.rac.aifrcp.SelectionHelper;
import com.teamcenter.rac.common.Activator;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCComponentPseudoFolder;
import com.teamcenter.rac.kernel.TCComponentTask;
import com.teamcenter.rac.kernel.TCComponentType;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.kernel.TCTypeService;
import com.teamcenter.rac.kernel.TypeInfo;
import com.teamcenter.rac.services.ICoreConstantService;
import com.teamcenter.rac.util.AdapterUtil;
import com.teamcenter.rac.util.MessageBox;
import com.teamcenter.rac.util.OSGIUtil;
import com.teamcenter.rac.util.Registry;
import com.teamcenter.rac.vns.model.IContentView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.ui.handlers.IHandlerService;

public class AddNewHandler
  extends AbstractHandler
{
  private static final String PARENT_COMPS = "parentComponents";
  private static final String REVISION_FLAG = "revisionFlag";
  private static final String PASTE_RELATION = "pasteRelation";
  private static final String OBJECT_TYPE = "objectType";
  
  public Object execute(ExecutionEvent paramExecutionEvent)
    throws ExecutionException
  {
    String[] arrayOfString1 = null;
    String[] arrayOfString2 = null;
    int i = 0;
    Registry localRegistry = Registry.getRegistry(AddNewHandler.class);
    IWorkbenchPart localIWorkbenchPart = HandlerUtil.getActivePart(paramExecutionEvent);
    Object localObject1 = localIWorkbenchPart.getAdapter(IContentView.class);
    List localList = null;
    InterfaceAIFComponent[] arrayOfInterfaceAIFComponent = null;
    Object localObject3;
    Object localObject2;
    if (localObject1 != null)
    {
      localList = ((IContentView)localObject1).getInputRootObjects();
      if ((localList != null) && (localList.size() > 0))
      {
        arrayOfInterfaceAIFComponent = new InterfaceAIFComponent[localList.size()];
        int j = 0;
        localObject3 = localList.iterator();
        while (((Iterator)localObject3).hasNext())
        {
          localObject2 = ((Iterator)localObject3).next();
          arrayOfInterfaceAIFComponent[(j++)] = ((InterfaceAIFComponent)AdapterUtil.getAdapter(localObject2, InterfaceAIFComponent.class));
        }
      }
    }
    if (arrayOfInterfaceAIFComponent == null) {
      arrayOfInterfaceAIFComponent = SelectionHelper.getTargetComponents(HandlerUtil.getCurrentSelection(paramExecutionEvent));
    }
    try
    {
      String str = paramExecutionEvent.getParameter("objecttype");
      localObject2 = paramExecutionEvent.getParameter("source");
      localObject3 = null;
      
      if ((str == null) || (str.length() == 0))
      {
        if ((localObject2 != null) && (((String)localObject2).length() > 0))
        {
          String[] localObject4 = ((String)localObject2).split(",");
          int k;
          if (localObject4.length > 1)
          {
            arrayOfString1 = new String[localObject4.length];
            for (k = 0; k < localObject4.length; k++)
            {
              int m = localObject4[k].indexOf(".");
              if (m > 0) {
                if (localObject3 != null) {
                  localObject3 = localObject3 + "," + localObject4[k].substring(0, m);
                } else {
                  localObject3 = localObject4[k].substring(0, m);
                }
              }
              arrayOfString1[k] = localObject4[k].substring(m + 1).trim();
            }
            arrayOfString2 = formUniqueSecondaryTypeList(arrayOfString1);
          }
          else
          {
            arrayOfString2 = new String[1];
            k = localObject4[0].indexOf(".");
            localObject3 = k > 0 ? localObject4[0].substring(0, k) : null;
            arrayOfString2[0] = localObject4[0].substring(k + 1).trim();
          }
        }
        else
        {
          MessageBox.post(localRegistry.getString("AddNewHandler.NoSourceFound"), "INFORMATION", 2);
        }
      }
      else
      {
        arrayOfString2 = new String[1];
        arrayOfString2[0] = str.trim();
      }
      if (arrayOfString2 != null)
      {
        i = arrayOfString2.length;
        if (i == 1)
        {
          launchWizard((String)localObject3, arrayOfString2[0], arrayOfInterfaceAIFComponent, (String)localObject2);
        }
        else
        {
          String localObject4 = identifyCommonParent(arrayOfString2);
          launchWizard((String)localObject3, (String)localObject4, arrayOfInterfaceAIFComponent, (String)localObject2);
        }
      }
    }
    catch (Exception localException)
    {
      MessageBox.post(Display.getDefault().getActiveShell(), localException, true);
    }
    return null;
  }
  
  private String[] formUniqueSecondaryTypeList(String[] paramArrayOfString)
  {
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    for (int i = 0; i < paramArrayOfString.length; i++) {
      localLinkedHashSet.add(paramArrayOfString[i]);
    }
    String[] arrayOfString = (String[])localLinkedHashSet.toArray(new String[localLinkedHashSet.size()]);
    return arrayOfString;
  }
  
  private String identifyCommonParent(String[] paramArrayOfString)
  {
    String localObject1 = "";
    int i = 50;
    int j = 0;
    ArrayList localArrayList = new ArrayList();
    int k = 0;
    try
    {
      TCSession localTCSession = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
      TCTypeService localTCTypeService = localTCSession.getTypeService();
      int m = paramArrayOfString.length;
      for (int n = 0; n < m; n++) {
        try
        {
          TCComponentType localTCComponentType = localTCTypeService.getTypeComponent(paramArrayOfString[n]);
          if (localTCComponentType != null)
          {
            localArrayList.add(localTCComponentType);
            k++;
          }
        }
        catch (Exception localException2) {}
      }
      List[] arrayOfList = new List[k];
      
      for (int i1 = 0; i1 < k; i1++)
      {
        List<String> localObject2 = Arrays.asList(((TCComponentType)localArrayList.get(i1)).getTypeNameHierarchy());
        arrayOfList[i1] = localObject2;
        if (i > ((List)localObject2).size())
        {
          i = ((List)localObject2).size();
          j = i1;
        }
      }
      int i1 = 0;
      Iterator localIterator = arrayOfList[j].iterator();
      while (localIterator.hasNext())
      {
        String localObject2 = (String)localIterator.next();
        for (int i2 = 0; i2 < arrayOfList.length; i2++) {
          if (i2 != j) {
            if (arrayOfList[i2].contains(localObject2)) {
              i1 = 1;
            } else {
              i1 = 0;
            }
          }
        }
        if (i1 != 0)
        {
          localObject1 = localObject2;
          break;
        }
      }
    }
    catch (Exception localException1)
    {
      MessageBox.post(Display.getDefault().getActiveShell(), localException1, true);
    }
    return localObject1;
  }
  
  private void launchWizard(String paramString1, String paramString2, InterfaceAIFComponent[] paramArrayOfInterfaceAIFComponent, String paramString3)
  {
    Registry localRegistry = Registry.getRegistry(this);
    if ((paramString2 == null) || (paramString2.isEmpty()))
    {
      MessageBox.post(Display.getDefault().getActiveShell(), localRegistry.getString("AddNewHandler.NoObjectType"), localRegistry.getString("warning"), 4);
      return;
    }
    TCSession localTCSession = (TCSession)AIFDesktop.getActiveDesktop().getCurrentApplication().getSession();
    TCTypeService localTCTypeService = localTCSession.getTypeService();
    try
    {
      TCComponentType localTCComponentType = localTCTypeService.getTypeComponent(paramString2);
      if (localTCComponentType == null)
      {
        MessageBox.post(Display.getDefault().getActiveShell(), localRegistry.getString("AddNewHandler.NoObjectType"), localRegistry.getString("warning"), 4);
        return;
      }
      IWorkbench localIWorkbench = PlatformUI.getWorkbench();
      ICommandService localICommandService = (ICommandService)localIWorkbench.getService(ICommandService.class);
      IHandlerService localIHandlerService = (IHandlerService)PlatformUI.getWorkbench().getService(IHandlerService.class);
      HashMap localHashMap = new HashMap();
      localHashMap.put("relOtherTypeInfo", paramString3);
      String str1;
      if (localTCComponentType.isTypeOf("Dataset"))
      {
        str1 = "com.teamcenter.rac.newDataset";
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("pasteRelation", paramString1);
      }
      else if (localTCComponentType.isTypeOf("ItemRevision"))
      {
        str1 = "com.teamcenter.rac.newItem";
		for (int i = 0; i < paramArrayOfInterfaceAIFComponent.length; i++) {
          if ((paramArrayOfInterfaceAIFComponent[i] != null) && ((paramArrayOfInterfaceAIFComponent[i] instanceof TCComponentPseudoFolder)))
          {
        	  TCComponent localObject2 = ((TCComponentPseudoFolder)paramArrayOfInterfaceAIFComponent[i]).getOwningComponent();
            if ((localObject2 instanceof TCComponentTask)) {
              paramArrayOfInterfaceAIFComponent[i] = localObject2;
            }
          }
        }
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("revisionFlag", Boolean.TRUE);
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("selection", paramArrayOfInterfaceAIFComponent);
        TypeInfo localObject1 = localTCComponentType.getTcTypes("Item", true);
        if (localObject1 != null)
        {
          String[] localObject2 = ((TypeInfo)localObject1).getTypeNames();
          List localList1 = Arrays.asList((Object[])localObject2);
          String str2 = "";
          Object localObject3;
          Object localObject4;
          if (paramString2.endsWith("Revision"))
          {
            int j = paramString2.indexOf("Revision");
            str2 = paramString2.substring(0, j).trim();
            if (localList1.contains(str2))
            {
              localHashMap.put("objectType", str2);
            }
            else if (!localList1.contains(str2))
            {
              localObject3 = (ICoreConstantService)OSGIUtil.getService(Activator.getDefault(), ICoreConstantService.class);
              localObject4 = ((ICoreConstantService)localObject3).getTypesConstant((String[])localObject2, "ItemRevision");
              List localList2 = Arrays.asList((Object[])localObject4);
              int m = localList2.indexOf(paramString2);
              str2 = localObject2[m];
              localHashMap.put("objectType", str2);
            }
          }
          else
          {
            ICoreConstantService localICoreConstantService = (ICoreConstantService)OSGIUtil.getService(Activator.getDefault(), ICoreConstantService.class);
            localObject3 = localICoreConstantService.getTypesConstant((String[])localObject2, "ItemRevision");
            localObject4 = Arrays.asList((Object[])localObject3);
            int k = ((List)localObject4).indexOf(paramString2);
            str2 = localObject2[k];
            localHashMap.put("objectType", str2);
          }
        }
      }
      else if (localTCComponentType.isTypeOf("Item"))
      {
        localHashMap.put("revisionFlag", Boolean.FALSE);
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("objectType", paramString2);
        if (localTCComponentType.isTypeOf("Part")) {
          str1 = "com.teamcenter.rac.newPart";
        } else {
          str1 = "com.teamcenter.rac.newItem";
        }
      }
      else if (localTCComponentType.isTypeOf("WorkspaceObject"))
      {
        str1 = "com.teamcenter.rac.newBO";
        localHashMap.put("revisionFlag", Boolean.TRUE);
        localHashMap.put("selection", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("objectType", localTCComponentType.getTypeName());
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
      }
      else if (localTCComponentType.isTypeOf("Fnd0NameValue"))
      {
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("objectType", paramString2);
        str1 = "com.teamcenter.rac.newNameValue";
      }
      else if (localTCComponentType.isTypeOf("Fnd0TableRow"))
      {
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("objectType", paramString2);
        str1 = "com.teamcenter.rac.newTableRow";
      }
      else
      {
        localHashMap.put("pasteRelation", paramString1);
        localHashMap.put("parentComponents", paramArrayOfInterfaceAIFComponent);
        localHashMap.put("objectType", paramString2);
        str1 = "com.teamcenter.rac.newPOMObject";
      }
      Object localObject1 = localICommandService.getCommand(str1);
      Object localObject2 = new ExecutionEvent((Command)localObject1, localHashMap, null, localIHandlerService.getCurrentState());
      try
      {
        ((Command)localObject1).executeWithChecks((ExecutionEvent)localObject2);
      }
      catch (Exception localException2)
      {
        MessageBox.post(Display.getDefault().getActiveShell(), localException2, true);
      }
      return;
    }
    catch (TCException localTCException)
    {
      MessageBox.post(Display.getDefault().getActiveShell(), localTCException, true);
    }
    catch (Exception localException1)
    {
      MessageBox.post(Display.getDefault().getActiveShell(), localException1, true);
    }
  }
}
