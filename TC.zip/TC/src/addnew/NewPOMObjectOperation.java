package addnew;

import com.teamcenter.rac.common.create.IBOCreateDefinition;
import com.teamcenter.rac.common.create.ICreateInstanceInput;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.ui.commands.create.bo.NewBOModel;
import com.teamcenter.rac.ui.commands.create.bo.NewBOOperation;
import com.teamcenter.rac.ui.commands.create.bo.NewBOWizard;

import java.util.List;

public final class NewPOMObjectOperation
  extends NewBOOperation
{
  public NewPOMObjectOperation() {}
  
  public NewPOMObjectOperation(NewBOWizard paramNewBOWizard, List<ICreateInstanceInput> paramList)
  {
    setWizard(paramNewBOWizard);
    setCreateInput(paramList);
  }
  
  public void executeOperation()
    throws Exception
  {
	  performCreate(createInput);
    /*createComponent(getMonitor());
    if (getNewComponent() != null) {
      updateMRUList();
    }*/
  }
  
  protected List<TCComponent> performCreate(List<ICreateInstanceInput> paramList)
    throws TCException
  {
    IBOCreateDefinition localIBOCreateDefinition = this.wizard.getBOModel().getCreateDef();
    NewBOModel localNewBOModel = this.wizard.getBOModel();
    return SOAGenericCreateHelper.createRelateAndSubmitToWorkflow(localNewBOModel.getSession(), localIBOCreateDefinition, paramList, localNewBOModel.getDataToBeRelated(), localNewBOModel.getWorkFlowData(), (TCComponent)localNewBOModel.getTargetArray()[0], localNewBOModel.getRelType());
	  
	/*  IBOCreateDefinition localIBOCreateDefinition = wizard.getBOModel().getCreateDef();
	    return SOAGenericCreateHelper.create(this.session, localIBOCreateDefinition, paramList);*/
  }
}
