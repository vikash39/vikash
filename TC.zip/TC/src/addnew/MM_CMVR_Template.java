/**=================================================================================================
#                Copyright (c) 2013 Intelizign Engineering Services                    
#                  Unpublished - All Rights Reserved                    
#  ================================================================================================= 
#      Filename        :           MM_CMVR_Template.java          
#      Module          :           addnew          
#      Description     :           <DESCRIPTION>          
#      Project         :           Mahindra - EMPDS          
#      Author          :           Vinothkumar Arthanari          
#  =================================================================================================                    
#  Date                         Name           Description of Change
#  Apr 6, 2018				  Administrator			Initial Creation
#  $HISTORY$                  
#  =================================================================================================*/
package addnew;

import org.eclipse.swt.widgets.Composite;

/**
 * @author Administrator
 *
 */
public class MM_CMVR_Template extends Composite {

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public MM_CMVR_Template(Composite parent, int style) {
		super(parent, style);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

}
