package addnew;

import com.teamcenter.rac.common.Activator;
import com.teamcenter.rac.common.create.IBOCreateDefinition;
import com.teamcenter.rac.common.create.ICreateInstanceInput;
import com.teamcenter.rac.kernel.BOCreatePropertyDescriptor;
import com.teamcenter.rac.kernel.SoaUtil;
import com.teamcenter.rac.kernel.TCComponent;
import com.teamcenter.rac.kernel.TCException;
import com.teamcenter.rac.kernel.TCPropertyDescriptor;
import com.teamcenter.rac.kernel.TCSession;
import com.teamcenter.rac.services.ISessionService;
import com.teamcenter.services.rac.core.DataManagementService;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateIn;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateInput;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateOut;
import com.teamcenter.services.rac.core._2008_06.DataManagement.CreateResponse;
import com.teamcenter.services.rac.core._2015_07.DataManagement;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateIn2;
import com.teamcenter.services.rac.core._2015_07.DataManagement.CreateInput2;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.Property;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.apache.log4j.Logger;

public class SOAGenericCreateHelper
{
  private static Logger logger = Logger.getLogger(SOAGenericCreateHelper.class);
  
  public static List<TCComponent> create(TCSession paramTCSession, IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
    throws TCException
  {
    try
    {
      ArrayList localArrayList1 = null;
      if ((paramTCSession != null) && (paramIBOCreateDefinition != null) && (paramList != null) && (!paramList.isEmpty()))
      {
        logCreateInputs(paramList);
        DataManagementService localDataManagementService = DataManagementService.getService(paramTCSession);
        if (localDataManagementService != null)
        {
          ArrayList localArrayList2 = new ArrayList(paramList);
          CreateInput localCreateInput = getCreateInput(paramIBOCreateDefinition, localArrayList2);
          if (localCreateInput != null)
          {
            CreateIn localCreateIn = new CreateIn();
            localCreateIn.clientId = "Test";
            localCreateIn.data = localCreateInput;
            System.out.println("*** CreateInput structure: ***");
            logRootInput(localCreateInput, "");
            CreateResponse localCreateResponse = localDataManagementService.createObjects(new CreateIn[] { localCreateIn });
            SoaUtil.handlePartialErrors(localCreateResponse.serviceData, null, null, true);
            CreateOut[] arrayOfCreateOut1 = localCreateResponse.output;
            if ((arrayOfCreateOut1 != null) && (arrayOfCreateOut1.length > 0))
            {
              localArrayList1 = new ArrayList(0);
              for (CreateOut localCreateOut : arrayOfCreateOut1)
              {
                TCComponent[] arrayOfTCComponent = localCreateOut.objects;
                if ((arrayOfTCComponent != null) && (arrayOfTCComponent.length > 0)) {
                  localArrayList1.addAll(Arrays.asList(arrayOfTCComponent));
                }
              }
            }
          }
        }
      }
      return localArrayList1;
    }
    catch (Exception localException)
    {
      if ((localException instanceof TCException)) {
        throw ((TCException)localException);
      }
      throw new TCException(localException);
    }
  }
  
  public static List<TCComponent> createRelateAndSubmitToWorkflow(TCSession paramTCSession, IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList, Map paramMap1, Map paramMap2, TCComponent paramTCComponent, String paramString)
    throws TCException
  {
    try
    {
      ArrayList localArrayList1 = null;
      if ((paramTCSession != null) && (paramIBOCreateDefinition != null) && (paramList != null) && (!paramList.isEmpty()))
      {
        logCreateInputs(paramList);
        DataManagementService localDataManagementService = DataManagementService.getService(paramTCSession);
        if (localDataManagementService != null)
        {
          ArrayList localArrayList2 = new ArrayList(paramList);
          CreateInput2 localCreateInput2 = getCreateInput2(paramIBOCreateDefinition, localArrayList2);
          if (localCreateInput2 != null)
          {
            CreateIn2 localCreateIn2 = new CreateIn2();
            localCreateIn2.clientId = "RAC_Client";
            localCreateIn2.createData = localCreateInput2;
            if (paramString != null) {
              localCreateIn2.pasteProp = paramString;
            }
            if (paramTCComponent != null) {
              localCreateIn2.targetObject = paramTCComponent;
            }
            if (paramMap1 != null) {
              localCreateIn2.dataToBeRelated = paramMap1;
            }
            if (paramMap2 != null) {
              localCreateIn2.workflowData = paramMap2;
            }
            CreateResponse localCreateResponse = localDataManagementService.createRelateAndSubmitObjects2(new CreateIn2[] { localCreateIn2 });
            SoaUtil.handlePartialErrors(localCreateResponse.serviceData, null, null, true);
            CreateOut[] arrayOfCreateOut1 = localCreateResponse.output;
            if ((arrayOfCreateOut1 != null) && (arrayOfCreateOut1.length > 0))
            {
              localArrayList1 = new ArrayList(0);
              for (CreateOut localCreateOut : arrayOfCreateOut1)
              {
                TCComponent[] arrayOfTCComponent = localCreateOut.objects;
                if ((arrayOfTCComponent != null) && (arrayOfTCComponent.length > 0)) {
                  localArrayList1.addAll(Arrays.asList(arrayOfTCComponent));
                }
              }
            }
          }
        }
      }
      return localArrayList1;
    }
    catch (TCException localTCException)
    {
      throw localTCException;
    }
    catch (Exception localException)
    {
      throw new TCException(localException);
    }
  }
  
  private static CreateInput2 getCreateInput2(IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
    throws NumberFormatException
  {
    CreateInput2 localCreateInput2 = new CreateInput2();
    localCreateInput2.boName = paramIBOCreateDefinition.getTypeName();
    walkAndCreateInputStructure(localCreateInput2, paramIBOCreateDefinition, paramList);
    return localCreateInput2;
  }
  
  public static CreateInput getCreateInput(IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
    throws NumberFormatException
  {
    CreateInput localCreateInput = new CreateInput();
    localCreateInput.boName = paramIBOCreateDefinition.getTypeName();
    walkAndCreateInputStructure(localCreateInput, paramIBOCreateDefinition, paramList);
    return localCreateInput;
  }
  
  private static void walkAndCreateInputStructure(Object paramObject, IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
    throws NumberFormatException
  {
    if ((paramIBOCreateDefinition != null) && (paramList != null) && (!paramList.isEmpty()))
    {
      List localList1 = findCreateInputsForCreateDef(paramIBOCreateDefinition, paramList);
      if ((localList1 != null) && (!localList1.isEmpty()))
      {
        updateInputStructure(paramObject, localList1);
        Iterator localObject2 = localList1.iterator();
        while (((Iterator)localObject2).hasNext())
        {
        	ICreateInstanceInput localObject1 = (ICreateInstanceInput)((Iterator)localObject2).next();
          paramList.remove(localObject1);
          walkAndCreateNestedInputStructure(paramObject, (ICreateInstanceInput)localObject1, false);
        }
      }
      Object localObject1 = paramIBOCreateDefinition.getSecondaryCreateDefinitions();
      if ((localObject1 != null) && (!((Map)localObject1).isEmpty()) && (!paramList.isEmpty()))
      {
    	  String[] localObject2 = (String[])((Map)localObject1).keySet().toArray(new String[((Map)localObject1).size()]);
        for (Object localObject3 : localObject2)
        {
          List localList2 = (List)((Map)localObject1).get(localObject3);
          if ((localList2 != null) && (!localList2.isEmpty()))
          {
            ArrayList localArrayList = new ArrayList(localList2.size());
            Iterator localIterator = localList2.iterator();
            while (localIterator.hasNext())
            {
              IBOCreateDefinition localIBOCreateDefinition = (IBOCreateDefinition)localIterator.next();
              if (createInstanceInputAvailableForCreateDef(localIBOCreateDefinition, paramList))
              {
                CreateInput localCreateInput = new CreateInput();
                localCreateInput.boName = localIBOCreateDefinition.getTypeName();
                localArrayList.add(localCreateInput);
                walkAndCreateInputStructure(localCreateInput, localIBOCreateDefinition, paramList);
              }
            }
            if ((paramObject instanceof CreateInput)) {
              updateCompoundCreateInput((CreateInput)paramObject, localArrayList,(String) localObject3);
            } else if ((paramObject instanceof CreateInput2)) {
              updateCompoundCreateInput((CreateInput2)paramObject, localArrayList, (String)localObject3);
            }
          }
        }
      }
    }
  }
  
  private static void updateCompoundCreateInput(CreateInput paramCreateInput, List<CreateInput> paramList, String paramString)
  {
    if (paramCreateInput.compoundCreateInput == null) {
      paramCreateInput.compoundCreateInput = new HashMap();
    }
    CreateInput[] arrayOfCreateInput;
    if (paramCreateInput.compoundCreateInput.containsKey(paramString))
    {
      arrayOfCreateInput = (CreateInput[])paramCreateInput.compoundCreateInput.get(paramString);
      if ((arrayOfCreateInput != null) && (arrayOfCreateInput.length > 0)) {
        paramList.addAll(Arrays.asList(arrayOfCreateInput));
      }
    }
    if ((paramList != null) && (!paramList.isEmpty()))
    {
      arrayOfCreateInput = (CreateInput[])paramList.toArray(new CreateInput[paramList.size()]);
      paramCreateInput.compoundCreateInput.put(paramString, arrayOfCreateInput);
    }
  }
  
  private static void updateCompoundCreateInput(CreateInput2 paramCreateInput2, List<CreateInput> paramList, String paramString)
  {
    if (paramCreateInput2.compoundCreateInput == null) {
      paramCreateInput2.compoundCreateInput = new HashMap();
    }
    CreateInput[] arrayOfCreateInput;
    if (paramCreateInput2.compoundCreateInput.containsKey(paramString))
    {
      arrayOfCreateInput = (CreateInput[])paramCreateInput2.compoundCreateInput.get(paramString);
      if ((arrayOfCreateInput != null) && (arrayOfCreateInput.length > 0)) {
        paramList.addAll(Arrays.asList(arrayOfCreateInput));
      }
    }
    if ((paramList != null) && (!paramList.isEmpty()))
    {
      arrayOfCreateInput = (CreateInput[])paramList.toArray(new CreateInput[paramList.size()]);
      paramCreateInput2.compoundCreateInput.put(paramString, arrayOfCreateInput);
    }
  }
  
  private static void walkAndCreateNestedInputStructure(Object paramObject, ICreateInstanceInput paramICreateInstanceInput, boolean paramBoolean)
    throws NumberFormatException
  {
    if (paramBoolean) {
      updateInputStructure(paramObject, Arrays.asList(new ICreateInstanceInput[] { paramICreateInstanceInput }));
    }
    if ((paramICreateInstanceInput != null) && (paramICreateInstanceInput.hasSecondaryCreateInputs()))
    {
      Map localMap = paramICreateInstanceInput.getSecondaryCreateInputs();
      Iterator localIterator1 = localMap.entrySet().iterator();
      while (localIterator1.hasNext())
      {
        Map.Entry localEntry = (Map.Entry)localIterator1.next();
        String str = (String)localEntry.getKey();
        List localList = (List)localEntry.getValue();
        if ((localList != null) && (!localList.isEmpty()))
        {
          ArrayList localArrayList = new ArrayList(0);
          Iterator localIterator2 = localList.iterator();
          while (localIterator2.hasNext())
          {
            ICreateInstanceInput localICreateInstanceInput = (ICreateInstanceInput)localIterator2.next();
            CreateInput localCreateInput = new CreateInput();
            localCreateInput.boName = localICreateInstanceInput.getCreateDefinition().getTypeName();
            localArrayList.add(localCreateInput);
            walkAndCreateNestedInputStructure(localCreateInput, localICreateInstanceInput, true);
          }
          if ((paramObject instanceof CreateInput)) {
            updateCompoundCreateInput((CreateInput)paramObject, localArrayList, str);
          } else if ((paramObject instanceof CreateInput2)) {
            updateCompoundCreateInput((CreateInput2)paramObject, localArrayList, str);
          }
        }
      }
    }
  }
  
  public static List<ICreateInstanceInput> findCreateInputsForCreateDef(IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
  {
    return findCreateInputsForCreateDef2(paramIBOCreateDefinition, paramList, false);
  }
  
  public static List<ICreateInstanceInput> findCreateInputsForCreateDef2(IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList, boolean paramBoolean)
  {
    ArrayList localArrayList = new ArrayList(0);
    if ((paramIBOCreateDefinition != null) && (paramList != null) && (!paramList.isEmpty()))
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        ICreateInstanceInput localICreateInstanceInput = (ICreateInstanceInput)localIterator.next();
        IBOCreateDefinition localIBOCreateDefinition = localICreateInstanceInput.getCreateDefinition();
        if (localIBOCreateDefinition == paramIBOCreateDefinition)
        {
          localArrayList.add(localICreateInstanceInput);
        }
        else
        {
          Object localObject1;
          String str1;
          if (localIBOCreateDefinition.getTypeName().equals(paramIBOCreateDefinition.getTypeName()))
          {
            localObject1 = localIBOCreateDefinition.getParentContext();
            str1 = paramIBOCreateDefinition.getParentContext();
            if (((localObject1 == null) && (str1 == null)) || ((localObject1 != null) && (str1 != null) && (((String)localObject1).equals(str1))))
            {
              String localObject2 = localIBOCreateDefinition.getContext();
             String  str2 = paramIBOCreateDefinition.getContext();
              if (((localObject2 == null) && (str2 == null)) || ((localObject2 != null) && (str2 != null) && (((String)localObject2).equals(str2)))) {
                localArrayList.add(localICreateInstanceInput);
              }
            }
          }
          else if (paramBoolean)
          {
            localObject1 = paramIBOCreateDefinition.getSecondaryCreateDefinitions();
            if ((localObject1 != null) && (!((Map)localObject1).isEmpty()) && (!paramList.isEmpty()))
            {
              str1 = localIBOCreateDefinition.getContext();
              String[] localObject2 = (String[])((Map)localObject1).keySet().toArray(new String[((Map)localObject1).size()]);
              for (String str2 : localObject2) {
                if ((str2 != null) && (str2.equals(str1))) {
                  localArrayList.add(localICreateInstanceInput);
                }
              }
            }
          }
        }
      }
    }
    return localArrayList;
  }
  
  private static boolean createInstanceInputAvailableForCreateDef(IBOCreateDefinition paramIBOCreateDefinition, List<ICreateInstanceInput> paramList)
  {
    List localList = findCreateInputsForCreateDef2(paramIBOCreateDefinition, paramList, true);
    return (localList != null) && (!localList.isEmpty());
  }
  
  private static void updateInputStructure(Object paramObject, List<ICreateInstanceInput> paramList)
    throws NumberFormatException
  {
    Object localObject1 = null;
    String str = null;
    Object localObject2 = null;
    try
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        ICreateInstanceInput localICreateInstanceInput = (ICreateInstanceInput)localIterator.next();
        localObject1 = localICreateInstanceInput;
        Map localMap1 = localICreateInstanceInput.getCreateInputs();
        if ((localMap1 != null) && (!localMap1.isEmpty()))
        {
          BOCreatePropertyDescriptor[] arrayOfBOCreatePropertyDescriptor1 = (BOCreatePropertyDescriptor[])localMap1.keySet().toArray(new BOCreatePropertyDescriptor[localMap1.size()]);
          if ((arrayOfBOCreatePropertyDescriptor1 != null) && (arrayOfBOCreatePropertyDescriptor1.length > 0)) {
            for (BOCreatePropertyDescriptor localBOCreatePropertyDescriptor : arrayOfBOCreatePropertyDescriptor1)
            {
              localObject2 = localMap1.get(localBOCreatePropertyDescriptor);
              if ((paramObject != null) && (localBOCreatePropertyDescriptor != null))
              {
                str = localBOCreatePropertyDescriptor.getPropertyDescriptor().getName();
                int k = localBOCreatePropertyDescriptor.getPropertyDescriptor().getType();
                boolean bool = localBOCreatePropertyDescriptor.getPropertyDescriptor().isArray();
                Map localMap2;
                Object localObject3;
                if ((paramObject instanceof CreateInput))
                {
                  localMap2 = getInputMap(k, bool, (CreateInput)paramObject);
                  if (localMap2 != null)
                  {
                    localObject3 = marshallValue(k, bool, localObject2);
                    if (localObject3 != null) {
                      localMap2.put(str, localObject3);
                    }
                  }
                }
                else if ((paramObject instanceof CreateInput2))
                {
                  localMap2 = getInputMap(k, bool, (CreateInput2)paramObject);
                  if (localMap2 != null)
                  {
                    localObject3 = marshallToStringValues(k, bool, localObject2);
                    String[] arrayOfString = (String[])((List)localObject3).toArray(new String[0]);
                    if (localObject3 != null) {
                      localMap2.put(str, arrayOfString);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      if (localObject1 != null)
      {
       // localObject1.setErrorCreateInput(true);
        //localObject1.setErrorPropName(str);
      }
      if (localObject2 != null) {
        Logger.getLogger(SOAGenericCreateHelper.class).error(localObject2.toString() + " : " + "Invalid Input for Property" + " " + str);
      }
      throw localNumberFormatException;
    }
  }
  
  private static Map getInputMap(int paramInt, boolean paramBoolean, CreateInput2 paramCreateInput2)
  {
    Map localMap = null;
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
      localMap = paramCreateInput2.propertyNameValues;
      break;
    }
    return localMap;
  }
  
  private static Map getInputMap(int paramInt, boolean paramBoolean, CreateInput paramCreateInput)
  {
    Map localMap = null;
    switch (paramInt)
    {
    case 2: 
      localMap = paramBoolean ? paramCreateInput.dateArrayProps : paramCreateInput.dateProps;
      break;
    case 3: 
      localMap = paramBoolean ? paramCreateInput.doubleArrayProps : paramCreateInput.doubleProps;
      break;
    case 4: 
      localMap = paramBoolean ? paramCreateInput.floatArrayProps : paramCreateInput.floatProps;
      break;
    case 5: 
    case 7: 
      localMap = paramBoolean ? paramCreateInput.intArrayProps : paramCreateInput.intProps;
      break;
    case 6: 
      localMap = paramBoolean ? paramCreateInput.boolArrayProps : paramCreateInput.boolProps;
      break;
    case 1: 
    case 8: 
    case 12: 
      localMap = paramBoolean ? paramCreateInput.stringArrayProps : paramCreateInput.stringProps;
      break;
    case 9: 
    case 10: 
    case 11: 
    case 13: 
    case 14: 
      localMap = paramBoolean ? paramCreateInput.tagArrayProps : paramCreateInput.tagProps;
      break;
    }
    return localMap;
  }
  
  public static Object marshallValue(int paramInt, boolean paramBoolean, Object paramObject)
    throws NumberFormatException
  {
    Object localObject = null;
    switch (paramInt)
    {
    case 2: 
      localObject = paramBoolean ? toDateValueArray(paramObject) : toDateValue(paramObject);
      break;
    case 3: 
      localObject = paramBoolean ? toDoubleValueArray(paramObject) : toDoubleValue(paramObject);
      break;
    case 4: 
      localObject = paramBoolean ? toFloatValueArray(paramObject) : toFloatValue(paramObject);
      break;
    case 5: 
    case 7: 
      localObject = paramBoolean ? toIntegerValueArray(paramObject) : toIntegerValue(paramObject);
      break;
    case 6: 
      localObject = paramBoolean ? toBooleanValueArray(paramObject) : toBooleanValue(paramObject);
      break;
    case 1: 
    case 8: 
    case 12: 
      localObject = paramBoolean ? toStringValueArray(paramObject, paramInt) : toStringValue(paramObject, paramInt);
      break;
    case 9: 
    case 10: 
    case 11: 
    case 13: 
    case 14: 
      localObject = paramBoolean ? toReferenceValueArray(paramObject) : toReferenceValue(paramObject);
      break;
    }
    return localObject;
  }
  
  public static List<String> marshallToStringValues(int paramInt, boolean paramBoolean, Object paramObject)
    throws NumberFormatException
  {
    ArrayList localArrayList = new ArrayList();
    if (!paramBoolean)
    {
      localArrayList.add(marshaltoStringValue(paramInt, paramObject));
      return localArrayList;
    }
    switch (paramInt)
    {
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
      Object[] arrayOfObject = getArray(paramObject);
      int i = 0;
      for (;;)
      {
        localArrayList.add(marshaltoStringValue(paramInt, arrayOfObject[i]));
        i++;
        if (i >= arrayOfObject.length) {
          break;
        }
      }
    }
    return localArrayList;
  }
  
  private static String marshaltoStringValue(int paramInt, Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    String str = null;
    switch (paramInt)
    {
    case 6: 
      if ((paramObject instanceof Boolean)) {
        str = Property.toBooleanString(((Boolean)paramObject).booleanValue());
      }
      break;
    case 2: 
      if ((paramObject instanceof Date)) {
        str = Property.toDateString((Date)paramObject);
      }
      break;
    case 1: 
    case 3: 
    case 4: 
    case 5: 
    case 7: 
    case 8: 
    case 12: 
      if ((paramObject instanceof String)) {
        str = (String)paramObject;
      } else if (paramObject != null) {
        str = paramObject.toString().trim();
      }
      break;
    case 9: 
    case 10: 
    case 11: 
    case 13: 
    case 14: 
      if ((paramObject instanceof ModelObject)) {
        str = Property.toModelObjectString((ModelObject)paramObject);
      } else if ((paramObject instanceof String)) {
        str = (String)paramObject;
      }
      break;
    }
    return str;
  }
  
  private static Object toIntegerValue(Object paramObject)
    throws NumberFormatException
  {
    Object localObject = null;
    if ((paramObject instanceof Integer))
    {
      localObject = paramObject;
    }
    else if (paramObject != null)
    {
      String str = paramObject.toString().trim();
      if (!str.isEmpty()) {
        localObject = Integer.valueOf(str);
      }
    }
    if (localObject != null) {
      return BigInteger.valueOf(((Integer)localObject).intValue());
    }
    return localObject;
  }
  
  private static Object toIntegerValueArray(Object paramObject)
    throws NumberFormatException
  {
    if ((paramObject instanceof int[])) {
      return paramObject;
    }
    Object[] arrayOfObject = getArray(paramObject);
    if ((arrayOfObject != null) && (arrayOfObject.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject.length);
       
      for (Object localObject1 : arrayOfObject)
      {
        Object localObject3 = toIntegerValue(localObject1);
        if (localObject3 != null) {
          localArrayList.add((BigInteger)localObject3);
        }
      }
      if (!localArrayList.isEmpty())
      {
        int[] localObject1 = new int[localArrayList.size()];
        int i = 0;
        Iterator aa = localArrayList.iterator();
        while (((Iterator)aa).hasNext())
        {
          BigInteger localBigInteger = (BigInteger)((Iterator)aa).next();
          localObject1[i++] = localBigInteger.intValue();
        }
        return localObject1;
      }
    }
    return null;
  }
  
  private static Object toFloatValue(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof Float))
    {
      localObject = paramObject;
    }
    else if (paramObject != null)
    {
      String str = paramObject.toString().trim();
      if (!str.isEmpty()) {
        localObject = Float.valueOf(str);
      }
    }
    return localObject;
  }
  
  private static Object toFloatValueArray(Object paramObject)
  {
    if ((paramObject instanceof float[])) {
      return paramObject;
    }
    Object[] arrayOfObject = getArray(paramObject);
    if ((arrayOfObject != null) && (arrayOfObject.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject.length);
      
      for (Object localObject1 : arrayOfObject)
      {
        Object localObject3 = toFloatValue(localObject1);
        if (localObject3 != null) {
          localArrayList.add((Float)localObject3);
        }
      }
      if (!localArrayList.isEmpty())
      {
        float[] localObject1 = new float[localArrayList.size()];
        int a  = 0;
        Iterator itt = localArrayList.iterator();
        while (((Iterator)itt).hasNext())
        {
          Float localFloat = (Float)((Iterator)itt).next();
          localObject1[(a++)] = localFloat.floatValue();
        }
        return localObject1;
      }
    }
    return null;
  }
  
  private static Object toDoubleValue(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof Double))
    {
      localObject = paramObject;
    }
    else if (paramObject != null)
    {
      String str = paramObject.toString().trim();
      if (!str.isEmpty()) {
        localObject = Double.valueOf(str);
      }
    }
    return localObject;
  }
  
  private static Object toDoubleValueArray(Object paramObject)
  {
    if ((paramObject instanceof double[])) {
      return paramObject;
    }
    Object[] arrayOfObject = getArray(paramObject);
    if ((arrayOfObject != null) && (arrayOfObject.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject.length);
      for (Object localObject1 : arrayOfObject)
      {
        Object localObject3 = toDoubleValue(localObject1);
        if (localObject3 != null) {
          localArrayList.add((Double)localObject3);
        }
      }
      if (!localArrayList.isEmpty())
      {
        double[] localObject1 = new double[localArrayList.size()];
        int a = 0;
        Iterator itt = localArrayList.iterator();
        while (((Iterator)itt).hasNext())
        {
          Double localDouble = (Double)((Iterator)itt).next();
          localObject1[(a++)] = localDouble.doubleValue();
        }
        return localObject1;
      }
    }
    return null;
  }
  
  private static Object toBooleanValue(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof Boolean))
    {
      localObject = paramObject;
    }
    else if (paramObject != null)
    {
      String str = paramObject.toString().trim();
      if (!str.isEmpty()) {
        localObject = Boolean.valueOf(str);
      }
    }
    return localObject;
  }
  
  private static Object toBooleanValueArray(Object paramObject)
  {
    if ((paramObject instanceof boolean[])) {
      return paramObject;
    }
    Object[] arrayOfObject = getArray(paramObject);
    if ((arrayOfObject != null) && (arrayOfObject.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject.length);
      
      for (Object localObject1 : arrayOfObject)
      {
        Object localObject3 = toBooleanValue(localObject1);
        if (localObject3 != null) {
          localArrayList.add((Boolean)localObject3);
        }
      }
      if (!localArrayList.isEmpty())
      {
        boolean[] localObject1 = new boolean[localArrayList.size()];
        int a = 0;
        Iterator itt = localArrayList.iterator();
        while (((Iterator)itt).hasNext())
        {
          Boolean localBoolean = (Boolean)((Iterator)itt).next();
          localObject1[(a++)] = localBoolean.booleanValue();
        }
        return localObject1;
      }
    }
    return null;
  }
  
  private static Object toStringValue(Object paramObject, int paramInt)
  {
    Object localObject = null;
    if ((paramObject instanceof String))
    {
      if ((paramInt == 8) || (paramInt == 1) || (paramInt == 12) || (!paramObject.toString().isEmpty())) {
        localObject = paramObject;
      }
    }
    else if (paramObject != null) {
      localObject = paramObject.toString().trim();
    }
    return localObject;
  }
  
  private static Object toStringValueArray(Object paramObject, int paramInt)
  {
    Object[] arrayOfObject1;
    if ((paramObject instanceof char[]))
    {
       char[] localObject1 = (char[])paramObject;
      arrayOfObject1 = new Object[localObject1.length];
      for (int i = 0; i < localObject1.length; i++) {
        arrayOfObject1[i] = Character.valueOf(localObject1[i]);
      }
    }
    else
    {
      arrayOfObject1 = getArray(paramObject);
    }
    if ((arrayOfObject1 != null) && (arrayOfObject1.length > 0))
    {
    	ArrayList localObject1 = new ArrayList(arrayOfObject1.length);
      for (Object localObject2 : arrayOfObject1)
      {
        Object localObject3 = toStringValue(localObject2, paramInt);
        if (localObject3 != null) {
          ((List)localObject1).add((String)localObject3);
        }
      }
      if (!((List)localObject1).isEmpty()) {
        return ((List)localObject1).toArray(new String[((List)localObject1).size()]);
      }
    }
    return null;
  }
  
  private static Object toReferenceValue(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof TCComponent)) {
      localObject = paramObject;
    } else if ((paramObject instanceof String)) {
      localObject = convertUIDToTCComponent((String)paramObject);
    }
    return localObject;
  }
  
  private static Object toReferenceValueArray(Object paramObject)
  {
    Object[] arrayOfObject1 = getArray(paramObject);
    if ((arrayOfObject1 != null) && (arrayOfObject1.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject1.length);
      for (Object localObject1 : arrayOfObject1)
      {
        Object localObject2 = toReferenceValue(localObject1);
        if (localObject2 != null) {
          localArrayList.add((TCComponent)localObject2);
        }
      }
      if (!localArrayList.isEmpty()) {
        return localArrayList.toArray(new TCComponent[localArrayList.size()]);
      }
    }
    return null;
  }
  
  private static TCComponent convertUIDToTCComponent(String paramString)
  {
    TCComponent localTCComponent = null;
    if ((paramString != null) && (!paramString.isEmpty()))
    {
      ISessionService localISessionService = Activator.getDefault().getSessionService();
      if (localISessionService != null) {
        try
        {
          TCSession localTCSession = (TCSession)localISessionService.getSession(TCSession.class.getName());
          localTCComponent = localTCSession.stringToComponent(paramString);
        }
        catch (Exception localException)
        {
          logger.error(localException.getLocalizedMessage(), localException);
        }
      }
    }
    return localTCComponent;
  }
  
  private static Object toDateValue(Object paramObject)
  {
    Object localObject = null;
    if ((paramObject instanceof Calendar))
    {
      localObject = paramObject;
    }
    else if ((paramObject instanceof Date))
    {
      GregorianCalendar localGregorianCalendar = new GregorianCalendar();
      localGregorianCalendar.setTime((Date)paramObject);
      localObject = localGregorianCalendar;
    }
    return localObject;
  }
  
  private static Object toDateValueArray(Object paramObject)
  {
    Object[] arrayOfObject1 = getArray(paramObject);
    if ((arrayOfObject1 != null) && (arrayOfObject1.length > 0))
    {
      ArrayList localArrayList = new ArrayList(arrayOfObject1.length);
      for (Object localObject1 : arrayOfObject1)
      {
        Object localObject2 = toDateValue(localObject1);
        if (localObject2 != null) {
          localArrayList.add((Calendar)localObject2);
        }
      }
      if (!localArrayList.isEmpty()) {
        return localArrayList.toArray(new Calendar[localArrayList.size()]);
      }
    }
    return null;
  }
  
  private static Object[] getArray(Object paramObject)
  {
    Object[] arrayOfObject = null;
    if ((paramObject instanceof Object[])) {
      arrayOfObject = (Object[])paramObject;
    } else if ((paramObject instanceof Collection)) {
      arrayOfObject = ((Collection)paramObject).toArray();
    } else {
      arrayOfObject = new Object[] { paramObject };
    }
    return arrayOfObject;
  }
  
  private static void logCreateInputs(List<ICreateInstanceInput> paramList)
  {
    System.out.println("*** Delegating to Generic Create API with the below information ***");
    Iterator localIterator1 = paramList.iterator();
    while (localIterator1.hasNext())
    {
      ICreateInstanceInput localICreateInstanceInput = (ICreateInstanceInput)localIterator1.next();
      IBOCreateDefinition localIBOCreateDefinition = localICreateInstanceInput.getCreateDefinition();
      if (localIBOCreateDefinition != null)
      {
        Map localMap = localICreateInstanceInput.getCreateInputs();
        if ((localMap != null) && (!localMap.isEmpty()))
        {
          System.out.println("BO Name : " + localIBOCreateDefinition.getTypeName());
          Iterator localIterator2 = localMap.entrySet().iterator();
          while (localIterator2.hasNext())
          {
            Map.Entry localEntry = (Map.Entry)localIterator2.next();
            String str1 = ((BOCreatePropertyDescriptor)localEntry.getKey()).getPropertyDescriptor().getName();
            Object localObject = localEntry.getValue();
            String str2 = (localObject != null) && (!localObject.toString().isEmpty()) ? localObject.toString() : "<No Value>";
            System.out.println("[" + str1 + "] - [" + str2 + "]");
          }
        }
      }
    }
  }
  
  private static void logRootInput(CreateInput paramCreateInput, String paramString)
  {
    System.out.println(paramString + "  BO Name : " + paramCreateInput.boName);
    HashMap localHashMap = (HashMap)paramCreateInput.compoundCreateInput;
    if ((localHashMap != null) && (!localHashMap.isEmpty()))
    {
      Set localSet = localHashMap.keySet();
      Object[] arrayOfObject1 = localSet.toArray();
      for (Object localObject1 : arrayOfObject1)
      {
        Object localObject2 = localHashMap.get(localObject1);
        Object[] arrayOfObject3 = null;
        if ((localObject2 instanceof Object[])) {
          arrayOfObject3 = (Object[])localObject2;
        }
        if ((arrayOfObject3 != null) && (arrayOfObject3.length != 0)) {
          for (Object localObject3 : arrayOfObject3) {
            if ((localObject3 instanceof CreateInput))
            {
              System.out.println(paramString + "   -secondary object for : " + paramCreateInput.boName);
              logRootInput((CreateInput)localObject3, paramString + "    ");
            }
          }
        }
      }
    }
  }
}
