package addnew;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import com.teamcenter.rac.ui.commands.Messages;
import com.teamcenter.rac.ui.commands.handlers.NewBOHandler;

public final class NewTableRowHandler
  extends NewBOHandler
{
  public Object execute(ExecutionEvent paramExecutionEvent)
    throws ExecutionException
  {
    this.wizardId = "com.teamcenter.rac.ui.commands.create.bo.MyNewTableRowWizard";
    return super.execute(paramExecutionEvent);
  }
  
  public String getWizardTitle()
  {
    return Messages.getString("NewTableRowWizard.TITLE");
  }
}