//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  IZ3ReleaseStatus

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libIZ3ReleaseStatus

#if !defined(LIBIZ3RELEASESTATUS) && !defined(IPLIB)
#   error IPLIB or LIBIZ3RELEASESTATUS is not defined
#endif

/* Handwritten code should use IZ3RELEASESTATUS_API, not IZ3RELEASESTATUSEXPORT */

#define IZ3RELEASESTATUS_API IZ3RELEASESTATUSEXPORT

#if IPLIB==libIZ3ReleaseStatus || defined(LIBIZ3RELEASESTATUS)
#   if defined(__lint)
#       define IZ3RELEASESTATUSEXPORT       __export(IZ3ReleaseStatus)
#       define IZ3RELEASESTATUSGLOBAL       extern __global(IZ3ReleaseStatus)
#       define IZ3RELEASESTATUSPRIVATE      extern __private(IZ3ReleaseStatus)
#   elif defined(_WIN32)
#       define IZ3RELEASESTATUSEXPORT       __declspec(dllexport)
#       define IZ3RELEASESTATUSGLOBAL       extern __declspec(dllexport)
#       define IZ3RELEASESTATUSPRIVATE      extern
#   else
#       define IZ3RELEASESTATUSEXPORT
#       define IZ3RELEASESTATUSGLOBAL       extern
#       define IZ3RELEASESTATUSPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define IZ3RELEASESTATUSEXPORT       __export(IZ3ReleaseStatus)
#       define IZ3RELEASESTATUSGLOBAL       extern __global(IZ3ReleaseStatus)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define IZ3RELEASESTATUSEXPORT      __declspec(dllimport)
#       define IZ3RELEASESTATUSGLOBAL       extern __declspec(dllimport)
#   else
#       define IZ3RELEASESTATUSEXPORT
#       define IZ3RELEASESTATUSGLOBAL       extern
#   endif
#endif
