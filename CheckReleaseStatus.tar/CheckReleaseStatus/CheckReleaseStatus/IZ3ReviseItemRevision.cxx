//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension IZ3ReviseItemRevision
 *
 */
#include "IZ3ReviseItemRevision.hxx"
#include <iostream>
#include <tccore\grm.h>
#include <epm\epm.h>

int IZ3ReviseItemRevision( METHOD_message_t * msg, va_list args )
{
	std::cout<<"Release status uploaded extension "<<std::endl;

	int ifail =ITK_ok;

	int releasedStatus = NULL;

	tag_t source_rev   = NULLTAG;
	tag_t relation_tag = NULLTAG;

	source_rev = va_arg(args, tag_t);


	ifail =  EPM_ask_if_released(source_rev,&releasedStatus);

	std::cout<<"releasedStatus = "<<releasedStatus<<std::endl;

	if(releasedStatus == 0){

		std::cout<<"Item Revesion is already released. So You can not revise "<<std::endl;
		 EMH_store_error(EMH_severity_error, 919003);
		 return 919003;

		

	}else{
		std::cout<<"Item Revesion is not released. So You can revise "<<std::endl;
	}

 
 return 0;

}