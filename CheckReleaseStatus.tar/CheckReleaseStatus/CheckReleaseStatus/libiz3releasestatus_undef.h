//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBIZ3RELEASESTATUS) && !defined(IPLIB)
#   error IPLIB or LIBIZ3RELEASESTATUS is not defined
#endif

#undef IZ3RELEASESTATUS_API
#undef IZ3RELEASESTATUSEXPORT
#undef IZ3RELEASESTATUSGLOBAL
#undef IZ3RELEASESTATUSPRIVATE
