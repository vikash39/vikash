package com.iz.rga.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class DBConnection {
	private static Connection conn;
	private static final String URL 		= "jdbc:oracle:thin:@//192.168.2.172:1521/TC";
	private static final String USER_ID 	= "tc_fduser";
	private static final String PASSWORD 	= "tc_fduser" ;
	private static final String sForNameDriver = "oracle.jdbc.driver.OracleDriver";
	public static final String PROJECT_TABLE = "MM_FD_PROJECT";
	public static final String PROJECT_USER_TABLE = "MM_FD_PROJECT_USER";
	public static final String PROPERTY_TABLE = "MM_FD_PROPERTY";
	public static Connection getConnection() throws SQLException, Exception {
		if (conn == null || conn.isClosed()) {
			Class.forName(sForNameDriver);
			conn = DriverManager.getConnection(URL,USER_ID,PASSWORD);
		}
		conn.setAutoCommit(true);
		return conn;
	}
	public void closeConnection(Connection dbConn) throws SQLException {
		conn = null;
		dbConn.close();
	}

	public static ResultSet execute(String sqlStatement) throws Exception{
		ResultSet rsProcessList = getConnection().createStatement().executeQuery(sqlStatement);
		return rsProcessList;
	}
	public static int executeUpdateOrDeleteOrInsert(String sqlStatement) throws Exception{
		int rsProcessList = getConnection().createStatement().executeUpdate(sqlStatement);
		return rsProcessList;
	}
	public static ResultSet selectPlatformFromProjectTable() throws Exception
	{
		String sqlStatement="SELECT PLATFORM FROM "+PROJECT_TABLE;
		System.out.println(sqlStatement);
		return execute(sqlStatement);
	}
	
	public static ResultSet selectUserRefIdAndRoleFromProjectUserTable() throws Exception
	{
		String sqlStatement="SELECT REFID,ROLE,USERID FROM "+PROJECT_USER_TABLE;
		System.out.println(sqlStatement);
		return execute(sqlStatement);
	}
	
	public static void removePlatformOrProject(ArrayList<String> removed, String string) throws Exception {
		 String res = String.join(",", removed);
		/*for (int i = 0; i < removed.size(); i++) {
			System.out.println(removed.get(i)+"removed");
			deleteFromConcurrentTable(removed.get(i),string);
		}*/
		deleteFromConcurrentTable(res,string);
		String sqlStatement="DELETE FROM "+PROJECT_TABLE+" WHERE "+string+" IN("+res+")";
		System.out.println(sqlStatement);
		int deletedCount=executeUpdateOrDeleteOrInsert(sqlStatement);
		System.out.println("Number of rows deleted in the Project table "+deletedCount);

	}
	private static void deleteFromConcurrentTable(String remove, String string) throws Exception {
		ArrayList<String> list=new ArrayList<>();
		String select="ID";
		String condition=""+string+" IN("+remove+")";
		ResultSet resultSet = DBConnection.selectFromProjectTable(select,condition);
		while (resultSet.next()) {
			String id=resultSet.getString("ID");
			list.add(id);
		}
		 String res = String.join(",",list);
		DBConnection.deleteFromProjectUserTable(res);
	}
	private static void deleteFromProjectUserTable(String id) throws Exception {
		String sqlStatement="DELETE FROM "+PROJECT_USER_TABLE+" WHERE REFID IN("+id+")" ;
		System.out.println(sqlStatement);
		execute(sqlStatement);
	}
	
	public static void insertRowsIntoTheProjectUserTable(int id, String key, String result) throws Exception {
		String query="INSERT INTO "+PROJECT_USER_TABLE+"(REFID,ROLE,USERID)"+" VALUES "+"("+id+",'"+key+"','"+result+"')";
		System.out.println(query);
		executeUpdateOrDeleteOrInsert(query);
	}
	
	public static void insertingRowsIntoTheProjectTable(ArrayList<String> added, String platformItems) throws Exception {
		
		int insertedRowsCount=0;
		for (int i = 0; i < added.size(); i++) {
			String sqlStatement="INSERT INTO "+PROJECT_TABLE+"(PLATFORM,PROJECT)"+" VALUES "+"('"+platformItems+"','"+added.get(i)+"')";
			insertedRowsCount++;
			System.out.println(sqlStatement);
			executeUpdateOrDeleteOrInsert(sqlStatement);
		}
		System.out.println("Num of rows inserted====== "+insertedRowsCount);
	
	}
	
	public static void updateOrReplaceUsersInTheProjectUserTable(int id, String role, String user) throws Exception {
		String sqlStatement="UPDATE "+PROJECT_USER_TABLE+" SET "+"USERID='"+user+"' WHERE"+" REFID="+id+" AND ROLE='"+role+"'";
		System.out.println(sqlStatement);
		executeUpdateOrDeleteOrInsert(sqlStatement);
	}
	
	public static ResultSet selectFromProjectTable(String select,String condition) throws Exception {
		String sqlQuery="SELECT "+select+" FROM "+PROJECT_TABLE+" WHERE "+condition;
		System.out.println(sqlQuery);
		return execute(sqlQuery);
	}
	
	public static ResultSet selectFromProjectUserTable(String select,String condition) throws Exception {
		String sqlQuery="SELECT "+select+" FROM "+PROJECT_USER_TABLE+" WHERE "+condition;
		System.out.println(sqlQuery);
		return execute(sqlQuery);
	}public static ResultSet selectFromPropertyTable(String select,String condition) throws Exception {
		String sqlQuery="SELECT "+select+" FROM "+PROPERTY_TABLE+" WHERE "+condition;
		System.out.println(sqlQuery);
		return execute(sqlQuery);
	}
	public static void insertRowsIntoThePropertyTable( String key, String result) throws Exception {
		String query="INSERT INTO "+PROPERTY_TABLE+"(KEY,VALUE)"+" VALUES "+"('"+key+"','"+result+"')";
		System.out.println(query);
		executeUpdateOrDeleteOrInsert(query);
	}
	public static void updateIntoPropertyTable( String key, String result) throws Exception {
		String sqlStatement="UPDATE "+PROPERTY_TABLE+" SET "+"VALUE='"+result+"' WHERE"+" KEY='"+key+"'";
		System.out.println(sqlStatement);
		executeUpdateOrDeleteOrInsert(sqlStatement);
	}
}
