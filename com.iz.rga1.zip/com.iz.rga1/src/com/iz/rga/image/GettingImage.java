package com.iz.rga.image;

import org.eclipse.swt.graphics.Image;
import org.eclipse.wb.swt.SWTResourceManager;


public class GettingImage {
	public static Image getImage(String imageName) {
		return SWTResourceManager.getImage(GettingImage.class, "/com/iz/rga/icons/"+imageName+".png");
	}
}
