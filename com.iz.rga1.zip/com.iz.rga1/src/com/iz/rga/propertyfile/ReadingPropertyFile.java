package com.iz.rga.propertyfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public class ReadingPropertyFile {
	public  Properties readProperty() throws IOException
	{
		FileInputStream input=new FileInputStream(new File("RGAPropertyFile.properties"));
		Properties property=new Properties();
		property.load(input);
		return property;
	}
}
