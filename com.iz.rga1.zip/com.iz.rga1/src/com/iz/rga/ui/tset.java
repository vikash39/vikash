package com.iz.rga.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class tset {
public static void main(String[] args) throws ParseException {
	  String today = convertdate("10/03/2015");
      System.out.println("Today : " + today);
}
public static String convertdate(String recivieddate) throws ParseException {
    SimpleDateFormat in = new SimpleDateFormat("dd/MM/yyyy");
    Date date = in.parse(recivieddate);
    System.out.println(date);
    SimpleDateFormat out = new SimpleDateFormat("");
    String newdate = out.format(date);
    return newdate;
}
}
