package com.iz.rga.ui;

import java.text.SimpleDateFormat;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;


import org.eclipse.swt.widgets.Composite;



public class DataTimeDialog implements Listener{
	public  String selectedDate;
	private DateTime dateTimeCalendar;
	private Shell shlDateControl;

	public static void main(String[] args) {
		new DataTimeDialog();
	}
	public DataTimeDialog(){

		shlDateControl = new Shell (Display.getDefault().getActiveShell(),SWT.APPLICATION_MODAL | SWT.CLOSE);
		shlDateControl.setSize(330, 316);
		shlDateControl.setText("Date Control");
		shlDateControl.setLayout (new GridLayout (1, false));

		Composite composite = new Composite(shlDateControl, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, false, false, 1, 1));
		composite.setLayout(new GridLayout(2, false));


		dateTimeCalendar = new DateTime (composite, SWT.CALENDAR | SWT.BORDER);
		dateTimeCalendar.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		

		Button btnCancel = createbtn(composite,"Cancel");
		btnCancel.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, true, false, 1, 1));

		Button btnOk = createbtn(composite,"Ok");
		btnOk.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));

		Point pt = Display.getDefault().getCursorLocation();
		shlDateControl.setLocation(pt.x, pt.y);
		shlDateControl.pack ();

		shlDateControl.open();
		shlDateControl.layout();
		while (!shlDateControl.isDisposed()) {
			if (!Display.getDefault().readAndDispatch()) {
				Display.getDefault().sleep();
			}
		}
	}
	private Button createbtn(Composite composite, String string) {
		Button btn = new Button(composite, SWT.NONE);
		btn.setText(string);
		btn.setData("Action",string);
		btn.addListener(SWT.MouseUp, this);
		return btn;

	}
	@Override
	public void handleEvent(Event event) {
		String clickAction = (String)event.widget.getData("Action");
		if(clickAction.equalsIgnoreCase("Cancel"))
		{
			shlDateControl.close ();
		}
		if(clickAction.equalsIgnoreCase("Ok"))
		{
			System.out.println ("Calendar date selected (MM/dd/yyyy) = " + (dateTimeCalendar.getMonth () + 1) + "/" + dateTimeCalendar.getDay () + "/" + dateTimeCalendar.getYear ());
			selectedDate = dateTimeCalendar.getDay () + "/" +  (dateTimeCalendar.getMonth () + 1) + "/" + dateTimeCalendar.getYear (); //+ " " + time.getHours () + ":" + (time.getMinutes () < 10 ? "0" : "") + time.getMinutes ();

			shlDateControl.close ();
		}
	}



}