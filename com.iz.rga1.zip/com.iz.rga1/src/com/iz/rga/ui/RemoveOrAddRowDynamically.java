package com.iz.rga.ui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.IColumnAccessor;
import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;

public class RemoveOrAddRowDynamically extends ListDataProvider<GetAndSetNatData>{
	List<GetAndSetNatData> list;
	public RemoveOrAddRowDynamically(List<GetAndSetNatData> list, IColumnAccessor<GetAndSetNatData> columnAccessor) {
		super(list, columnAccessor);
		this.list=list;
	}

	void addingRowDynamically(GetAndSetNatData details)
	{
		list.add(details);
	}

	public void addingRowDynamically(GetAndSetNatData details, int row) {
		list.add(row, details);
	}
	public void removeRowDynamically(int row) {
		list.remove(row);
	}
	
	public void removeRowDynamically(GetAndSetNatData details, int row) {
		
		
		list.remove(details);
	}

	/*public void removed(ArrayList<String> list2) {
		HashMap<String , GetAndSetNatData> val=new HashMap<>();
		for (int i = 0; i < list.size(); i++) {
			GetAndSetNatData get = list.get(i);
			String values = get.getColumnListValues().get(1);
			val.put(values, get);
		}
		
		for (int i = 0; i < list2.size(); i++) {
			GetAndSetNatData hdsfs = val.get(list2.get(i));
			list.remove(hdsfs);
		}
	}*/

	public void removeMultipleRows(ArrayList<GetAndSetNatData> removeRows) {
		for (int i = 0; i < removeRows.size(); i++) {
			list.remove(removeRows.get(i));
		}
	}
}
