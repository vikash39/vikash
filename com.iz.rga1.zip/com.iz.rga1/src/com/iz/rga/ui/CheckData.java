package com.iz.rga.ui;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.ListDataProvider;
import org.eclipse.nebula.widgets.nattable.data.validate.DataValidator;


public class CheckData extends DataValidator {




	private NatDataProvider dataProvider;
	private RemoveOrAddRowDynamically rowObject;

	public CheckData(NatDataProvider dataProvider, RemoveOrAddRowDynamically addingRow) {
		this.dataProvider=dataProvider;
		this.rowObject=addingRow;
	}

	@Override
	public boolean validate(int columnIndex, int rowIndex, Object enteredValue) {

		ArrayList<String> checkDuplicates = dataProvider.str;
		String tractorSlNum= rowObject.getDataValue(1, rowIndex).toString();
		
		if(enteredValue==null ||enteredValue=="" || tractorSlNum.equalsIgnoreCase(enteredValue.toString())) 
			return true;
		if(checkDuplicates.contains(enteredValue.toString()))
			return false;


		return true;

	}

}
