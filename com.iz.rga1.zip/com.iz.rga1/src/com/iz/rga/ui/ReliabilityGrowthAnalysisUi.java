package com.iz.rga.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.Properties;

import org.eclipse.jface.fieldassist.ControlDecoration;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;

import com.iz.rga.db.DBConnection;
import com.iz.rga.image.GettingImage;
import com.iz.rga.propertyfile.ReadingPropertyFile;

public class ReliabilityGrowthAnalysisUi implements Listener{


	public static void main(String[] args) throws Exception {
		new ReliabilityGrowthAnalysisUi();
	}
	private Combo comboProject;
	private Text txtForStrDate;
	private Text txtForEndDate;
	private Shell shlReliabiltyGrowthAnalysis;
	private NatTableForCumulativeHrs natTableForCumulativeHours;
	private Combo cumulativeHrsCombo;
	private Composite compositeForNatTable;
	private GridData gridDataForNatTable;
	public ReliabilityGrowthAnalysisUi() throws Exception {
		
		ReadingPropertyFile file=new ReadingPropertyFile();
		Properties property = file.readProperty();
		String gntReport = property.getProperty("GntReport");
		
		Display display=Display.getDefault();
		shlReliabiltyGrowthAnalysis = new Shell(display, SWT.MIN | SWT.MAX | SWT.RESIZE);
		shlReliabiltyGrowthAnalysis.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		shlReliabiltyGrowthAnalysis.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		shlReliabiltyGrowthAnalysis.setText("Reliabilty Growth Analysis");
		shlReliabiltyGrowthAnalysis.setLayout(new GridLayout(1, true));
		shlReliabiltyGrowthAnalysis.setSize(1000, 500);

		Composite compositeForGenerateReportLbl = createomposite(shlReliabiltyGrowthAnalysis);
		compositeForGenerateReportLbl.setLayout(new GridLayout(1, false));

		Label lblGenerateReport = new Label(compositeForGenerateReportLbl, SWT.NONE);
		lblGenerateReport.setText(gntReport);
		lblGenerateReport.setFont(new Font(null,"Segoe UI", 9, SWT.BOLD ));

		Composite compositeForLblComboText =createomposite(shlReliabiltyGrowthAnalysis);
		GridLayout gridLayoutForLblComboText = new GridLayout(4, true);
		gridLayoutForLblComboText.verticalSpacing = 5;
		gridLayoutForLblComboText.horizontalSpacing = 25;
		compositeForLblComboText.setLayout(gridLayoutForLblComboText);
		compositeForLblComboText.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));


		String buildStage = property.getProperty("BldStage");
		String platform = property.getProperty("Platform");
		String project = property.getProperty("Project");
		String methodology = property.getProperty("Methodology");
		String timeInterval = property.getProperty("TimeInterval");
		String targetMTBF = property.getProperty("Target");
		String cumulativeHrsInput = property.getProperty("CumulativeHrsIp");
		String effectivenessFactor = property.getProperty("EffectivenessFactor");
		String MTBFCalculation = property.getProperty("MTBFCalculation");
		String strDate = property.getProperty("StrDate");
		String endDate = property.getProperty("EndDate");
		String lalNames[]= {buildStage,platform,project,methodology};
		for (int i = 0; i < lalNames.length; i++) {
			createlabel(compositeForLblComboText,lalNames[i]);
		}

		Combo comboBuildStage = createombo(compositeForLblComboText,buildStage);
		String buildStageItems[]= {"Gen2"};
		comboBuildStage.setItems(buildStageItems);

		Combo comboPlatform = createombo(compositeForLblComboText,platform);
		comboPlatform.addListener(SWT.Selection, this);
		ResultSet result = DBConnection.selectPlatformFromProjectTable();
		setValues(result, comboPlatform);

		comboProject=createombo(compositeForLblComboText,project);
		createombo(compositeForLblComboText,methodology);

		String lblNames1[]= {timeInterval,targetMTBF,cumulativeHrsInput,effectivenessFactor};
		for (int i = 0; i < lblNames1.length; i++) {
			createlabel(compositeForLblComboText, lblNames1[i]);
		}

		Combo comboTimeIntervals = createombo(compositeForLblComboText,timeInterval);
		String time[]= {"Daily","Weekly"};
		comboTimeIntervals.setItems(time);

       //Text for TagetMTBF	
		createText(compositeForLblComboText);

		cumulativeHrsCombo = createombo(compositeForLblComboText,cumulativeHrsInput);
		String items[]= {"Manual","Computed"};
		cumulativeHrsCombo.addListener(SWT.Modify, this);
		cumulativeHrsCombo.setItems(items);

		Combo comboEffFactor = createombo(compositeForLblComboText,effectivenessFactor);
		String effFac[]= {"Yes","No"};
		comboEffFactor.setItems(effFac);

		String lblNames2[]= {MTBFCalculation,strDate,endDate};
		for (int i = 0; i < lblNames2.length; i++) {
			createlabel(compositeForLblComboText, lblNames2[i]);
		}
		Combo comboMTBFCal = createombo(compositeForLblComboText,MTBFCalculation);
		String MTBF[]= {"Roll up","Project Comparison"};
		comboMTBFCal.setItems(MTBF);

		Composite compositeForTextStrDate=createCompositeForTextAndDate(compositeForLblComboText);


		txtForStrDate=createText(compositeForTextStrDate);
		createButton(compositeForTextStrDate, "date1", false,"StrDate");

		Composite compositeForTextEndDate=createCompositeForTextAndDate(compositeForLblComboText);

		txtForEndDate=createText(compositeForTextEndDate);
		createButton(compositeForTextEndDate, "date1", false,"EndDate");
		
		compositeForNatTable = new Composite(shlReliabiltyGrowthAnalysis, SWT.NONE);
		gridDataForNatTable = new GridData(SWT.FILL, SWT.FILL, true, true);
		compositeForNatTable.setLayoutData(gridDataForNatTable);
		compositeForNatTable.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		compositeForNatTable.setLayout(new GridLayout(3,false));
		
		natTableForCumulativeHours = new NatTableForCumulativeHrs();
		
		gridDataForNatTable.exclude  = true;
		compositeForNatTable.layout(true);

		Composite compositeForGenerateReportExportToexcel = createomposite(shlReliabiltyGrowthAnalysis);
		compositeForGenerateReportExportToexcel.setLayout(new GridLayout(2, false));
		compositeForGenerateReportExportToexcel.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));

		createButton(compositeForGenerateReportExportToexcel,"Generate Report",true,"Report");
		createButton(compositeForGenerateReportExportToexcel,"Export To Excel", true,"ExportToExcel");
		shlReliabiltyGrowthAnalysis.open();
		while (!shlReliabiltyGrowthAnalysis.isDisposed ()) {
			if (!display.readAndDispatch ()) display.sleep ();
		}


	}
	private Composite createCompositeForTextAndDate(Composite compositeForLblComboText) {
		Composite composite= new Composite(compositeForLblComboText, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		GridLayout gridLayout = new GridLayout(2, false);
		gridLayout.marginWidth = 0;
		gridLayout.marginHeight = 0;
		gridLayout.verticalSpacing = 0;
		gridLayout.horizontalSpacing = 0;
		composite.setLayout(gridLayout);
		return composite;
	}
	private Composite createomposite(Shell shlReliabiltyGrowthAnalysis) {
		Composite composite= new Composite(shlReliabiltyGrowthAnalysis, SWT.NONE);
		composite.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		return composite;

	}
	private void createButton(Composite composite, String btnText, boolean textOrImage, String string) {
		Button btn = new Button(composite, SWT.NONE);
		if(textOrImage)
			btn.setText(btnText);
		else
			btn.setImage(GettingImage.getImage(btnText));
		btn.setData("Action",string);
		btn.addListener(SWT.MouseUp,this);
	}
	private Text createText(Composite composite) {
		Text text = new Text(composite, SWT.BORDER);
		text.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		return text;

	}
	private Combo createombo(Composite composite, String lblName) {
		Combo combo = new Combo(composite, SWT.NONE);
		combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		combo.setData("Action",lblName);
		return combo;
	}
	private Label createlabel(Composite composite, String lblName) {
		Label lbl = new Label(composite, SWT.NONE);
		lbl.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lbl.setText(lblName);
		lbl.setFont(new Font(null,"Segoe UI", 9, SWT.BOLD ));
		if(!lblName.equalsIgnoreCase("Project"))
			setMandatoryText(lbl);
		if(lblName.equalsIgnoreCase("End Date"))
			lbl.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		return lbl;
	}
	private void setMandatoryText(Label lbl) {
		ControlDecoration star=new ControlDecoration(lbl, SWT.RIGHT|SWT.TOP);
		star.setImage(GettingImage.getImage("star"));
		star.show();

	}
	@Override
	public void handleEvent(Event event) {
		String clickAction = (String) event.widget.getData("Action");

		if(clickAction.equalsIgnoreCase("Platform"))
		{
			String platformItems = ((Combo) event.widget).getText();
			comboProject.removeAll();
			getProjectValues(platformItems.trim(), comboProject);
		}
		if(clickAction.equalsIgnoreCase("Cumulative Hours Input"))
		{

			String cumulativeHours = ((Combo) event.widget).getText();
			if(cumulativeHours.equalsIgnoreCase("Manual"))
			{
				try {
					if( !txtForStrDate.getText().isEmpty() && !txtForEndDate.getText().isEmpty())
					{
							creatingNattable();
						
					} 
					}
				catch (Exception e) {
					e.printStackTrace();
				}

				
			}
			else if(cumulativeHours.equalsIgnoreCase("Computed"))
			{
				
				gridDataForNatTable.exclude  = true;
				compositeForNatTable.setVisible(false);
				compositeForNatTable.layout(false);
				compositeForNatTable.update();
				compositeForNatTable.getParent().layout(false);
				shlReliabiltyGrowthAnalysis.update();
				
			}


		}
		if(clickAction.equalsIgnoreCase("StrDate"))
		{
			try {
				DataTimeDialog dateDialog = new	DataTimeDialog();
				txtForStrDate.setText(dateDialog.selectedDate);


				if( !txtForStrDate.getText().isEmpty() && !txtForEndDate.getText().isEmpty()
						&& cumulativeHrsCombo.getText().equalsIgnoreCase("Manual"))
				{
					creatingNattable();
				}


			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		if(clickAction.equalsIgnoreCase("EndDate"))
		{
			try {
				DataTimeDialog dateDialog = new	DataTimeDialog();
				txtForEndDate.setText(dateDialog.selectedDate);
				if( !txtForStrDate.getText().isEmpty() && !txtForEndDate.getText().isEmpty()
						&& cumulativeHrsCombo.getText().equalsIgnoreCase("Manual"))
				{
					creatingNattable();

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	private void creatingNattable() throws Exception {
		LinkedHashMap<String, ArrayList<String>> mapNatTableData=getlist();
		ArrayList<String> listStrDateAndEndDateIntervals=getDateIntervals();
		natTableForCumulativeHours.createNatTable(compositeForNatTable,listStrDateAndEndDateIntervals, mapNatTableData);
		gridDataForNatTable.exclude  = false;
		compositeForNatTable.setVisible(true);
		compositeForNatTable.layout(false);
		compositeForNatTable.update();
		compositeForNatTable.getParent().layout(false);
		shlReliabiltyGrowthAnalysis.update();
		
	}
	private LinkedHashMap<String, ArrayList<String>> getlist() throws Exception {
		Ex ex = new Ex(txtForStrDate.getText(),txtForEndDate.getText());
		LinkedHashMap<String, ArrayList<String>> list = ex.hmapFilterExcel;
		return list;
	}
	private ArrayList<String> getDateIntervals() {

		ArrayList<String> listStrDateAndEndDateIntervals=new ArrayList<>();
		String strStartDate = txtForStrDate.getText();
		String strendDate = txtForEndDate.getText();
		try {
			DateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
			Date dateStartDate=dateFormat.parse(strStartDate);
			Date dateEndDate=dateFormat.parse(strendDate);
			Calendar calendar = new GregorianCalendar();
			calendar.setTime(dateStartDate);
			
			while (calendar.getTime().before(dateEndDate))
			{

				Date result = calendar.getTime();
				String formate = dateFormat.format(result);
				listStrDateAndEndDateIntervals.add(formate);
				calendar.add(Calendar.DATE, 1);
			}
			listStrDateAndEndDateIntervals.add(strendDate);

		} catch (ParseException e) {
			e.printStackTrace();
		} 

		return listStrDateAndEndDateIntervals;
	}
	public void getProjectValues(String platformItems, Combo combo) {
		ArrayList<String> list=new ArrayList<>();
		try {
			String select="PROJECT";
			String condition="PLATFORM='"+platformItems.trim()+"'";

			ResultSet resultSet = DBConnection.selectFromProjectTable(select,condition);
			while (resultSet.next()) {
				String projectValues=resultSet.getString("PROJECT");
				list.add(projectValues);
			}
			String[] stringArray = list.toArray(new String[0]);
			combo.setItems(stringArray);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private  void setValues(ResultSet resultSet, Combo combo) throws SQLException {
		ArrayList<String> list=new ArrayList<>();
		while(resultSet.next())
		{
			String values=resultSet.getString("PLATFORM");
			if(list.contains(values))
			{
				System.out.println("already exist");
			}
			else
				list.add(values);
		}
		String[] stringArray = list.toArray(new String[0]);
		combo.setItems(stringArray);
	}
}
