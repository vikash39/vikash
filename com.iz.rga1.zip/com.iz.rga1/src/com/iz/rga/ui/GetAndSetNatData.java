package com.iz.rga.ui;

import java.util.ArrayList;

public class GetAndSetNatData {
	private String value;
	private String project;
	private ArrayList<String> columnListValues;

	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}


	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value=value;
	}
	public ArrayList<String> getColumnListValues() {
		return columnListValues;
	}
	public void setColumnListValues(ArrayList<String> columnListValues) {
		this.columnListValues = columnListValues;
	}

}
