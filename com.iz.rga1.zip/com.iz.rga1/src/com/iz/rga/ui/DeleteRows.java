package com.iz.rga.ui;

import java.util.Collection;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.command.AbstractMultiRowCommand;
import org.eclipse.nebula.widgets.nattable.command.ILayerCommand;
import org.eclipse.nebula.widgets.nattable.command.ILayerCommandHandler;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.event.RowDeleteEvent;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;

public class DeleteRows extends AbstractMultiRowCommand {

	protected DeleteRows(AbstractMultiRowCommand command) {
		super(command);
	}
	
	  protected DeleteRows(ILayer layer, int[] rowPositions) {
	        super(layer, rowPositions);
	    }
	  
	@Override
	public ILayerCommand cloneCommand() {
		return new DeleteRows(this);
	}
	
}
