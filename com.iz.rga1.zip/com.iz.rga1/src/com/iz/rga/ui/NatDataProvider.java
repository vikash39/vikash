package com.iz.rga.ui;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.data.IColumnAccessor;
import org.eclipse.nebula.widgets.nattable.data.IColumnPropertyAccessor;

public class NatDataProvider implements IColumnAccessor<GetAndSetNatData>,IColumnPropertyAccessor<GetAndSetNatData>{
	List<String> lst_prop_name;
//	private NatTableForCumulativeHrs natTableForCumulativeHrs;
public ArrayList<String> str=new ArrayList<>();

	public NatDataProvider(List<String> date1) {
		
		this.lst_prop_name=date1;
		//this.natTableForCumulativeHrs=natTableForCumulativeHrs;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return lst_prop_name.size();
	}


	@Override
	public Object getDataValue(GetAndSetNatData details, int idx) {
		if(idx==0 )
			return details.getColumnListValues().get(0);
		 if ( idx==1) {
			return details.getColumnListValues().get(1);
		}
		else
			return details.getColumnListValues().get(idx);
	}

	@Override
	public void setDataValue(GetAndSetNatData details, int arg1, Object arg2) {
		if(arg1==0)
		{
			details.getColumnListValues().set(0, arg2.toString());
		}
	   if ( arg1==1) {
		   if(arg2.toString()==null || arg2.toString()=="")
		   {
			   details.getColumnListValues().set(1,"");
		   }
		   else
		   {
			   details.getColumnListValues().set(1, arg2.toString());
				str.add((String)arg2);   
		   }
			
		}
		else
		{
			details.getColumnListValues().set(arg1, arg2.toString());
		}
	}

	@Override
	public int getColumnIndex(String arg0) {
		return 0;
	}

	@Override
	public String getColumnProperty(int arg0) {
		return lst_prop_name.get(arg0);
	}

}
