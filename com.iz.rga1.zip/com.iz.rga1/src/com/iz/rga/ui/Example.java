package com.iz.rga.ui;

import java.io.IOException;
import java.util.Properties;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Button;
import org.eclipse.wb.swt.SWTResourceManager;

import com.iz.rga.image.GettingImage;
import com.iz.rga.propertyfile.ReadingPropertyFile;
import org.eclipse.swt.widgets.Text;

public class Example extends Shell {
	private Text text;
	private Text text_1;
	private Text text_2;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			Display display = Display.getDefault();
			Example shell = new Example(display);
			shell.open();
			shell.layout();
			while (!shell.isDisposed()) {
				if (!display.readAndDispatch()) {
					display.sleep();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the shell.
	 * @param display
	 * @throws IOException 
	 */
	public Example(Display display) throws IOException {
		super(display, SWT.SHELL_TRIM);
		setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		setLayout(new GridLayout(1, false));
		
		ReadingPropertyFile file=new ReadingPropertyFile();
		Properties property = file.readProperty();
		String gntReport = property.getProperty("GntReport");
		String buildStage = property.getProperty("BldStage");
		String platform = property.getProperty("Platform");
		String project = property.getProperty("Project");
		String methodology = property.getProperty("Methodology");
		String timeInterval = property.getProperty("TimeInterval");
		String targetMTBF = property.getProperty("Target");
		String cumulativeHrsInput = property.getProperty("CumulativeHrsIp");
		String effectivenessFactor = property.getProperty("EffectivenessFactor");
		String MTBFCalculation = property.getProperty("MTBFCalculation");
		String strDate = property.getProperty("StrDate");
		String endDate = property.getProperty("EndDate");
		
		
		
		Composite composite1 = new Composite(this, SWT.NONE);
		composite1.setLayoutData(new GridData(SWT.FILL, SWT.TOP, true, false));
		composite1.setLayout(new GridLayout(1, false));
		
		Label label = new Label(composite1, SWT.NONE);
		label.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		label.setText("Generate Report");
		
		
		Composite composite = new Composite(this, SWT.NONE);
		composite.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite.setLayout(new GridLayout(1, false));
		composite.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false, 1, 1));
		
		Composite composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		GridLayout gl_composite_1 = new GridLayout(6, false);
		composite_1.setLayout(gl_composite_1);
		composite_1.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 1, 1));
		
		Label lblNewLabel = new Label(composite_1, SWT.NONE);
		lblNewLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		lblNewLabel.setText("New Label");
		
		Label lblNewLabel_1 = new Label(composite_1, SWT.NONE);
		lblNewLabel_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		lblNewLabel_1.setText("New Label");
		
		Label lblNewLabel_3 = new Label(composite_1, SWT.NONE);
		lblNewLabel_3.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		lblNewLabel_3.setText("New Label");
		
		Label lblNewLabel_15 = new Label(composite_1, SWT.NONE);
		lblNewLabel_15.setText("New Label");
		
		Combo combo = new Combo(composite_1, SWT.NONE);
		combo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Combo combo_1 = new Combo(composite_1, SWT.NONE);
		combo_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		Combo combo_3 = new Combo(composite_1, SWT.NONE);
		combo_3.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		Combo combo_13 = new Combo(composite_1, SWT.NONE);
		combo_13.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblNewLabel_4 = new Label(composite_1, SWT.NONE);
		lblNewLabel_4.setText("New Label");
		
		Label lblNewLabel_5 = new Label(composite_1, SWT.NONE);
		lblNewLabel_5.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblNewLabel_5.setText("New Label");
		
		Label lblNewLabel_7 = new Label(composite_1, SWT.NONE);
		lblNewLabel_7.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblNewLabel_7.setText("New Label");
		
		Label lblNewLabel_16 = new Label(composite_1, SWT.NONE);
		lblNewLabel_16.setText("New Label");
		
		Combo combo_5 = new Combo(composite_1, SWT.NONE);
		combo_5.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		text_2 = new Text(composite_1, SWT.BORDER);
		text_2.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		Combo combo_8 = new Combo(composite_1, SWT.NONE);
		combo_8.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		Combo combo_14 = new Combo(composite_1, SWT.NONE);
		combo_14.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Label lblNewLabel_10 = new Label(composite_1, SWT.NONE);
		lblNewLabel_10.setText("New Label");
		
		Label lblNewLabel_11 = new Label(composite_1, SWT.NONE);
		lblNewLabel_11.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		lblNewLabel_11.setText("New Label");
		
		Label lblNewLabel_13 = new Label(composite_1, SWT.NONE);
		lblNewLabel_13.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 3, 1));
		lblNewLabel_13.setText("New Label");
		
		Combo combo_10 = new Combo(composite_1, SWT.NONE);
		combo_10.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		text = new Text(composite_1, SWT.BORDER);
		text.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Button btnNewButton = new Button(composite_1, SWT.NONE);
		btnNewButton.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		btnNewButton.setImage(GettingImage.getImage("date"));
		
		text_1 = new Text(composite_1, SWT.BORDER);
		text_1.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 1, 1));
		
		Button btnOk = new Button(composite_1, SWT.NONE);
		btnOk.setLayoutData(new GridData(SWT.LEFT, SWT.FILL, false, true, 1, 1));
		btnOk.setImage(GettingImage.getImage("date"));
		new Label(composite_1, SWT.NONE);
		Composite composite2 = new Composite(this, SWT.NONE);
		composite2.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		composite2.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		composite2.setLayout(new GridLayout(2, false));
		
		Button btnNewButton_1 = new Button(composite2, SWT.NONE);
		btnNewButton_1.setText("New Button");
		
		Button btnNewButton_2 = new Button(composite2, SWT.NONE);
		btnNewButton_2.setText("New Button");
		
		createContents();
	}

	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("SWT Application");
		setSize(450, 300);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
}
