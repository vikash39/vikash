package com.iz.rga.ui;

import org.eclipse.nebula.widgets.nattable.data.convert.DefaultIntegerDisplayConverter;

public class IntegerConvertor extends DefaultIntegerDisplayConverter {

	@Override
	protected Object convertToNumericValue(String value) {
		
		if(value == null  || value.isEmpty())
			return "";
		
		return super.convertToNumericValue(value);
	}
}
