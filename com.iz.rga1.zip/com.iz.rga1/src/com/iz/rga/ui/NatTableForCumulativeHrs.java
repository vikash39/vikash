package com.iz.rga.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.nebula.widgets.nattable.NatTable;
import org.eclipse.nebula.widgets.nattable.config.AbstractRegistryConfiguration;
import org.eclipse.nebula.widgets.nattable.config.CellConfigAttributes;
import org.eclipse.nebula.widgets.nattable.config.DefaultNatTableStyleConfiguration;
import org.eclipse.nebula.widgets.nattable.config.IConfigRegistry;
import org.eclipse.nebula.widgets.nattable.config.IEditableRule;
import org.eclipse.nebula.widgets.nattable.data.IDataProvider;
import org.eclipse.nebula.widgets.nattable.edit.EditConfigAttributes;
import org.eclipse.nebula.widgets.nattable.edit.config.DialogErrorHandling;
import org.eclipse.nebula.widgets.nattable.edit.config.LoggingErrorHandling;
import org.eclipse.nebula.widgets.nattable.edit.editor.IEditErrorHandler;
import org.eclipse.nebula.widgets.nattable.grid.GridRegion;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultColumnHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultCornerDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.data.DefaultRowHeaderDataProvider;
import org.eclipse.nebula.widgets.nattable.grid.layer.ColumnHeaderLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.CornerLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.DefaultGridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.GridLayer;
import org.eclipse.nebula.widgets.nattable.grid.layer.RowHeaderLayer;
import org.eclipse.nebula.widgets.nattable.layer.DataLayer;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.cell.ColumnOverrideLabelAccumulator;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;
import org.eclipse.nebula.widgets.nattable.style.CellStyleAttributes;
import org.eclipse.nebula.widgets.nattable.style.ConfigAttribute;
import org.eclipse.nebula.widgets.nattable.style.DisplayMode;
import org.eclipse.nebula.widgets.nattable.style.Style;
import org.eclipse.nebula.widgets.nattable.tooltip.NatTableContentTooltip;
import org.eclipse.nebula.widgets.nattable.util.GUIHelper;
import org.eclipse.nebula.widgets.nattable.viewport.ViewportLayer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.wb.swt.SWTResourceManager;
import org.osgi.framework.AllServiceListener;

public class NatTableForCumulativeHrs implements Listener{

	RemoveOrAddRowDynamically addingRow;
	//int rowCount=0;
	public  String project="PROJECT";
	public  String slNum="Sl. No";
	public  String integer="INTEGER";
	private SelectionLayer selectionLayer;
	public	NatTable natTable;
	private Button btnForDeleteRow;
	private Button btnForAddRow;
	private NatDataProvider dataProvider;
	private ArrayList<String> listStrDateAndEndDateIntervals;
	private Button btnForClear;

	public static void main(String[] args) {
		//new NatTableForCumulativeHrs();
	}

	public void createNatTable(Composite composite1,ArrayList<String> listStrDateAndEndDateIntervals, LinkedHashMap<String, ArrayList<String>> mapNatData) {

		if(natTable!=null || btnForAddRow!=null || btnForDeleteRow!=null || btnForClear!=null)
		{
			natTable.dispose();	
			btnForAddRow.dispose();
			btnForDeleteRow.dispose();
			btnForClear.dispose();

		}


		this.listStrDateAndEndDateIntervals=listStrDateAndEndDateIntervals;
		String[] dynamicDates=listStrDateAndEndDateIntervals.toArray(new String[listStrDateAndEndDateIntervals.size()]);
		String[] prjSlNum= {"Project","Tractor Sl. No"};
		String[] natHeaders=murgeArrys(dynamicDates,prjSlNum);
		List<String> listnatHeaders=Arrays.asList(natHeaders);

		//Body layer
		dataProvider=new NatDataProvider(listnatHeaders);

		ArrayList<GetAndSetNatData> listNatData=new ArrayList<>();
		for(Map.Entry<String, ArrayList<String>> entry:mapNatData.entrySet()){

			ArrayList<String> listGetDataFronMap=entry.getValue();
			ArrayList<String> listSetColumnListValues=new ArrayList<>();
			GetAndSetNatData obj = new GetAndSetNatData();
			//obj.setProject(listGetDataFronMap.get(0));
			String strPrjValue = entry.getKey();

			//obj.setValue(strPrjValue);

			listSetColumnListValues.add(listGetDataFronMap.get(0));
			listGetDataFronMap.remove(0);
			listSetColumnListValues.add(strPrjValue);

			dataProvider.str.add(strPrjValue);
			for (int i = 0; i < listGetDataFronMap.size(); i++) {
				listSetColumnListValues.add(listGetDataFronMap.get(i));
			}

			obj.setColumnListValues(listSetColumnListValues);
			listNatData.add(obj);

		}

		addingRow=new RemoveOrAddRowDynamically(listNatData, dataProvider);
		DataLayer bodyDataLayer = new DataLayer(addingRow);
		bodyDataLayer.setColumnPercentageSizing(true);
		selectionLayer = new SelectionLayer(bodyDataLayer);
		ViewportLayer viewportLayer = new ViewportLayer(selectionLayer);

		//bodyDataLayer.registerCommandHandler(new DeleteMultiRowCommandHandler<>(addingRow.getList()));
		//column layer
		IDataProvider headerDataProvider = new DefaultColumnHeaderDataProvider(natHeaders);
		DataLayer headerDataLayer =new DataLayer(headerDataProvider);
		ILayer columnHeaderLayer =new ColumnHeaderLayer(headerDataLayer, viewportLayer, selectionLayer);

		//Row layer
		IDataProvider rowDataProvider=new DefaultRowHeaderDataProvider(addingRow);
		DataLayer RowDataLayer=new DataLayer(rowDataProvider,40,20);
		ILayer rowHeaderLayer=new RowHeaderLayer(RowDataLayer, viewportLayer, selectionLayer);


		//corner layer
		IDataProvider carnerDataProvider=new DefaultCornerDataProvider(headerDataProvider, rowDataProvider);
		DataLayer carnerDataLayer=new DataLayer(carnerDataProvider);
		ILayer cornerLayer=new CornerLayer(carnerDataLayer, rowHeaderLayer, columnHeaderLayer);


		GridLayer layer=new GridLayer(viewportLayer,columnHeaderLayer,rowHeaderLayer, cornerLayer);

		ColumnOverrideLabelAccumulator columnLabelAccumulator =new ColumnOverrideLabelAccumulator(viewportLayer);
		viewportLayer.setConfigLabelAccumulator(columnLabelAccumulator);

		for (int i = 0; i < natHeaders.length; i++) {
			if(i==0)
			{
				columnLabelAccumulator.registerColumnOverrides(0,project);
			}
			else if (i==1) {
				columnLabelAccumulator.registerColumnOverrides(1,slNum);
			}
			else
			{
				columnLabelAccumulator.registerColumnOverrides(i, integer);
			}


		}
		natTable = new NatTable(composite1,layer,false);
		
		natTable.addConfiguration(new DefaultNatTableStyleConfiguration());
		natTable.addConfiguration(new AbstractRegistryConfiguration() {
			@Override
			public void configureRegistry(IConfigRegistry configReg) {
				System.out.println("configure");
				configReg.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,IEditableRule.ALWAYS_EDITABLE,DisplayMode.EDIT,project);
				configReg.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,IEditableRule.ALWAYS_EDITABLE,DisplayMode.EDIT,integer);
				configReg.registerConfigAttribute(CellConfigAttributes.DISPLAY_CONVERTER,new IntegerConvertor(), DisplayMode.NORMAL,integer);
				configReg.registerConfigAttribute(EditConfigAttributes.CELL_EDITABLE_RULE,IEditableRule.ALWAYS_EDITABLE,DisplayMode.EDIT,slNum);
//				configReg.registerConfigAttribute(EditConfigAttributes.DATA_VALIDATOR,new CheckData(dataProvider),DisplayMode.NORMAL,slNum);
				configReg.registerConfigAttribute(EditConfigAttributes.DATA_VALIDATOR,new CheckData(dataProvider,addingRow),DisplayMode.EDIT,slNum);
				/*configReg.registerConfigAttribute(
			                EditConfigAttributes.VALIDATION_ERROR_HANDLER,
			                new DialogErrorHandling(false),
			                DisplayMode.EDIT,slNum);*/
				/* Style conversionErrorStyle = new Style();
			        conversionErrorStyle.setAttributeValue(
			                CellStyleAttributes.BACKGROUND_COLOR, GUIHelper.COLOR_RED);
			        conversionErrorStyle.setAttributeValue(
			                CellStyleAttributes.FOREGROUND_COLOR, GUIHelper.COLOR_WHITE);

			        configReg.registerConfigAttribute(
			                EditConfigAttributes.CONVERSION_ERROR_STYLE,
			                conversionErrorStyle, DisplayMode.EDIT,
			                slNum);*/
			}
		});

		//	natTable.registerCommandHandler(new DeleteMultiRowCommandHandler<>(addingRow.getList()));
		natTable.configure();
		new NatTableContentTooltip(natTable, GridRegion.COLUMN_HEADER); /*{
			protected String getText(Event event) {
				return "Right-click for options.";
			}
		};*/
		natTable.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 3, 1));
		natTable.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		//natTable.refresh();
		btnForAddRow=createButton(composite1,"AddRow");
		btnForDeleteRow=createButton(composite1,"RemoveRow");
		btnForClear=createButton(composite1, "Clear");
		/*int count = dataProvider.getColumnCount();
		for (int j = 0; j <count; j++) {
			dataProvider.getColumnProperty(j);
			System.out.println(dataProvider.getColumnProperty(j)+" hgdd");
		}*/
	}
	private Button createButton(Composite composite, String string) {
		Button btn = new Button(composite, SWT.NONE);
		btn.setText(string);
		btn.addListener(SWT.MouseUp, this);
		btn.setData("Action", string);
		return btn;

	}
	public  IEditErrorHandler getEditErrorHandler(
			IConfigRegistry configRegistry,
			ConfigAttribute<IEditErrorHandler> configAttribute,
			String configLabels) {

		IEditErrorHandler errorHandler = configRegistry.getConfigAttribute(
				configAttribute, DisplayMode.EDIT, configLabels);
		if (errorHandler == null) {
			// set LoggingErrorHandling as default
			errorHandler = new LoggingErrorHandling();
		}
		return errorHandler;
	}
	private String[] murgeArrys(String[] dynamicDates, String[] prjSlNum) {
		String[] natHeaders = new String[dynamicDates.length+prjSlNum.length];
		int count = 0;

		for(int i = 0; i<prjSlNum.length; i++) { 
			natHeaders[i] = prjSlNum[i];
			count++;
		} 
		for(int j = 0;j<dynamicDates.length;j++) { 
			natHeaders[count++] = dynamicDates[j];
		} 
		for (int i = 0; i < natHeaders.length; i++) {
			System.out.println(natHeaders[i]);
		}
		return natHeaders;

	}
	@Override
	public void handleEvent(Event event) {
		String clickAction = (String)event.widget.getData("Action");
		if(clickAction.equalsIgnoreCase("AddRow"))
		{
			GetAndSetNatData ob=new GetAndSetNatData();
			ArrayList<String> list=new ArrayList<>();
			list.add("");
			list.add("");
			for(String val:listStrDateAndEndDateIntervals)
				list.add("0");
			ob.setColumnListValues(list);
			addingRow.addingRowDynamically(ob);
			natTable.refresh();
		}
		if(clickAction.equalsIgnoreCase("RemoveRow"))
		{
			int[] rowPosition= selectionLayer.getFullySelectedRowPositions();

			ArrayList<GetAndSetNatData> listRemoveMultipleRowsFromNattable=new ArrayList<>();
			for (int i = 0; i < rowPosition.length; i++) {

				int rowPosition1=selectionLayer.getRowIndexByPosition(rowPosition[i]);
				GetAndSetNatData deleteRow = addingRow.getRowObject(rowPosition1);
				listRemoveMultipleRowsFromNattable.add(deleteRow);
				Object obj = addingRow.getDataValue(1, rowPosition1);
				ArrayList<String> str1 = dataProvider.str;
				str1.remove(obj.toString());
				System.out.println(obj.toString()+" Object");

			}
			addingRow.removeMultipleRows(listRemoveMultipleRowsFromNattable);
			natTable.refresh();

		}
		if(clickAction.equalsIgnoreCase("Clear"))
		{
			dataProvider.str.clear();
			List<GetAndSetNatData> list = addingRow.list;
			for(GetAndSetNatData data:list) {
				for (int i = 0; i < addingRow.getRowCount(); i++) {
					for (int j = 0; j < addingRow.getColumnCount(); j++) {
						if(j==0 || j==1)
						{
							addingRow.setDataValue(j, i, " ");
						}
						else
						addingRow.setDataValue(j, i, "0");

					}
				}
			}
			natTable.refresh();

		}

	}
}
