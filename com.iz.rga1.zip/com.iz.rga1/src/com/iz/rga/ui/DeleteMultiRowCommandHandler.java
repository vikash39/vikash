package com.iz.rga.ui;

import java.util.Collection;
import java.util.List;

import org.eclipse.nebula.widgets.nattable.command.ILayerCommandHandler;
import org.eclipse.nebula.widgets.nattable.layer.ILayer;
import org.eclipse.nebula.widgets.nattable.layer.event.RowDeleteEvent;
import org.eclipse.nebula.widgets.nattable.selection.SelectionLayer;

public class DeleteMultiRowCommandHandler<T> implements ILayerCommandHandler<DeleteRows> {

	//public class DeleteMultiRowCommandHandler<T> implements ILayerCommandHandler<DeleteRows> {

	    private List<T> bodyData;
	   // private SelectionLayer layer;

	   /* public DeleteMultiRowCommandHandler(List<T> bodyData, SelectionLayer selectionLayer) {
	        this.bodyData = bodyData;
	        this.layer = selectionLayer;
	    }*/

	    public DeleteMultiRowCommandHandler(List<T> bodyData){
	        this.bodyData = bodyData;
	    }

	    @Override
	    public Class<DeleteRows> getCommandClass() {
	        return DeleteRows.class;
	    }


		@Override
		public boolean doCommand(ILayer targetLayer, DeleteRows command) {
			 if (command.convertToTargetLayer(targetLayer)) {
		            Collection<Integer>rowpos = command.getRowPositions();
		            //remove the element
		            for(Integer val : rowpos){
		                this.bodyData.remove(val.intValue());
		                targetLayer.fireLayerEvent(new RowDeleteEvent(targetLayer, val.intValue()));
		            }

		            return true;
		        }
			return false;
		}

	}


