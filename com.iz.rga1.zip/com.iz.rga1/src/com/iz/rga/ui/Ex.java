package com.iz.rga.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.formula.eval.ErrorEval;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Ex {

	public LinkedHashMap<String, ArrayList<String>> hmapFilterExcel;

	//private static boolean confirm;
	//private static HashMap<String, String> map_col_val=new HashMap<String, String>();
	public static void main(String[] args) throws IOException, ParseException {
		new Ex("1/7/2018","10/7/2018");
	}
	
	public Ex(String string, String string2) throws IOException, ParseException {
		
		int intStartcell=0;
		int intEndCell=0;
		String excelFilePath = "E://RGAExcel//InputLogTemplate.xlsx";
		FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
		SimpleDateFormat dFormat=new SimpleDateFormat("dd/MM/yyyy");
		Date date1=dFormat.parse(string);
		System.out.println(date1);
		Date date2=dFormat.parse(string2);
		System.out.println(date2);
		String sStartDate=dFormat.format(date1);
		String sEndDate=dFormat.format(date2);
		
		
		LinkedHashMap< String, ArrayList<String>> hmapFilterExcel=new LinkedHashMap<String, ArrayList<String>>();
		
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheetAt(0);
		Row row1 = firstSheet.getRow(0);
		ArrayList<String> columnList=new ArrayList<String>();
		for(int iCol=0;iCol<row1.getLastCellNum();iCol++){
			Cell cell = row1.getCell(iCol);
			switch (cell.getCellType()) {
				case Cell.CELL_TYPE_STRING:
					columnList.add(cell.getStringCellValue());
					break;
				case Cell.CELL_TYPE_BOOLEAN:
					columnList.add(cell.getBooleanCellValue()+"");
					break;
				case Cell.CELL_TYPE_NUMERIC:
					double dfdf = cell.getNumericCellValue();
					  if (HSSFDateUtil.isCellDateFormatted(cell)) {
						  Date exDate = cell.getDateCellValue();
					        System.out.println ("date--------->"+cell.getDateCellValue());
					        String strDate = dFormat.format(cell.getDateCellValue());  
					        
					        System.out.println("the exe ddate ------------->"+strDate);
					        
					        if(sStartDate.toString().equalsIgnoreCase(strDate.trim()))
					        	intStartcell=iCol;
					        else if(sEndDate.toString().equalsIgnoreCase(strDate.trim()))
					        	intEndCell=iCol;
					   }
					
					break;
				}	
		}
		System.out.println("startdateplace-------->"+intStartcell+" End date palce----------->"+intEndCell);
		System.out.println("ColumnList:\n" +columnList);
		System.out.println("start");
		 int intcount=0;
		 for (Row myRow : firstSheet) {
			 String strTarctor="";
			 ArrayList<String> aListdetails=new ArrayList<String>();
			 if(myRow.getRowNum() == 0)
				 continue;
				 Cell cellproject = myRow.getCell(0);
				 
				 Cell cellTractorNo = myRow.getCell(1);
				  strTarctor=cellTractorNo.getStringCellValue();
//				 System.out.print("Project------->"+cellproject.getStringCellValue());
				 aListdetails.add(cellproject.getStringCellValue());
//				 System.out.print(", Tractorno------->"+cellTractorNo.getStringCellValue());
				 for(int iCol=intStartcell;iCol<=intEndCell;iCol++){
					 
				String svalue=	 getCellValue(myRow.getCell(iCol));
			if(svalue.length()>0)	
				aListdetails.add(svalue);
					 
							
				 }
			 
			 intcount++;
			if(aListdetails.size()>0) 
			 hmapFilterExcel.put(strTarctor, aListdetails);
		 }
		

		inputStream.close();
         this.hmapFilterExcel=hmapFilterExcel;
		for(Map.Entry<String, ArrayList<String>> entry:hmapFilterExcel.entrySet()){
			
			ArrayList<String> aLsit=entry.getValue();
			System.out.println(entry.getKey()+"<-------->"+aLsit.toString());
		}
		
	}
	public static String getCellValue(Cell cell) {
		if (cell == null) 
		return "";
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BLANK:
		return "0";
		case Cell.CELL_TYPE_BOOLEAN:
		return "";// cell.getBooleanCellValue();
		case Cell.CELL_TYPE_STRING:
		return cell.getStringCellValue();
		case Cell.CELL_TYPE_NUMERIC:
		return isNumberOrDate(cell);
		case Cell.CELL_TYPE_FORMULA:
		String str_val = "";
		switch(cell.getCachedFormulaResultType()) {
		case Cell.CELL_TYPE_STRING:
		RichTextString str = cell.getRichStringCellValue();
		if(str != null && str.length() > 0) {
		str_val = str.toString();
		}
		break;
		case Cell.CELL_TYPE_NUMERIC:
		CellStyle style = cell.getCellStyle();
		if(style == null) {
		str_val = cell.getNumericCellValue()+"";
		} else {
		DataFormatter _formatter = new DataFormatter();
		str_val = _formatter.formatRawCellContents(cell.getNumericCellValue(),style.getDataFormat(),style.getDataFormatString());
		}
		break;
		case Cell.CELL_TYPE_BOOLEAN:
		str_val =cell.getBooleanCellValue()+"" ;
		break;
		case Cell.CELL_TYPE_ERROR:
		str_val = ErrorEval.getText(cell.getErrorCellValue());
		break;
		}
		return str_val;
		}
		return "";
		}
    
	 private static String isNumberOrDate(Cell cell) {
	        if (DateUtil.isCellDateFormatted(cell)) {
	            DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
	            return formatter.format(cell.getDateCellValue());
	        } else {
	            DataFormatter df = new DataFormatter();
	            return df.formatCellValue(cell);
	        }
	    }  
}
