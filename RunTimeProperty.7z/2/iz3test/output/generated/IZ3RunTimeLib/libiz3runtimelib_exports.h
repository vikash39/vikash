//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  IZ3RunTimeLib

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libIZ3RunTimeLib

#if !defined(LIBIZ3RUNTIMELIB) && !defined(IPLIB)
#   error IPLIB or LIBIZ3RUNTIMELIB is not defined
#endif

/* Handwritten code should use IZ3RUNTIMELIB_API, not IZ3RUNTIMELIBEXPORT */

#define IZ3RUNTIMELIB_API IZ3RUNTIMELIBEXPORT

#if IPLIB==libIZ3RunTimeLib || defined(LIBIZ3RUNTIMELIB)
#   if defined(__lint)
#       define IZ3RUNTIMELIBEXPORT       __export(IZ3RunTimeLib)
#       define IZ3RUNTIMELIBGLOBAL       extern __global(IZ3RunTimeLib)
#       define IZ3RUNTIMELIBPRIVATE      extern __private(IZ3RunTimeLib)
#   elif defined(_WIN32)
#       define IZ3RUNTIMELIBEXPORT       __declspec(dllexport)
#       define IZ3RUNTIMELIBGLOBAL       extern __declspec(dllexport)
#       define IZ3RUNTIMELIBPRIVATE      extern
#   else
#       define IZ3RUNTIMELIBEXPORT
#       define IZ3RUNTIMELIBGLOBAL       extern
#       define IZ3RUNTIMELIBPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define IZ3RUNTIMELIBEXPORT       __export(IZ3RunTimeLib)
#       define IZ3RUNTIMELIBGLOBAL       extern __global(IZ3RunTimeLib)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define IZ3RUNTIMELIBEXPORT      __declspec(dllimport)
#       define IZ3RUNTIMELIBGLOBAL       extern __declspec(dllimport)
#   else
#       define IZ3RUNTIMELIBEXPORT
#       define IZ3RUNTIMELIBGLOBAL       extern
#   endif
#endif
