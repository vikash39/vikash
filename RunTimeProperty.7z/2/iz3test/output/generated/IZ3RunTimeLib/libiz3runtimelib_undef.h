//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBIZ3RUNTIMELIB) && !defined(IPLIB)
#   error IPLIB or LIBIZ3RUNTIMELIB is not defined
#endif

#undef IZ3RUNTIMELIB_API
#undef IZ3RUNTIMELIBEXPORT
#undef IZ3RUNTIMELIBGLOBAL
#undef IZ3RUNTIMELIBPRIVATE
