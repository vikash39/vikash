//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBIZ3TESTDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBIZ3TESTDISPATCH is not defined
#endif

#undef IZ3TESTDISPATCH_API
#undef IZ3TESTDISPATCHEXPORT
#undef IZ3TESTDISPATCHGLOBAL
#undef IZ3TESTDISPATCHPRIVATE
