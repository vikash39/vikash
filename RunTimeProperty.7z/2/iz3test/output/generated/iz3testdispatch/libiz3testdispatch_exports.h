//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  iz3testdispatch

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libiz3testdispatch

#if !defined(LIBIZ3TESTDISPATCH) && !defined(IPLIB)
#   error IPLIB or LIBIZ3TESTDISPATCH is not defined
#endif

/* Handwritten code should use IZ3TESTDISPATCH_API, not IZ3TESTDISPATCHEXPORT */

#define IZ3TESTDISPATCH_API IZ3TESTDISPATCHEXPORT

#if IPLIB==libiz3testdispatch || defined(LIBIZ3TESTDISPATCH)
#   if defined(__lint)
#       define IZ3TESTDISPATCHEXPORT       __export(iz3testdispatch)
#       define IZ3TESTDISPATCHGLOBAL       extern __global(iz3testdispatch)
#       define IZ3TESTDISPATCHPRIVATE      extern __private(iz3testdispatch)
#   elif defined(_WIN32)
#       define IZ3TESTDISPATCHEXPORT       __declspec(dllexport)
#       define IZ3TESTDISPATCHGLOBAL       extern __declspec(dllexport)
#       define IZ3TESTDISPATCHPRIVATE      extern
#   else
#       define IZ3TESTDISPATCHEXPORT
#       define IZ3TESTDISPATCHGLOBAL       extern
#       define IZ3TESTDISPATCHPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define IZ3TESTDISPATCHEXPORT       __export(iz3testdispatch)
#       define IZ3TESTDISPATCHGLOBAL       extern __global(iz3testdispatch)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define IZ3TESTDISPATCHEXPORT      __declspec(dllimport)
#       define IZ3TESTDISPATCHGLOBAL       extern __declspec(dllimport)
#   else
#       define IZ3TESTDISPATCHEXPORT
#       define IZ3TESTDISPATCHGLOBAL       extern
#   endif
#endif
