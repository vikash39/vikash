//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object IZ3ProRuntimeRevisionImpl
//

#include <IZ3RunTimeLib/IZ3ProRuntimeRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include<tccore\aom_prop.h>
#include<iostream>

using namespace iz3test;

//----------------------------------------------------------------------------------
// IZ3ProRuntimeRevisionImpl::IZ3ProRuntimeRevisionImpl(IZ3ProRuntimeRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
IZ3ProRuntimeRevisionImpl::IZ3ProRuntimeRevisionImpl( IZ3ProRuntimeRevision& busObj )
   : IZ3ProRuntimeRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// IZ3ProRuntimeRevisionImpl::~IZ3ProRuntimeRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
IZ3ProRuntimeRevisionImpl::~IZ3ProRuntimeRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// IZ3ProRuntimeRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int IZ3ProRuntimeRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = IZ3ProRuntimeRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


///
/// Getter for an Integer Property
/// @param value - Parameter Value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  IZ3ProRuntimeRevisionImpl::getIz3ValueCBase( int & value, bool &isNull ) const
{
    //int ifail = ITK_ok;

    // Your Implementation


    int ifail = ITK_ok;

     isNull = false;
	 int valueA = 0;
     int valueB = 0;

   tag_t tproTag = NULLTAG;

	//std::cout<<"getA2NumberCBase = "<<value<<std::endl;

   TC_write_syslog("Loaded successfully my dll");

   std::cout<<"Loaded successfully my dll" <<std::endl;

   tproTag = this->getIZ3ProRuntimeRevision()->getTag();

   AOM_ask_value_int(tproTag, "iz3ValueA",&valueA );

    std::cout<<"valueA = " <<valueA<<std::endl;

   AOM_ask_value_int(tproTag, "iz3ValueB",&valueB );

    std::cout<<"valueB = " <<valueB<<std::endl;

   value= valueA+valueB;

   std::cout<<"valueC = " <<value<<std::endl;

   AOM_set_value_int(tproTag,"iz3ValueC",value);

	//AOM_set_value_int(tproTag,"a2NumberC",value);

	std::cout<<"Added Values  ValueA + ValueB  = "<<value<<std::endl;




    // Your Implementation

    return ifail;




  //  return ifail;
}

