//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object IZ3ProRuntimeRevisionImpl
//

#ifndef IZ3TEST__IZ3PRORUNTIMEREVISIONIMPL_HXX
#define IZ3TEST__IZ3PRORUNTIMEREVISIONIMPL_HXX

#include <IZ3RunTimeLib/IZ3ProRuntimeRevisionGenImpl.hxx>

#include <IZ3RunTimeLib/libiz3runtimelib_exports.h>


namespace iz3test
{
    class IZ3ProRuntimeRevisionImpl; 
    class IZ3ProRuntimeRevisionDelegate;
}

class  IZ3RUNTIMELIB_API iz3test::IZ3ProRuntimeRevisionImpl
    : public iz3test::IZ3ProRuntimeRevisionGenImpl
{
public:

    ///
    /// Getter for an Integer Property
    /// @param value - Parameter Value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getIz3ValueCBase( int &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a IZ3ProRuntimeRevision
    explicit IZ3ProRuntimeRevisionImpl( IZ3ProRuntimeRevision& busObj );

    ///
    /// Destructor
    virtual ~IZ3ProRuntimeRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    IZ3ProRuntimeRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    IZ3ProRuntimeRevisionImpl( const IZ3ProRuntimeRevisionImpl& );

    ///
    /// Copy constructor
    IZ3ProRuntimeRevisionImpl& operator=( const IZ3ProRuntimeRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class iz3test::IZ3ProRuntimeRevisionDelegate;

};

#include <IZ3RunTimeLib/libiz3runtimelib_undef.h>
#endif // IZ3TEST__IZ3PRORUNTIMEREVISIONIMPL_HXX
