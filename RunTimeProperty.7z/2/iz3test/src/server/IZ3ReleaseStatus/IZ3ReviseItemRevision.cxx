//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension IZ3ReviseItemRevision
 *
 */
#include <IZ3ReleaseStatus/IZ3ReviseItemRevision.hxx>

int IZ3ReviseItemRevision( METHOD_message_t * /*msg*/, va_list /*args*/ )
{
 
 return 0;

}