//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension IZ3ReviseItemRevision
 *
 */
 
#ifndef IZ3REVISEITEMREVISION_HXX
#define IZ3REVISEITEMREVISION_HXX
#include <tccore/method.h>
#include <IZ3ReleaseStatus/libiz3releasestatus_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern IZ3RELEASESTATUS_API int IZ3ReviseItemRevision(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <IZ3ReleaseStatus/libiz3releasestatus_undef.h>
                
#endif  // IZ3REVISEITEMREVISION_HXX
