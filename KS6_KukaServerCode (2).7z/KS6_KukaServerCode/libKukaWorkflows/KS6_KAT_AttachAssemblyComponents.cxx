#include "KS6_KAT_AttachAssemblyComponents.h"

int katAttachAssemblyComponents(EPM_action_message_t msg)
{
	ResultStatus rStatus;
	try
	{
		//Fetch the arguments and add them to a map
		map<string, string> mArguments;

		rStatus = fetchArguments(msg, mArguments);

		//Get the root task tag
		tag_t tRootTask = NULLTAG;
		rStatus = EPM_ask_root_task(msg.task, &tRootTask);

		//Ask the attachments
		int iTargetCount = 0;
		tag_t* tpTargets = NULL;
		char* cObjectType = NULL; 
		rStatus = EPM_ask_attachments(tRootTask, EPM_target_attachment, &iTargetCount, &tpTargets);

		//Loop through the targets to process them one by one
		for (size_t i = 0; i < iTargetCount; i++)
		{
			rStatus = WSOM_ask_object_type2(tpTargets[i],&cObjectType);

			//here check the object type 
			if(tc_strcmp(cObjectType,"ItemRevision")==0) 
			{
				//Check if the target object is a valid target or not
				bool bIsValid = false;

				if(mArguments.size() !=0)
					bIsValid = validateTarget(tpTargets[i], mArguments, bIsValid);

				//Target object will be processed only if its valid else it will be skipped
				if (bIsValid)
				{
					rStatus = getAttachedComponentsInTarget(tRootTask, tpTargets[i], mArguments);
				}
				else if(mArguments.size() == 0)
				{
					rStatus = getAttachedComponentsInTarget(tRootTask, tpTargets[i], mArguments);
				}
				else if(mArguments.find(REVISION_RULE) != mArguments.end() && mArguments.size() == 1)
				{
					rStatus = getAttachedComponentsInTarget(tRootTask, tpTargets[i], mArguments);
				}

				else if (mArguments.find(CHILD_PROPERTY) != mArguments.end() && mArguments.size() == 2)
				{
					rStatus = getAttachedComponentsInTarget(tRootTask, tpTargets[i], mArguments);
				}
			}
		}
	}
	catch (const IFail& ex)
	{
		TC_write_syslog("Error in KAT-attach-assembly-components handler. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return ITK_ok;
}

int fetchArguments(EPM_action_message_t msg, map<string, string> &mArguments)
{
	int iStatus = ITK_ok;

	int iArgCount = 0;

	char** cArgNames = NULL;
	char** cArgValues = NULL;

	iStatus = EPM_args_process_args(msg.task,msg.arguments,&iArgCount,&cArgNames,&cArgValues);
	if(iArgCount != 0)
	{
		for(int iCnt = 0; iCnt<iArgCount; iCnt++)
		{
			string sValue = cArgValues[iCnt];
			string sTypeArg = cArgNames[iCnt];

			transform(sTypeArg.begin(), sTypeArg.end(), sTypeArg.begin(), ::tolower);		

			mArguments.insert(pair<string, string>(sTypeArg, sValue));
		}
	}

	return iStatus;
}

bool validateTarget(tag_t tTarget, map<string, string> &mArguments, bool &bIsValid)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try
	{
		//If parent property and parent value, both are provided, only then we will check that on target object else
		//by default, target object will be valid
		if (mArguments.find(PARENT_PROPERTY) != mArguments.end() && mArguments.find(PARENT_VALUE) != mArguments.end())
		{
			string sProperty = mArguments.find(PARENT_PROPERTY)->second;

			//First check if the provided property exists on the target object
			bool bExists = false;
			bExists = doesPropertyExist(tTarget, sProperty, bExists);

			if (bExists)
			{
				//If the property exists, only then get the value of the property from target object
				char* cpValue = NULL;
				rStatus = AOM_UIF_ask_value(tTarget, sProperty.c_str(), &cpValue);

				string sPropertyValue = mArguments.find(PARENT_VALUE)->second;


				//Compare if the property value on target object is same as the one passed as argument
				//If not then target object will be treated as invalid object to process
				if (tc_strcasecmp(sPropertyValue.c_str(), cpValue) == 0)
				{
					bIsValid = true;
				}
			}
			else
			{
				//If the provided property does not exist on target object then target object will be treated as invalid object to process
				bIsValid = false;
			}	
		}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in validateTarget function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return bIsValid;
}


bool doesPropertyExist(tag_t tTarget, string sProperty, bool &bExists)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;

	try
	{
		//Get the class of target object
		//bExists = false;
		tag_t tClassID = NULLTAG;
		rStatus = POM_class_of_instance(tTarget, &tClassID);

		//Get the class ID of class of target object
		char* cpClassName = NULL;
		rStatus = POM_name_of_class(tClassID, &cpClassName);

		//Check if the property exist on class of the target object
		rStatus = POM_attr_exists(sProperty.c_str(), cpClassName, &bExists);
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in doesPropertyExist function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	//return iStatus;
	return bExists;
} 

int getValidChildComponents(tag_t tTarget, map<string, string> &mArguments, counted_tag_list_t* sValidChildren)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try
	{
		//Create a BOM window
		tag_t tWindow = NULLTAG;
		rStatus = BOM_create_window(&tWindow);

		//Check of the revision rule argument is provided
		//If yes, only then find the revision rule
		if (mArguments.find(REVISION_RULE) != mArguments.end())
		{
			tag_t tRevRule = NULLTAG;
			rStatus = CFM_find(mArguments.find(REVISION_RULE)->second.c_str(), &tRevRule);

			//If revision rule is valid and found, only then set it on BOM window
			if( tRevRule != NULLTAG )
			{
				rStatus = BOM_set_window_config_rule(tWindow, tRevRule);
			}
		}

		//Set the current target as top BOM line
		tag_t tBOMTopLine = NULLTAG;
		rStatus = BOM_set_window_top_line(tWindow, NULLTAG, tTarget, NULLTAG, &tBOMTopLine);

		//Get the child lines of the BOM
		int iNoOfChildren = 0;
		tag_t* tpChildren = NULL;
		rStatus = BOM_line_ask_child_lines(tBOMTopLine, &iNoOfChildren, &tpChildren);

		bool bValidateChild = false;
		string sChildProperty = "";
		string sChildPropertyValue = "";

		//If child property & child value, both are provided then child lines need to be validated
		if (mArguments.find(CHILD_PROPERTY) != mArguments.end() && mArguments.find(CHILD_VALUE) != mArguments.end())
		{
			bValidateChild = true;
			sChildProperty = mArguments.find(CHILD_PROPERTY)->second;
			sChildPropertyValue = mArguments.find(CHILD_VALUE)->second;
		}

		//Loop through all the child lines
		for (size_t i = 0; i < iNoOfChildren; i++)
		{
			//Get the child object from the child line
			tag_t tRevision = NULLTAG;
			rStatus = AOM_ask_value_tag(tpChildren[i], "bl_revision", &tRevision);

			//If child objects are to be validated then check the child property
			if( bValidateChild )
			{
				//Check if the child property passed as argument, exists on the child object
				bool bExists = false;
				bExists = doesPropertyExist(tRevision, sChildProperty, bExists);

				//If the child property exists on child object only then get its value and validate
				//If child property doesnt exist then child object is treated as invalid object to add to target attachment
				if (bExists)
				{
					char* cpValue = NULL;
					rStatus = AOM_UIF_ask_value(tRevision, sChildProperty.c_str(), &cpValue);

					//Compare the value of child property on child object with the value passed
					//If they match, only then child object would be treated as valid object else will be skipped
					if (tc_strcasecmp(sChildPropertyValue.c_str(), cpValue) == 0)
					{
						rStatus = EPM__add_to_tag_list(tRevision, sValidChildren);
					}
				}
			}
			else
			{
				//If child objects are not to be validated then all the child objects will be treated as valid to add to target attachment
				rStatus = EPM__add_to_tag_list(tRevision, sValidChildren);
			}
		}

	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		TC_write_syslog("Error in getValidChildComponents function. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return iStatus;
}

int getAttachedComponentsInTarget(tag_t tRootTask, tag_t tpTargets, map<string, string> &mArguments)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try {
		//Get the valid first level child lines of the target object
		counted_tag_list_t  sValidChildren = {0};
		int initial_tag_list_size = 16;  // Reference PR-8968371
		sValidChildren.list = (tag_t *)MEM_alloc(initial_tag_list_size * (sizeof(tag_t)));

		rStatus = getValidChildComponents(tpTargets, mArguments, &sValidChildren);

		if(sValidChildren.count !=0)
		{
			int *piAttachTypes = NULL;
			piAttachTypes = (int *) MEM_alloc (sValidChildren.count * sizeof(int));
			for (int ii = 0; ii < sValidChildren.count; ii++)
			{
				piAttachTypes[ii] = EPM_target_attachment;
			}

			rStatus = AOM_refresh(tRootTask, TRUE); 

			rStatus = EPM_add_attachments(tRootTask, sValidChildren.count, sValidChildren.list, piAttachTypes);

			if(piAttachTypes)
				MEM_free(piAttachTypes);  

			rStatus = AOM_save(tRootTask);
		}
	}
	catch (const IFail& ex)
	{
		TC_write_syslog("Error in KAT-attach-assembly-components handler. Error code %d, Error String: %s, File name: %s", ex.ifail(), ex.getMessage().c_str(), __FILE__);
	}
	return iStatus;
}