#pragma once
//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
* @file
*
*   This file contains the declaration for the Extension KATHandlers
*
*/

#ifndef KAT_move_attached_objects_HXX
#define KAT_move_attached_objects_HXX

#define KAT_MOVE_ATTACHED_OBJECTS				"KAT-move-attached-objects"
#define ALLOWED_INPUT_TYPE						"ItemRevision"
#define FROM_ATTACH_ARG							"from_attach"
#define TO_ATTACH_ARG							"to_attach"
#define PROPERTY_ARG							"property"
#define VALUE_ARG								"value"
#define INCLUDE_TYPE_ARG						"include_type"
#define EXCLUDE_TYPE_ARG						"exclude_type"
#define COPY_ARG								"copy"
#define COPY_DEFAULT_VALUE						"false"
#define TARGET									"target"
#define REFERENCE								"reference"
#define PROBLEM_ITEM							"problem_item"
#define SOLUTION_ITEM							"solution_item"
#define IMPACTED_ITEM							"impacted_item"
#define SEPARATOR_PREFERENCE_NAME				"EPM_ARG_target_user_group_list_separator"
#define INCLUDE_OR_EXCLUDE_TYPE_PRESENT			"FALSE"


#include <tccore\method.h>
#include <string>
#include <ict\ict_userservice.h>
#include <tccore\custom.h>
#include <epm\epm.h>
#include <tccore\grm.h>
#include <tc\preferences.h>
#include <tccore\item.h>
#include <tccore\tctype.h>
#include <tccore\aom.h>
#include <tccore\aom_prop.h>
#include <tccore\workspaceobject.h>
#include <base_utils\ScopedSmPtr.hxx>
#include <base_utils\TcResultStatus.hxx>
#include <base_utils\IFail.hxx>
#include <fclasses\AcquireLock.hxx>
#include <base_utils\Mem.h>
#include <tccore\project.h>
#include <tc\tc_arguments.h>
#include <vector>
#include <map>
#include <algorithm>
#include <sstream>
#include "libKukaWorkflows.h";


using namespace std;
using namespace Teamcenter;

#ifdef __cplusplus
extern "C" {
#endif

	// Action Handler.
	int KAT_move_attached_objects(EPM_action_message_t msg);
	int processArguments(EPM_action_message_t msg, map<string, string> &mArguments,
		std::vector<std::string> &vInputTypes);
	void getListFromString(std::string input, std::vector<std::string>& output);
	std::string getDelimiter();
	int getAttachmentType(const char* pcName);
	int processAttachedObjects(map<string, string> mArguments, tag_t tRootTask,
		std::vector<std::string> vInputTypes);
	int doesPropertyExist(tag_t tTarget, string sProperty, bool &bExists);
	int filterObjectsBasedOnProperty(map<string, string> mArguments, std::vector<tag_t>& vObjects);
	int validateObject(tag_t tTarget, map<string, string> mArguments, bool &bIsValid);
	int attachObjects(map<string, string> mArguments, tag_t tRootTask, std::vector<tag_t>& vWorkflowTargets,
		std::vector<tag_t>& vAttachments, std::vector<std::string> vInputTypes);
	int filterObjectsBasedOnType(std::vector<std::string>& vPassedTypes,
		std::vector<tag_t>& vObjects);

#ifdef __cplusplus
}
#endif

#endif 


#define ERROR_CALL(x) { \
int stat; \
char *err_string = NULL; \
if( (stat = (x)) != ITK_ok) \
{ \
EMH_ask_error_text (stat, &err_string); \
if(err_string != NULL) {\
printf ("ERROR: %d ERROR MSG: %s \n", stat, err_string); \
printf ("Function: %s FILE: %s LINE: %d \n",#x, __FILE__, __LINE__); \
TC_write_syslog("KAT Handler Error [%d]: %s\n\t(FILE: %s, LINE:%d)\n", stat, err_string, __FILE__, __LINE__);\
MEM_free (err_string);\
err_string=NULL;\
}\
} \
}