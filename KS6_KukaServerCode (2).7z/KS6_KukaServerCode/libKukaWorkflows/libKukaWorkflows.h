# ifndef LIB_KUKA_WORKFLOWS_H
# define LIB_KUKA_WORKFLOWS_H

////Standard include files
//#include <iostream>
//
////Teamcenter header files
//#include <epm/epm.h>
//#include <tc/tc.h>
//#include <tccore/custom.h>



/*************************************************
* System Header Files
**************************************************/
#include <algorithm>
#include <winsock2.h>
#include <Windows.h>
#include <ctype.h>
#include <fstream>
#include <iomanip>
#include <locale>
#include <map>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <sys/stat.h> 
#include <sys/timeb.h>
#include <sys/types.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <string>
#include <sstream>
#include <direct.h>
#include <set>
#include <unordered_map>
#include <iterator>

/*************************************************
* Teamcenter Header Files
**************************************************/
#include <ae/ae.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <ae/shell_util.h>
#include <ae/vm_errors.h>
#include <base_utils/TcResultStatus.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <common/emh_const.h>
#include <constants/constants.h>
#include <ctype.h>
#include <errno.h>
#include <epm/cr.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/releasestatus.h>
#include <epm/signoff.h>
#include <fclasses/tc_date.h>
#include <itk/bmf.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <me/me.h>
#include <metaframework/BusinessObjectRef.hxx>
#include <metaframework/BusinessObjectRegistry.hxx>
#include <cxpom/attributeaccessor.hxx>
#include <nls\nls.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <property/propdesc.h>
#include <property/prop_errors.h>
#include <ps/ps.h>
#include <ps/ps_tokens.h>
#include <ps/vrule.h>
#include <qry/crf.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <sa/am.h>
#include <sa/user.h>
#include <sa/tcfile.h>
#include <sa/tcvolume.h>
#include <schmgt/schmgt_bridge_itk.h>
#include <schmgt/schmgt_itk.h>
#include <sub_mgr/standardtceventtypes.h>
#include <sub_mgr/subscription.h>
#include <sub_mgr/tceventtype.h>
#include <tc/emh.h>
#include <tc\emh_errors.h>
#include <tc/folder.h>
#include <tc/iman_arguments.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <textsrv/textserver.h>	
#include <tccore\aom.h>
#include <tccore\aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/item.h>
#include <tccore/item_msg.h>
#include <tccore/license.h>
#include <tccore/method.h>
#include <tccore/project.h>
#include <tccore/project_errors.h>
#include <tccore/tc_msg.h>	
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h> 
#include <tccoreext/gde.h>
#include <ug_va_copy.h>
#include <cxpom/attributeaccessor.hxx>
#include <fclasses\AcquireLock.hxx>
#include "libKukaWorkflowExports.h"

#ifdef __cplusplus
extern "C" {
#endif

	KUKA_WORKFLOW_EXPORT int libKukaWorkflows_register_callbacks();

	KUKA_WORKFLOW_EXPORT int kukaRegisterHandlers(int* decision, va_list args);

#ifdef __cplusplus
}
#endif

#endif //LIB_KUKA_WORKFLOWS_H