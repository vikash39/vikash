#include "KAT_move_attached_objects.h"

int katMoveAttachedObjects(EPM_action_message_t msg)
{
	int iFail = ITK_ok;
	std::vector<std::string> sAttachType = { PROBLEM_ITEM, SOLUTION_ITEM, IMPACTED_ITEM };
	ResultStatus rStatus(0);
	std::vector<std::string> vInputTypes;
	tag_t tTask;
	tag_t tRootTask;
	map<string, string> mArguments;

	TC_write_syslog("KAT_move_attached_objects: INFO: Processing attachments.\n");

	try {
		iFail = processArguments(msg, mArguments, vInputTypes);

		if (iFail == ITK_ok)
		{
			// take the root task
			tTask = msg.task;
			rStatus = EPM_ask_root_task(tTask, &tRootTask);

			rStatus = processAttachedObjects(mArguments, tRootTask, vInputTypes);
		}


	}
	catch (IFail &ex) {
		ERROR_CALL(ex.ifail());
	}

	TC_write_syslog("KAT_move_attached_objects: INFO: End\n");

	return iFail;
}


int processArguments(EPM_action_message_t msg, map<string, string> &mArguments, 
	std::vector<std::string> &vInputTypes)
{
	int iStatus = ITK_ok;
	
	char* cpArgValue = NULL;
	char* cpTypeArg = NULL;
	char* cpValue = NULL;
	

	//Loop through all the arguments and push them into a map
	//Since all the arguments are optional, if any one of them is not provided then it will not be added to map
	while ((cpArgValue = TC_next_argument(msg.arguments)) != NULL)
	{
		iStatus = ITK_ask_argument_named_value(cpArgValue, &cpTypeArg, &cpValue);
		if (cpValue != NULL)
		{
			string sTypeArg(cpTypeArg);
			transform(sTypeArg.begin(), sTypeArg.end(), sTypeArg.begin(), ::tolower);

			string sValue(cpValue);

			mArguments.insert(pair<string, string>(sTypeArg, sValue));
		}
	}

	//check mandatory
	if (mArguments.find(FROM_ATTACH_ARG) != mArguments.end() && mArguments.find(TO_ATTACH_ARG) != mArguments.end()
		&& mArguments.find(PROPERTY_ARG) != mArguments.end() && mArguments.find(VALUE_ARG) != mArguments.end())
	{
		//from_attach & to_attach should not be same
		if (tc_strcasecmp(mArguments.find(FROM_ATTACH_ARG)->second.c_str(),
			mArguments.find(TO_ATTACH_ARG)->second.c_str()) != 0)
		{
			//only one of include_type and exclude_type should be passed
			if (mArguments.find(INCLUDE_TYPE_ARG) == mArguments.end() || mArguments.find(EXCLUDE_TYPE_ARG) == mArguments.end())
			{
				//assign defaults
				if (mArguments.find(COPY_ARG) == mArguments.end()) {
					mArguments.at(COPY_ARG) = COPY_DEFAULT_VALUE;
				}

				mArguments.insert(pair<string, string>(INCLUDE_OR_EXCLUDE_TYPE_PRESENT, "FALSE"));
				if (mArguments.find(INCLUDE_TYPE_ARG) != mArguments.end())
				{
					getListFromString(mArguments.find(INCLUDE_TYPE_ARG)->second.c_str(), vInputTypes);
					mArguments.insert(pair<string, string>(INCLUDE_OR_EXCLUDE_TYPE_PRESENT, "TRUE"));
				}
				else if (mArguments.find(EXCLUDE_TYPE_ARG) != mArguments.end())
				{
					getListFromString(mArguments.find(EXCLUDE_TYPE_ARG)->second.c_str(), vInputTypes);
					mArguments.insert(pair<string, string>(INCLUDE_OR_EXCLUDE_TYPE_PRESENT, "TRUE"));
				}
			}
			else
			{
				EMH_store_error_s2(EMH_severity_error, EPM_double_argument_value, INCLUDE_TYPE_ARG, EXCLUDE_TYPE_ARG);
				TC_write_syslog("KAT_move_attached_objects: ERROR: Only one of the arguments %s and %s should be present.\n",
					INCLUDE_TYPE_ARG, EXCLUDE_TYPE_ARG);
				iStatus = 33119;
			}
		}
		else
		{
			TC_write_syslog("KAT_move_attached_objects: ERROR: Value of arguments %s and %s must not be same.\n", FROM_ATTACH_ARG, TO_ATTACH_ARG);
			iStatus = 33020;
		}
	}
	else
	{
		EMH_store_error(EMH_severity_error, EPM_missing_req_arg);
		TC_write_syslog("KAT_move_attached_objects: ERROR: All the mandatory arguments are not present.\n");
		//status = 33032;
	}
		
	return iStatus;
}

void getListFromString(std::string input, std::vector<std::string>& vResult)
{
	size_t pos = 0;
	std::string sToken;
	std::string delimiter = getDelimiter();

	std::stringstream ss(input); // Turn the string into a stream.
	std::string tok;

	while (getline(ss, tok, delimiter[0]))
	{
		vResult.push_back(tok);
	}

	/*
	std::vector<std::string> temp;
	do {
		pos = input.find(delimiter);
		sToken = input.substr(0, pos);
		temp.push_back(sToken);
		input.erase(0, pos + delimiter.length());
	} while (pos != std::string::npos);

	output = temp;*/
}

std::string getDelimiter()
{
	std::string delimiter = ",";
	scoped_smptr<char> cPrefValue;
	PREF_ask_char_value(SEPARATOR_PREFERENCE_NAME, 0, &cPrefValue);

	if (tc_strcasecmp(cPrefValue.getString(), ""))
	{
		delimiter = cPrefValue.getString();
	}

	return delimiter;
}

void getRelationTagFromName(const char* pcAttachType, tag_t* tRelationType)
{
	int iFail = ITK_ok;
	if (tc_strcasecmp(pcAttachType, PROBLEM_ITEM) == 0)
	{
		iFail = GRM_find_relation_type("CMHasProblemItem", tRelationType);
	}
	if (tc_strcasecmp(pcAttachType, SOLUTION_ITEM) == 0)
	{
		iFail = GRM_find_relation_type("CMHasSolutionItem", tRelationType);
	}
	if (tc_strcasecmp(pcAttachType, IMPACTED_ITEM) == 0)
	{
		iFail = GRM_find_relation_type("CMHasImpactedItem", tRelationType);
	}
}

int processAttachedObjects(map<string, string> mArguments, tag_t tRootTask, 
	std::vector<std::string> vInputTypes)
{
	ResultStatus rStatus(0);
	int iFail = ITK_ok;
	scoped_smptr<tag_t> tObjectsToMove;
	int iAttachments;
	scoped_smptr<tag_t> tAttachments;
	int iWorkflowTargets;
	vector<tag_t> vWorkflowTargets;

	try
	{
		const char* cpFromAttach = mArguments.find(FROM_ATTACH_ARG)->second.c_str();
		//target attachment will be required for reading or creating relation
		rStatus = EPM_ask_attachments(tRootTask, getAttachmentType(TARGET), &iAttachments, &tAttachments);
		iWorkflowTargets = iAttachments;
		std::vector<tag_t> vWorkflowTargets(tAttachments.get(), tAttachments.get() + iAttachments);


		if (tc_strcasecmp(cpFromAttach, REFERENCE) == 0)
		{
			rStatus = EPM_ask_attachments(tRootTask, getAttachmentType(cpFromAttach), &iAttachments, &tAttachments);
		}
		
		if ((tc_strcasecmp(cpFromAttach, TARGET) == 0) || (tc_strcasecmp(cpFromAttach, REFERENCE) == 0))
		{
			std::vector<tag_t> vAttachments(tAttachments.get(), tAttachments.get() + iAttachments);
			
			if (vAttachments.size() > 0)
			{
				
				rStatus = attachObjects(mArguments, tRootTask, vWorkflowTargets, vAttachments, vInputTypes);
				//in case of move objects
				if ((iFail == ITK_ok) && 
					(vAttachments.size() > 0) && tc_strcasecmp(mArguments.find(COPY_ARG)->second.c_str(), "false") == 0){
					int *piAttachTypes = NULL;
					piAttachTypes = (int *)MEM_alloc(vAttachments.size() * sizeof(int));
					for (int ii = 0; ii < vAttachments.size(); ii++)
					{
						piAttachTypes[ii] = getAttachmentType(mArguments.find(FROM_ATTACH_ARG)->second.c_str());
					}
					rStatus = EPM_remove_attachments_from_att_type(tRootTask, vAttachments.size(), 
						&vAttachments[0], piAttachTypes);	
				}
			}
			
		}
		else {
			for (int i = 0; i < iAttachments; i++)
			{
				tag_t tFromRelationType;
				int iSecondaryCount;
				//scoped_smptr<tag_t> tObjectsToMove;
				scoped_smptr<GRM_relation_t> tSecondaryData;
				getRelationTagFromName(cpFromAttach, &tFromRelationType);

				char* name;
				AOM_ask_value_string(tAttachments[i], "object_name", &name);

				rStatus = GRM_list_secondary_objects(tAttachments[i], tFromRelationType, &iSecondaryCount, &tSecondaryData);

				std::vector<tag_t> vObjectsToMove;
				std::vector<tag_t> vRelationsToDelete;
				for (int j = 0; j < iSecondaryCount; j++)
				{
					vObjectsToMove.push_back(tSecondaryData[j].secondary);
				}
				if (vObjectsToMove.size() > 0)
				{

					rStatus = attachObjects(mArguments, tRootTask, vWorkflowTargets, vObjectsToMove, vInputTypes);
					if (tc_strcasecmp(mArguments.find(COPY_ARG)->second.c_str(), "false") == 0)
					{
						for (int jj = 0; jj < iSecondaryCount; jj++)
						{
							if (std::find(vObjectsToMove.begin(), vObjectsToMove.end(), tSecondaryData[jj].secondary) != vObjectsToMove.end())
							{
								rStatus = GRM_delete_relation(tSecondaryData[jj].the_relation);
							}
						}
					}

				}
			}
		}
	}
	catch (IFail & ex)
	{
		iFail = ex.ifail();
		ERROR_CALL(ex.ifail());
	}

	return iFail;
	
}

int getAttachmentType(const char* pcName)
{	
	if (tc_strcasecmp(pcName, REFERENCE) == 0)
		return EPM_reference_attachment;
	else
		return EPM_target_attachment;
}

int filterObjectsBasedOnType( std::vector<std::string>& vPassedTypes, 
	std::vector<tag_t>& vObjects)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	std::vector<tag_t> vObjectsTemp;
	try {
		std::vector<tag_t> vInputObjectTypes;
		for (int iType = 0; iType < vPassedTypes.size(); iType++)
		{
			tag_t tInputObjectType = NULLTAG;
			rStatus = TCTYPE_find_type(vPassedTypes[iType].c_str(), NULL, &tInputObjectType);
			vInputObjectTypes.push_back(tInputObjectType);
		}

		for (int i = 0; i < vObjects.size(); i++)
		{
			char* cpObjectType = NULL;
			rStatus = WSOM_ask_object_type2(vObjects[i], &cpObjectType);

			tag_t tObjectType = NULLTAG;
			rStatus = TCTYPE_find_type(cpObjectType, NULL, &tObjectType);

			bool bValidType = false;
			for (int iType = 0; iType < vPassedTypes.size(); iType++)
			{
				rStatus = TCTYPE_is_type_of(tObjectType, vInputObjectTypes[iType], &bValidType); 
				if (bValidType)
				{
					vObjectsTemp.push_back(vObjects[i]);
					break;
				}
			}
		}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		ERROR_CALL(iStatus);
	}

	vObjects = vObjectsTemp;
	return iStatus;
}
int filterObjectsBasedOnProperty(map<string, string> mArguments, std::vector<tag_t>& vObjects)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	std::vector<tag_t> vObjectsTemp;
	try {
		for (int i = 0; i < vObjects.size(); i++)
		{
			bool bIsValid;
			rStatus = validateObject(vObjects[i], mArguments, bIsValid);
			if (bIsValid)
			{
				vObjectsTemp.push_back(vObjects[i]);
			}
		}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		ERROR_CALL(iStatus);
	}
	vObjects = vObjectsTemp;
	return iStatus;
}

int validateObject(tag_t tTarget, map<string, string> mArguments, bool &bIsValid)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try
	{
		bIsValid = false;
		//If property and value are passed, we will check on attachment object
		//if not present, that object will not be processed further
		//since property and value are mandatory arg, null check is not required.
		
			string sProperty = mArguments.find(PROPERTY_ARG)->second;

			//First check if the provided property exists on the target object
			bool bExists = false;
			rStatus = doesPropertyExist(tTarget, sProperty, bExists);

			if (bExists)
			{
				//If the property exists, only then get the value of the property from target object
				char* cpValue = NULL;
				rStatus = AOM_UIF_ask_value(tTarget, sProperty.c_str(), &cpValue);

				string sPropertyValue = mArguments.find(VALUE_ARG)->second;

				//Compare if the property value on target object is same as the one passed as argument
				//If not then target object will be treated as invalid object to process
				if (tc_strcasecmp(sPropertyValue.c_str(), cpValue) == 0)
				{
					bIsValid = true;
				}
			}
			else
			{
				//If the provided property does not exist on target object then target object will be treated as invalid object to process
				bIsValid = false;
			}
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		ERROR_CALL(iStatus);
	}
	return iStatus;
}

int doesPropertyExist(tag_t tTarget, string sProperty, bool &bExists)
{
	int iStatus = ITK_ok;
	ResultStatus rStatus;
	try
	{
		//Get the class of target object
		bExists = false;
		tag_t tClassID = NULLTAG;
		rStatus = POM_class_of_instance(tTarget, &tClassID);

		//Get the class ID of class of target object
		char* cpClassName = NULL;
		rStatus = POM_name_of_class(tClassID, &cpClassName);

		//Check if the property exist on class of the target object
		rStatus = POM_attr_exists(sProperty.c_str(), cpClassName, &bExists);
	}
	catch (const IFail& ex)
	{
		iStatus = ex.ifail();
		ERROR_CALL(iStatus);
	}
	return iStatus;
}

int attachObjects(map<string, string> mArguments, tag_t tRootTask, std::vector<tag_t>& vWorkflowTargets,
	std::vector<tag_t>& vAttachments, std::vector<std::string> vInputTypes)
{
	int iFail = ITK_ok;
	ResultStatus rStatus(0);
	int *piAttachTypes = NULL;
	tag_t* tObjectsToAttach = &vAttachments[0];
	try
	{
		//If include_type or exclude_type is passed, filter objects based on the type
		if (tc_strcasecmp(mArguments.find(INCLUDE_OR_EXCLUDE_TYPE_PRESENT)->second.c_str(), "True") == 0)
		{
			rStatus = filterObjectsBasedOnType(vInputTypes, vAttachments);

		}
		rStatus = filterObjectsBasedOnProperty(mArguments, vAttachments);

		int iAttach = vAttachments.size();
		if (iAttach > 0)
		{
			const char* cpToAttach = mArguments.find(TO_ATTACH_ARG)->second.c_str();
			if ((tc_strcasecmp(cpToAttach, TARGET) == 0) || (tc_strcasecmp(cpToAttach, REFERENCE) == 0))
			{
				piAttachTypes = (int *)MEM_alloc(iAttach * sizeof(int));
				for (int ii = 0; ii < iAttach; ii++)
				{
					piAttachTypes[ii] = getAttachmentType(mArguments.find(TO_ATTACH_ARG)->second.c_str());
				}

				rStatus = EPM_add_attachments(tRootTask, iAttach, tObjectsToAttach, piAttachTypes);
			}
			else
			{
				tag_t tToRelationType;
				getRelationTagFromName(cpToAttach, &tToRelationType);
				for (int i = 0; i < iAttach; i++)
				{
					tag_t tRelation;
					for (int k = 0; k < vWorkflowTargets.size(); k++)
					{
						rStatus = GRM_create_relation(vWorkflowTargets[0], tObjectsToAttach[i], tToRelationType, NULLTAG, &tRelation);
						rStatus = GRM_save_relation(tRelation);
					}
					
				}
			}
		}
	}
	catch (IFail & ex)
	{
		iFail = ex.ifail();
		ERROR_CALL(ex.ifail());
	}

	return iFail;
}