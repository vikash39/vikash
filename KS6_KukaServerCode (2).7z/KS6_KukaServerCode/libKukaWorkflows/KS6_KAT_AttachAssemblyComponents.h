# ifndef KAT_ATTACH_ASSEMBLY_COMPONENTS_H
# define KAT_ATTACH_ASSEMBLY_COMPONENTS_H

//Custom include files
#include "libKukaWorkflows.h"
using namespace std;

#ifdef __cplusplus
extern "C" {
#endif

	#define PARENT_PROPERTY		"parent_property"
	#define PARENT_VALUE		"parent_value"
	#define CHILD_PROPERTY		"child_property"
	#define CHILD_VALUE			"child_value"
	#define REVISION_RULE		"rev_rule"

	int fetchArguments(EPM_action_message_t msg, map<string, string> &mArguments);
	bool validateTarget(tag_t tTarget, map<string, string> &mArguments, bool &bIsValid);
	bool doesPropertyExist(tag_t tTarget, string sProperty, bool &bExists);
	int getValidChildComponents(tag_t tTarget, map<string, string> &mArguments, counted_tag_list_t* sValidChildren);
	int getAttachedComponentsInTarget(tag_t tRootTask, tag_t tpTargets, map<string, string> &mArguments);

	KUKA_WORKFLOW_EXPORT int katAttachAssemblyComponents(EPM_action_message_t msg);


#ifdef __cplusplus
}
#endif


#endif //KAT_ATTACH_ASSEMBLY_COMPONENTS_H